import NotesApp from "@/components/NotesApp";
import { Landing } from "@/components/Landing";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

async function ensureSeedData() {
  const folderCount = await db.folder.count();
  if (folderCount > 0) return;

  const [work, personal, ideas] = await db.folder.createManyAndReturn({
    data: [
      { name: "Работа", color: "#0078d4", icon: "briefcase", position: 0 },
      { name: "Личное", color: "#107c10", icon: "home", position: 1 },
      { name: "Идеи", color: "#ca5010", icon: "bulb", position: 2 },
    ],
  });

  await db.note.createMany({
    data: [
      {
        folderId: work.id,
        title: "Добро пожаловать в Synapse",
        pinned: true,
        tags: JSON.stringify(["старт"]),
        content:
          "<h3>Это ваш второй мозг</h3><p>Пишите заметки, они сохраняются автоматически. Возможности:</p>" +
          "<ul><li>Создавайте <b>папки</b> слева и перетаскивайте заметки прямо на них</li>" +
          "<li>Форматируйте текст: <b>жирный</b>, <i>курсив</i>, списки, чек-листы</li>" +
          "<li>Связывайте заметки упоминаниями: @Second_Brain или @\"Second Brain\"</li>" +
          "<li>Откройте <b>Граф знаний</b> — визуальную паутину всех связей</li>" +
          "<li>Используйте <b>семантический поиск</b> (иконка ✦ в поиске) — ищет по смыслу, не по буквам</li>" +
          "<li>Вставьте ошибку из консоли кнопкой с иконкой жука — ИИ найдёт похожие заметки</li></ul>",
      },
      {
        folderId: ideas.id,
        title: "Second Brain",
        tags: JSON.stringify(["идея", "zettelkasten"]),
        content:
          "<h3>Концепция второго мозга</h3><p>Методология управления знаниями. Подробнее в @Zettelkasten.</p>" +
          "<p>Связи между заметками строются через @упоминания — никаких [[двойных скобок]].</p>",
      },
      {
        folderId: ideas.id,
        title: "Zettelkasten",
        tags: JSON.stringify(["zettelkasten"]),
        content:
          "<h3>Немецкая система заметок</h3><p>Каждая заметка — атомарная мысль, связанная с другими через @упоминания.</p>" +
          "<p>Лежит в основе @Second_Brain.</p>",
      },
      {
        folderId: work.id,
        title: "Подключение PostgreSQL к Next.js",
        tags: JSON.stringify(["код", "nextjs", "postgres"]),
        content:
          "<h3>Решение</h3><p>Используй Prisma + пул соединений:</p>" +
          "<pre><code>useEffect(() => {\n  const client = new Pool({ connectionString: process.env.DATABASE_URL });\n  await client.connect();\n}, []);</code></pre>" +
          "<p>Связано с @Second_Brain.</p>",
      },
      {
        folderId: personal.id,
        title: "Список дел на неделю",
        tags: JSON.stringify(["задачи"]),
        content:
          '<div class="cl-item"><input type="checkbox" contenteditable="false" checked /><span>Изучить интерфейс</span></div>' +
          '<div class="cl-item"><input type="checkbox" contenteditable="false" /><span>Создать первую папку</span></div>' +
          '<div class="cl-item"><input type="checkbox" contenteditable="false" /><span>Импортировать старые заметки</span></div>',
      },
    ],
  });
}

export default async function HomePage() {
  await ensureSeedData();
  return <NotesApp />;
}
