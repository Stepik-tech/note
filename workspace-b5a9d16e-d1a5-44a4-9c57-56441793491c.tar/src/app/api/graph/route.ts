import { db } from "@/lib/db";
import { NextRequest } from "next/server";
import { findWikiLinks, normalizeTitle } from "@/lib/links";

export const dynamic = "force-dynamic";

export type GraphNode = {
  id: number;
  title: string;
  folderId: number | null;
  folderName: string | null;
  folderColor: string | null;
  color: string;
  /** number of incoming links — used for node sizing */
  weight: number;
  tags: string[];
};

export type GraphEdge = {
  source: number;
  target: number;
};

export type GraphData = {
  nodes: GraphNode[];
  edges: GraphEdge[];
};

/** Build the global knowledge graph: nodes = notes, edges = wiki-links A→B. */
export async function GET(_req: NextRequest) {
  const [notes, folders] = await Promise.all([
    db.note.findMany({
      where: { trashed: false },
      select: { id: true, title: true, content: true, color: true, folderId: true, tags: true },
    }),
    db.folder.findMany({ select: { id: true, name: true, color: true } }),
  ]);

  const folderMap = new Map(folders.map((f) => [f.id, f]));
  const titleToId = new Map<string, number>();
  for (const n of notes) titleToId.set(normalizeTitle(n.title), n.id);

  const edges: GraphEdge[] = [];
  const inDegree = new Map<number, number>();
  for (const n of notes) {
    const links = findWikiLinks(n.content ?? "");
    const seen = new Set<number>();
    for (const l of links) {
      const tid = titleToId.get(normalizeTitle(l.target));
      if (!tid || tid === n.id || seen.has(tid)) continue;
      seen.add(tid);
      edges.push({ source: n.id, target: tid });
      inDegree.set(tid, (inDegree.get(tid) ?? 0) + 1);
    }
  }

  const nodes: GraphNode[] = notes.map((n) => {
    const folder = n.folderId ? folderMap.get(n.folderId) : null;
    let tags: string[] = [];
    try {
      tags = JSON.parse(n.tags || "[]");
      if (!Array.isArray(tags)) tags = [];
    } catch {
      tags = [];
    }
    return {
      id: n.id,
      title: n.title,
      folderId: n.folderId,
      folderName: folder?.name ?? null,
      folderColor: folder?.color ?? null,
      color: n.color,
      weight: inDegree.get(n.id) ?? 0,
      tags,
    };
  });

  const data: GraphData = { nodes, edges };
  return Response.json(data);
}
