import { db } from "@/lib/db";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  // count non-trashed notes per folder
  const folders = await db.folder.findMany({
    orderBy: [{ position: "asc" }, { id: "asc" }],
    include: { notes: { where: { trashed: false }, select: { id: true } } },
  });
  return Response.json(
    folders.map((f) => ({
      id: f.id,
      name: f.name,
      color: f.color,
      icon: f.icon,
      position: f.position,
      createdAt: f.createdAt.toISOString(),
      noteCount: f.notes.length,
    }))
  );
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const name = typeof body.name === "string" && body.name.trim() ? body.name.trim() : "Новая папка";
  const color = typeof body.color === "string" ? body.color : "#0078D4";
  const icon = typeof body.icon === "string" ? body.icon : "📁";

  const maxRow = await db.folder.aggregate({ _max: { position: true } });
  const nextPosition = (maxRow._max.position ?? -1) + 1;

  const created = await db.folder.create({
    data: { name, color, icon, position: nextPosition },
  });
  return Response.json(
    {
      id: created.id,
      name: created.name,
      color: created.color,
      icon: created.icon,
      position: created.position,
      createdAt: created.createdAt.toISOString(),
      noteCount: 0,
    },
    { status: 201 }
  );
}
