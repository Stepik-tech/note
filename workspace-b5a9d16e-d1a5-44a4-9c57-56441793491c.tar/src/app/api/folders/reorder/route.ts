import { db } from "@/lib/db";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const order: unknown = body?.order;
  if (!Array.isArray(order)) {
    return Response.json({ error: "order must be an array of ids" }, { status: 400 });
  }

  await Promise.all(
    order.map((id, index) =>
      typeof id === "number"
        ? db.folder.update({ where: { id }, data: { position: index } })
        : Promise.resolve()
    )
  );

  return Response.json({ ok: true });
}
