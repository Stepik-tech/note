import { db } from "@/lib/db";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function parseId(idParam: string) {
  const id = Number(idParam);
  return Number.isInteger(id) ? id : null;
}

export async function PATCH(req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const update: any = {};

  if (typeof body.name === "string") update.name = body.name.trim() || "Без названия";
  if (typeof body.color === "string") update.color = body.color;
  if (typeof body.icon === "string") update.icon = body.icon;
  if (typeof body.position === "number") update.position = body.position;

  if (Object.keys(update).length === 0) {
    return Response.json({ error: "No fields to update" }, { status: 400 });
  }

  const updated = await db.folder.update({ where: { id }, data: update });
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json({
    id: updated.id,
    name: updated.name,
    color: updated.color,
    icon: updated.icon,
    position: updated.position,
    createdAt: updated.createdAt.toISOString(),
  });
}

export async function DELETE(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  // detach notes from this folder, then delete the folder
  await db.note.updateMany({ where: { folderId: id }, data: { folderId: null } });
  const deleted = await db.folder.delete({ where: { id } }).catch(() => null);
  if (!deleted) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json({ ok: true });
}
