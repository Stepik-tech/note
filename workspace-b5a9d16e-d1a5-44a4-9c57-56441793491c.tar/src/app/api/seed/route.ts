import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { findHashtags } from '@/lib/notes'
import { pickColor } from '@/lib/tags'

const SEED: Array<{ title: string; content: string; folder: string }> = [
  {
    title: 'Second Brain',
    folder: 'Ideas',
    content: `# Second Brain

Методология управления знаниями по [[Zettelkasten]].

Главный принцип — заметки не живут в папках, а связаны между собой через [[Backlinks]].

См. также [[Knowledge Graph]] и [[AI Actions]].

#productivity #knowledge`,
  },
  {
    title: 'Zettelkasten',
    folder: 'Ideas',
    content: `# Zettelkasten

Немецкая система заметок Никласа Лумана. Каждая заметка — атомарная мысль, связанная с другими через [[Backlinks]].

Лежит в основе [[Second Brain]].`,
  },
  {
    title: 'Backlinks',
    folder: 'Ideas',
    content: `# Backlinks

Двунаправленные связи. Если в заметке A написать [[Zettelkasten]], то в заметке Zettelkasten появится запись «на эту страницу ссылаются: A».

Это позволяет строить [[Knowledge Graph]] и поддерживает [[Second Brain]].`,
  },
  {
    title: 'Knowledge Graph',
    folder: 'Ideas',
    content: `# Knowledge Graph

Визуализация всех связей между заметками. Узлы = заметки, рёбра = [[Backlinks]].

Чем больше входящих ссылок — тем крупнее узел (хаб знаний).

#visualization`,
  },
  {
    title: 'AI Actions',
    folder: 'Work',
    content: `# AI Actions

Контекстные микро-инструменты для выделенного текста:

- Саммари в один клик
- [[Action Items]] — вытащить поручения
- Изменение тона: формальный / неформальный / простой

Поддерживает работу в [[Second Brain]].`,
  },
  {
    title: 'Action Items',
    folder: 'Tasks',
    content: `# Action Items

- [ ] @Иван сделать дизайн к среде
- [ ] Отправить бриф в [[AI Actions]]
- [x] Согласовать план с командой

#work`,
  },
  {
    title: 'Inbox Quick Capture',
    folder: 'Inbox',
    content: `Быстрая заметка-тест. Купить молоко завтра в 19:00.

Ссылка на [[Second Brain]].`,
  },
  {
    title: 'Reading List',
    folder: 'Personal',
    content: `# Что прочитать

- Книга "How to Take Smart Notes" — про [[Zettelkasten]]
- Статья про [[Knowledge Graph]] в Obsidian

#reading`,
  },
  {
    title: 'Project: Notes App',
    folder: 'Work',
    content: `# Заметки-приложение

Стек: Next.js, Prisma, [[AI Actions]].

Вдохновлено [[Second Brain]] и [[Zettelkasten]].

- [ ] Реализовать [[Backlinks]]
- [ ] Подключить голосовой ввод
- [ ] OCR для фото-заметок

#work #dev`,
  },
]

export async function POST() {
  // wipe
  await db.noteTag.deleteMany()
  await db.note.deleteMany()
  await db.tag.deleteMany()

  for (const s of SEED) {
    const tagNames = findHashtags(s.content)
    const tagRecords = await Promise.all(
      tagNames.map((name) =>
        db.tag.upsert({
          where: { name },
          update: {},
          create: { name, color: pickColor(name) },
        })
      )
    )
    await db.note.create({
      data: {
        title: s.title,
        content: s.content,
        folder: s.folder,
        isPinned: s.title === 'Second Brain',
        tags: { create: tagRecords.map((t) => ({ tagId: t.id })) },
      },
    })
  }
  return NextResponse.json({ ok: true, count: SEED.length })
}
