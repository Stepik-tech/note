import { NextRequest, NextResponse } from 'next/server'
import { aiComplete, extractJSON } from '@/lib/ai'
import type { ParsedInbox } from '@/lib/types'

const SYSTEM = `You are an inbox parser for a notes app. Convert a single line (or short text) of user input into a structured note.

Return STRICT JSON with these fields:
{
  "title": string,            // short, clear note title (max 80 chars). For tasks start with a verb.
  "content": string,          // expanded markdown body, keep it short. May add context.
  "isTask": boolean,          // true if the input is an actionable task / todo
  "dueDate": string | null,   // ISO 8601 if a deadline is mentioned, else null
  "reminderAt": string | null,// ISO 8601 if a reminder time is mentioned, else null
  "tags": string[],           // 0-3 short lowercase tags without '#'. e.g. ["shopping","work"]
  "folder": string            // one of: "Inbox","Tasks","Ideas","Work","Personal","Journal". Default "Inbox".
}

Rules:
- The user's "now" is given. Interpret "tomorrow", "next monday", "in 2 hours" relative to it.
- If input is just an idea (not a task), set isTask=false and folder="Ideas".
- Never invent extra facts. Keep it faithful.
- Output ONLY the JSON object.`

export async function POST(req: NextRequest) {
  const { text, now } = (await req.json()) as { text: string; now?: string }
  if (!text || !text.trim()) return NextResponse.json({ error: 'empty' }, { status: 400 })

  const nowIso = now ?? new Date().toISOString()
  const raw = await aiComplete(SYSTEM, `NOW: ${nowIso}\nINPUT: ${text}`, { json: true, temperature: 0.2 })
  const parsed = extractJSON<ParsedInbox>(raw)
  if (!parsed) {
    // fallback: keep raw text as title
    return NextResponse.json({
      parsed: {
        title: text.slice(0, 80),
        content: text,
        isTask: false,
        dueDate: null,
        reminderAt: null,
        tags: [],
        folder: 'Inbox',
      } as ParsedInbox,
    })
  }
  return NextResponse.json({ parsed })
}
