import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { Note } from '@/lib/note-mappers'
import { aiComplete, extractJSON } from '@/lib/ai'

export const dynamic = 'force-dynamic'

const SYSTEM = `You are a debugging assistant inside a notes app for developers.
Given a stack trace / error log / console output from the user, do two things:

1. Parse the error and extract structured metadata.
2. Find related notes in the user's knowledge base by matching technology, error type,
   file paths, function names, or semantic similarity to past errors/solutions.

Return STRICT JSON:
{
  "title": string,            // short error title, e.g. "TypeError: Cannot read 'map' of undefined"
  "language": string|null,    // detected language: TypeScript|JavaScript|Python|Go|Rust|Java|etc
  "framework": string|null,   // detected framework/lib: React|Next.js|Express|Prisma|etc
  "errorType": string|null,   // TypeError|ReferenceError|SyntaxError|ImportError|panic|etc
  "file": string|null,        // first relevant file path from the trace
  "line": number|null,        // line number if present
  "tags": string[],           // 1-4 short lowercase tags, e.g. ["typescript","react","null-ref"]
  "summary": string,          // 1-2 sentence plain-language explanation of the error
  "related": [                // ids of related notes (max 5), ranked by relevance
    { "id": number, "reason": string }
  ]
}

Rules:
- Only include note ids from the provided candidate list.
- "reason" should explain WHY this note is related (e.g. "Same TypeError in React component, solution recorded").
- Output ONLY the JSON object.`

export async function POST(req: NextRequest) {
  const { trace } = (await req.json()) as { trace: string }
  if (!trace || !trace.trim()) return NextResponse.json({ error: 'empty' }, { status: 400 })

  // candidate pool: all non-trashed notes (cap 60)
  const rows = await db.note.findMany({
    where: { trashed: false },
    select: { id: true, title: true, content: true, tags: true },
    take: 60,
  })
  const pool = rows.map((r) => {
    let tags: string[] = []
    try { tags = JSON.parse(r.tags || '[]') } catch {}
    const text = (r.title + ' ' + r.content).replace(/<[^>]+>/g, ' ').slice(0, 400)
    return { id: r.id, title: r.title, tags, text }
  })

  const userMsg = `STACK TRACE / ERROR LOG:
${trace.slice(0, 4000)}

CANDIDATE NOTES (id :: title :: tags :: snippet):
${pool.map((p) => `- ${p.id} :: ${p.title} :: [${p.tags.join(',')}] :: ${p.text.slice(0, 200)}`).join('\n')}`

  let parsed: {
    title: string
    language: string | null
    framework: string | null
    errorType: string | null
    file: string | null
    line: number | null
    tags: string[]
    summary: string
    related: { id: number; reason: string }[]
  } | null = null

  try {
    const raw = await aiComplete(SYSTEM, userMsg, { json: true, temperature: 0.2 })
    parsed = extractJSON<typeof parsed>(raw)
  } catch {
    // fall back to a basic parse
  }

  if (!parsed) {
    // minimal fallback
    const firstLine = trace.split('\n').find((l) => l.trim()) ?? 'Ошибка'
    return NextResponse.json({
      parsed: {
        title: firstLine.slice(0, 100),
        language: null,
        framework: null,
        errorType: null,
        file: null,
        line: null,
        tags: ['ошибка'],
        summary: 'Не удалось распарсить ошибку через ИИ. Сохранено как есть.',
        related: [],
      },
    })
  }

  // fetch full related notes
  const relatedIds = (parsed.related ?? []).map((r) => r.id).filter((id) => pool.some((p) => p.id === id))
  const relatedNotes = relatedIds.length ? await db.note.findMany({ where: { id: { in: relatedIds } } }) : []
  const relatedMap = new Map(parsed.related?.map((r) => [r.id, r.reason]))

  return NextResponse.json({
    parsed: {
      ...parsed,
      related: relatedNotes.map((n) => ({
        note: Note.toDTO(n),
        reason: relatedMap.get(n.id) ?? 'Связано по контексту ошибки',
      })),
    },
  })
}
