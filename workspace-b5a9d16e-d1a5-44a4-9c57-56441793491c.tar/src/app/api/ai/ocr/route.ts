import { NextRequest, NextResponse } from 'next/server'
import { getAI } from '@/lib/ai'

const SYSTEM = `Extract ALL visible text from the image. Preserve layout with line breaks. If the image has no readable text, return an empty string. Output only the extracted text, no commentary.`

export async function POST(req: NextRequest) {
  const form = await req.formData()
  const file = form.get('file') as File | null
  const base64 = form.get('file_base64') as string | null
  if (!file && !base64) return NextResponse.json({ error: 'no image' }, { status: 400 })

  let b64 = base64 ?? ''
  let mime = 'image/png'
  if (file) {
    b64 = await fileToBase64(file)
    mime = file.type || 'image/png'
  }
  const dataUrl = `data:${mime};base64,${b64}`

  try {
    const ai = await getAI()
    const res = await ai.chat.completions.createVision({
      model: 'glm-4.5v',
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: [{ type: 'image_url', image_url: { url: dataUrl } }] },
      ],
    })
    const text: string =
      res?.choices?.[0]?.message?.content ?? res?.choices?.[0]?.delta?.content ?? ''
    return NextResponse.json({ text: text.trim() })
  } catch (e: any) {
    return NextResponse.json({ error: 'ocr_failed', detail: String(e?.message ?? e) }, { status: 500 })
  }
}

async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  return Buffer.from(buf).toString('base64')
}
