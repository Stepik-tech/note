import { NextRequest, NextResponse } from 'next/server'
import { aiComplete } from '@/lib/ai'

const SYSTEM = `Summarize the user's text into 3-7 concise bullet points in markdown. Keep the original language (Russian stays Russian, English stays English). Do not add new facts. Output only the bullet list.`

export async function POST(req: NextRequest) {
  const { text } = (await req.json()) as { text: string }
  if (!text?.trim()) return NextResponse.json({ error: 'empty' }, { status: 400 })
  const summary = await aiComplete(SYSTEM, text, { temperature: 0.3 })
  return NextResponse.json({ summary })
}
