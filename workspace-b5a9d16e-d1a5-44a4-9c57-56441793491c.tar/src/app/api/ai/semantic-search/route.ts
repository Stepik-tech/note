import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { aiComplete, extractJSON } from '@/lib/ai'

export const dynamic = 'force-dynamic'

/**
 * Semantic search across notes (by meaning, not by exact words).
 * Improved logic:
 *  1. Fetch a larger candidate pool (recent + tagged + substring)
 *  2. Give the LLM more context per note (title + tags + first 500 chars)
 *  3. Ask for a relevance score + reason for each match
 *  4. Sort by score descending
 */
export async function POST(req: NextRequest) {
  const { query } = (await req.json()) as { query: string }
  if (!query?.trim()) return NextResponse.json({ ids: [], matches: [] })

  // Build a broad candidate pool
  const [recent, byTitle, byContent] = await Promise.all([
    db.note.findMany({
      take: 30,
      orderBy: { updatedAt: 'desc' },
      select: { id: true, title: true, content: true, tags: true },
    }),
    db.note.findMany({
      where: { title: { contains: query } },
      take: 20,
      select: { id: true, title: true, content: true, tags: true },
    }),
    db.note.findMany({
      where: { content: { contains: query } },
      take: 20,
      select: { id: true, title: true, content: true, tags: true },
    }),
  ])

  const map = new Map<number, { id: number; title: string; tags: string[]; text: string }>()
  for (const n of [...recent, ...byTitle, ...byContent]) {
    if (map.has(n.id)) continue
    let tags: string[] = []
    try { tags = JSON.parse(n.tags || '[]') } catch {}
    const text = (n.title + ' ' + n.content).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 500)
    map.set(n.id, { id: n.id, title: n.title, tags, text })
  }
  const pool = [...map.values()]
  if (pool.length === 0) return NextResponse.json({ ids: [], matches: [] })

  const SYSTEM = `You are a semantic search engine for a developer's notes app (like an internal StackOverflow).
Given a user query and a list of candidate notes, return the most relevant note IDs ranked by semantic similarity.

IMPORTANT RULES:
- Match by MEANING, not exact words. "connect database to react" should match code with \`useEffect(() => connectDB())\`.
- Code snippets count: if a note contains code that does what the query asks, it's a match.
- Tags count: if query mentions "react" and note is tagged #react, that's relevant.
- Return a relevance score 0-100 and a short reason for each match.
- Only include notes with score >= 40.
- Max 8 results.

Return STRICT JSON:
{ "results": [{ "id": number, "score": number, "reason": string }] }
Output ONLY the JSON object.`

  const userMsg = `QUERY: ${query}

CANDIDATES:
${pool.map((p) => `- [${p.id}] ${p.title} {tags: [${p.tags.join(',')}]}\n  ${p.text.slice(0, 300)}`).join('\n\n')}`

  let results: { id: number; score: number; reason: string }[] = []
  try {
    const raw = await aiComplete(SYSTEM, userMsg, { json: true, temperature: 0.1 })
    const parsed = extractJSON<{ results: typeof results }>(raw)
    results = parsed?.results ?? []
  } catch {
    results = []
  }

  // Filter valid ids, sort by score, dedupe
  const seen = new Set<number>()
  results = results
    .filter((r) => map.has(r.id) && !seen.has(r.id) && seen.add(r.id))
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)

  const matches = results.map((r) => ({
    id: r.id,
    title: map.get(r.id)!.title,
    snippet: map.get(r.id)!.text.slice(0, 200),
    score: r.score,
    reason: r.reason,
  }))

  return NextResponse.json({ ids: matches.map((m) => m.id), matches })
}
