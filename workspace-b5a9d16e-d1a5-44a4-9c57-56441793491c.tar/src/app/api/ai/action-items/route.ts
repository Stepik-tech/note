import { NextRequest, NextResponse } from 'next/server'
import { aiComplete, extractJSON } from '@/lib/ai'
import type { ActionItem } from '@/lib/types'

const SYSTEM = `Extract action items (поручения / задачи) from the text.
Return STRICT JSON: { "items": [{ "text": string, "assignee"?: string, "due"?: string }] }
- text: the action in imperative form, in the original language.
- assignee: a person mentioned after @ or "имя" (optional).
- due: ISO date or short text like "среда" if mentioned (optional).
Output ONLY JSON.`

export async function POST(req: NextRequest) {
  const { text } = (await req.json()) as { text: string }
  if (!text?.trim()) return NextResponse.json({ error: 'empty' }, { status: 400 })
  const raw = await aiComplete(SYSTEM, text, { json: true, temperature: 0.2 })
  const parsed = extractJSON<{ items: ActionItem[] }>(raw)
  return NextResponse.json({ items: parsed?.items ?? [] })
}
