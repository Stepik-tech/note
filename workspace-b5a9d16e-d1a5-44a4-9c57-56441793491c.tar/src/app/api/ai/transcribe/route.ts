import { NextRequest, NextResponse } from 'next/server'
import { aiComplete, getAI } from '@/lib/ai'

const SYSTEM = `You are cleaning up a speech-to-text transcript.
Tasks:
1. Remove filler words (Russian: "эм", "ну", "типа", "короче", "как бы", "вот"; English: "um", "uh", "like", "you know").
2. Remove duplicate/repeated phrases and long pauses.
3. Fix punctuation and capitalization.
4. Split into short paragraphs; turn enumerated speech into bullet lists when appropriate.
5. Preserve the original language and meaning. Do NOT add new facts.
Output ONLY the cleaned markdown text.`

export async function POST(req: NextRequest) {
  const form = await req.formData()
  const file = form.get('file') as File | null
  const base64 = form.get('file_base64') as string | null

  if (!file && !base64) return NextResponse.json({ error: 'no audio' }, { status: 400 })

  let transcript = ''
  try {
    const ai = await getAI()
    const body: any = file ? { file_base64: await fileToBase64(file) } : { file_base64: base64 }
    const res = await ai.audio.asr.create(body)
    transcript = typeof res === 'string' ? res : (res?.text ?? res?.transcript ?? JSON.stringify(res))
  } catch (e: any) {
    return NextResponse.json({ error: 'asr_failed', detail: String(e?.message ?? e) }, { status: 500 })
  }

  if (!transcript.trim()) return NextResponse.json({ text: '', cleaned: '' })

  // AI cleanup pass
  const cleaned = await aiComplete(SYSTEM, transcript, { temperature: 0.3 }).catch(() => transcript)
  return NextResponse.json({ text: transcript, cleaned })
}

async function fileToBase64(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  return Buffer.from(buf).toString('base64')
}
