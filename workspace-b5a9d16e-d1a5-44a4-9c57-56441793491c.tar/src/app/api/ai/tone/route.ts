import { NextRequest, NextResponse } from 'next/server'
import { aiComplete } from '@/lib/ai'

const SYSTEM_MAP: Record<string, string> = {
  formal: `Rewrite the user's text in a more formal, professional tone suitable for business correspondence. Keep the same language. Keep the meaning. Output only the rewritten text.`,
  casual: `Rewrite the user's text in a friendlier, more casual tone. Keep the same language. Keep the meaning. Output only the rewritten text.`,
  simple: `Rewrite the user's text using simpler, clearer language (B1 level). Keep the same language. Keep the meaning. Output only the rewritten text.`,
  concise: `Rewrite the user's text more concisely, removing redundancy. Keep the same language. Keep the meaning. Output only the rewritten text.`,
}

export async function POST(req: NextRequest) {
  const { text, tone } = (await req.json()) as { text: string; tone: keyof typeof SYSTEM_MAP }
  if (!text?.trim()) return NextResponse.json({ error: 'empty' }, { status: 400 })
  const sys = SYSTEM_MAP[tone] ?? SYSTEM_MAP.formal
  const result = await aiComplete(sys, text, { temperature: 0.4 })
  return NextResponse.json({ text: result })
}
