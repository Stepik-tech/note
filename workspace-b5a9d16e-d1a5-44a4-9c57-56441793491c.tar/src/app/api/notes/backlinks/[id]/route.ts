import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { BacklinkDTO } from '@/lib/types'
import { findWikiLinks, buildBacklinkSnippet, normalizeTitle } from '@/lib/notes'

/**
 * Get all notes that link TO the note with :id.
 */
export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const target = await db.note.findUnique({ where: { id } })
  if (!target) return NextResponse.json({ backlinks: [] })

  const targetNorm = normalizeTitle(target.title)
  // pull all notes (small dataset) and filter
  const all = await db.note.findMany({ select: { id: true, title: true, content: true, updatedAt: true } })
  const backlinks: BacklinkDTO[] = []
  for (const n of all) {
    if (n.id === id) continue
    const links = findWikiLinks(n.content ?? '')
    const hit = links.some((l) => normalizeTitle(l.target) === targetNorm)
    if (hit) {
      backlinks.push({
        fromId: n.id,
        fromTitle: n.title,
        snippet: buildBacklinkSnippet(n.content ?? '', target.title),
        updatedAt: n.updatedAt.toISOString(),
      })
    }
  }
  backlinks.sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt))
  return NextResponse.json({ backlinks })
}
