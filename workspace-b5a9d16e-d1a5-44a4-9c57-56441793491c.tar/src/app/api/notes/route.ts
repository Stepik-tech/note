import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const hasView = searchParams.has("view");
  const view = searchParams.get("view") ?? "all";
  const folderId = searchParams.get("folderId");
  const tag = searchParams.get("tag");
  const q = searchParams.get("q")?.trim();
  const sort = searchParams.get("sort") ?? "updated-desc";

  if (!hasView) {
    // Full, unfiltered snapshot used by the client for instant local filtering.
    const rows = await db.note.findMany({
      orderBy: [{ pinned: "desc" }, { updatedAt: "desc" }],
    });
    return Response.json(rows.map(Note.toDTO));
  }

  // Build where conditions
  const where: any[] = [];
  if (view === "trash") {
    where.push({ trashed: true });
  } else {
    where.push({ trashed: false });
    if (view === "favorites") where.push({ favorite: true });
    if (view === "pinned") where.push({ pinned: true });
    if (view === "archive") {
      where.push({ archived: true });
    } else if (view !== "favorites" && view !== "pinned") {
      where.push({ archived: false });
    }
  }

  if (folderId && folderId !== "null" && !Number.isNaN(Number(folderId))) {
    where.push({ folderId: Number(folderId) });
  } else if (folderId === "null") {
    where.push({ folderId: null });
  }

  // SQLite has no native JSON array containment; filter tag in memory after fetch.
  // We fetch a broad set first, then filter.
  let rows = await db.note.findMany({ where: { AND: where } });

  if (tag) {
    rows = rows.filter((r) => {
      const tags: string[] = JSON.parse(r.tags || "[]");
      return tags.includes(tag);
    });
  }

  if (q) {
    const ql = q.toLowerCase();
    rows = rows.filter(
      (r) => r.title.toLowerCase().includes(ql) || r.content.toLowerCase().includes(ql)
    );
  }

  // sort
  rows.sort((a, b) => {
    if (view !== "trash" && a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    switch (sort) {
      case "created-desc":
        return +new Date(b.createdAt) - +new Date(a.createdAt);
      case "title-asc":
        return a.title.localeCompare(b.title, "ru");
      case "title-desc":
        return b.title.localeCompare(a.title, "ru");
      default:
        return +new Date(view === "trash" ? (b.deletedAt ?? b.updatedAt) : b.updatedAt) -
          +new Date(view === "trash" ? (a.deletedAt ?? a.updatedAt) : a.updatedAt);
    }
  });

  return Response.json(rows.map(Note.toDTO));
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const folderId = typeof body.folderId === "number" ? body.folderId : null;
  const title = typeof body.title === "string" ? body.title : "";
  const content = typeof body.content === "string" ? body.content : "";
  const tags =
    Array.isArray(body.tags) && body.tags.every((t: unknown) => typeof t === "string")
      ? JSON.stringify(body.tags)
      : "[]";

  const created = await db.note.create({
    data: { folderId, title, content, tags },
  });
  return Response.json(Note.toDTO(created), { status: 201 });
}
