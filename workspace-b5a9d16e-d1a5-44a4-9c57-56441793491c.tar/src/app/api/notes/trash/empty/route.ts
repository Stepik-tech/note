import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function POST() {
  await db.note.deleteMany({ where: { trashed: true } });
  return Response.json({ ok: true });
}
