import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";
import { findWikiLinks, buildBacklinkSnippet, normalizeTitle } from "@/lib/links";

export const dynamic = "force-dynamic";

export type BacklinkDTO = {
  fromId: number;
  fromTitle: string;
  snippet: string;
  updatedAt: string;
};

/** Get all notes that link TO the note with :id (via [[Title]] syntax). */
export async function GET(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = Number(idParam);
  if (!Number.isInteger(id)) return Response.json({ backlinks: [] });

  const target = await db.note.findUnique({ where: { id } });
  if (!target) return Response.json({ backlinks: [] });

  const targetNorm = normalizeTitle(target.title);
  if (!targetNorm) return Response.json({ backlinks: [] });

  // fetch all non-trashed notes and scan their content for [[target]]
  const all = await db.note.findMany({
    where: { trashed: false },
    select: { id: true, title: true, content: true, updatedAt: true },
  });

  const backlinks: BacklinkDTO[] = [];
  for (const n of all) {
    if (n.id === id) continue;
    const links = findWikiLinks(n.content ?? "");
    const hit = links.some((l) => normalizeTitle(l.target) === targetNorm);
    if (hit) {
      backlinks.push({
        fromId: n.id,
        fromTitle: n.title,
        snippet: buildBacklinkSnippet(n.content ?? "", target.title),
        updatedAt: n.updatedAt.toISOString(),
      });
    }
  }
  backlinks.sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt));
  return Response.json({ backlinks });
}

// re-export for type-only usage elsewhere
export type { Note };
