import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = Number(idParam);
  if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });

  const original = await db.note.findUnique({ where: { id } });
  if (!original) return Response.json({ error: "Not found" }, { status: 404 });

  const created = await db.note.create({
    data: {
      folderId: original.folderId,
      title: original.title ? `${original.title} (копия)` : "",
      content: original.content,
      color: original.color,
      tags: original.tags,
      pinned: false,
      favorite: false,
      archived: false,
      trashed: false,
    },
  });

  return Response.json(Note.toDTO(created), { status: 201 });
}
