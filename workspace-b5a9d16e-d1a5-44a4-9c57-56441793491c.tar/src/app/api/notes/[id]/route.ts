import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function parseId(idParam: string) {
  const id = Number(idParam);
  return Number.isInteger(id) ? id : null;
}

export async function GET(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const row = await db.note.findUnique({ where: { id } });
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(Note.toDTO(row));
}

export async function PATCH(req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const update: any = {};

  if (typeof body.title === "string") update.title = body.title;
  if (typeof body.content === "string") update.content = body.content;
  if (typeof body.color === "string") update.color = body.color;
  if (Array.isArray(body.tags))
    update.tags = JSON.stringify(body.tags.filter((t: unknown) => typeof t === "string"));
  if (typeof body.pinned === "boolean") update.pinned = body.pinned;
  if (typeof body.favorite === "boolean") update.favorite = body.favorite;
  if (typeof body.archived === "boolean") update.archived = body.archived;
  if (body.folderId === null || typeof body.folderId === "number") update.folderId = body.folderId;
  if (typeof body.position === "number") update.position = body.position;

  if (typeof body.trashed === "boolean") {
    update.trashed = body.trashed;
    update.deletedAt = body.trashed ? new Date() : null;
  }

  if (Object.keys(update).length === 0) {
    return Response.json({ error: "No fields to update" }, { status: 400 });
  }

  update.updatedAt = new Date();

  const updated = await db.note.update({ where: { id }, data: update });
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json(Note.toDTO(updated));
}

export async function DELETE(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const existing = await db.note.findUnique({ where: { id } });
  if (!existing) return Response.json({ error: "Not found" }, { status: 404 });

  if (existing.trashed) {
    await db.note.delete({ where: { id } });
    return Response.json({ ok: true, permanent: true });
  }

  const updated = await db.note.update({
    where: { id },
    data: { trashed: true, deletedAt: new Date(), updatedAt: new Date() },
  });

  return Response.json({ ok: true, permanent: false, note: Note.toDTO(updated) });
}
