import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = Number(idParam);
  if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });

  const updated = await db.note.update({
    where: { id },
    data: { trashed: false, deletedAt: null, archived: false, updatedAt: new Date() },
  });

  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(Note.toDTO(updated));
}
