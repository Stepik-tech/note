import { db } from "@/lib/db";
import { Note } from "@/lib/note-mappers";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function escapeHtml(text: string) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const folderId = typeof body.folderId === "number" ? body.folderId : null;

  // JSON backup import (array of note-like objects)
  if (Array.isArray(body.notes)) {
    const toInsert = body.notes
      .filter((n: unknown) => n && typeof n === "object")
      .map((n: Record<string, unknown>) => ({
        folderId,
        title: typeof n.title === "string" ? n.title : "",
        content: typeof n.content === "string" ? n.content : "",
        color: typeof n.color === "string" ? n.color : "#ffffff",
        tags: JSON.stringify(
          Array.isArray(n.tags) ? n.tags.filter((t) => typeof t === "string") : []
        ),
      }));

    if (toInsert.length === 0) return Response.json({ error: "Nothing to import" }, { status: 400 });

    const created = await db.note.createMany({ data: toInsert });
    const rows = await db.note.findMany({
      orderBy: { id: "desc" },
      take: created.count,
    });
    return Response.json({ ok: true, count: created.count, notes: rows.map(Note.toDTO) });
  }

  // Plain text import: split into separate notes by blank-line-separated blocks
  if (typeof body.text === "string" && body.text.trim()) {
    const blocks = body.text
      .split(/\n\s*\n\s*\n+/)
      .map((b: string) => b.trim())
      .filter(Boolean);

    const chunks = blocks.length > 0 ? blocks : [body.text.trim()];

    const toInsert = chunks.map((block: string) => {
      const lines = block.split("\n");
      const title = lines[0]?.slice(0, 120) ?? "Импортированная заметка";
      const rest = lines.slice(1).join("\n").trim();
      const htmlBody = (rest || block)
        .split("\n")
        .map((line) => `<p>${escapeHtml(line) || "<br>"}</p>`)
        .join("");
      return {
        folderId,
        title,
        content: htmlBody,
        color: "#ffffff",
        tags: "[]",
      };
    });

    const created = await db.note.createMany({ data: toInsert });
    const rows = await db.note.findMany({
      orderBy: { id: "desc" },
      take: created.count,
    });
    return Response.json({ ok: true, count: created.count, notes: rows.map(Note.toDTO) });
  }

  return Response.json({ error: "Provide notes[] or text" }, { status: 400 });
}
