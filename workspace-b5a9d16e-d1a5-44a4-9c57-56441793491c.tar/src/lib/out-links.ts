"use client";

import { findMentions, normalizeTitle } from "@/lib/links";
import type { NoteDTO } from "@/lib/types";

export type OutLink = {
  id: number | null;
  title: string;
};

/** Compute outgoing @mentions from the current note's content. */
export function computeOutLinks(content: string, allNotes: NoteDTO[]): OutLink[] {
  const raw = findMentions(content);
  const seen = new Set<string>();
  const out: OutLink[] = [];
  for (const l of raw) {
    const key = normalizeTitle(l.target);
    if (seen.has(key)) continue
    seen.add(key);
    const found = allNotes.find((n) => normalizeTitle(n.title) === key);
    out.push({ id: found ? found.id : null, title: l.target });
  }
  return out;
}
