import type { Note as PrismaNote } from "@prisma/client"
import type { NoteDTO } from "@/lib/types"

/**
 * Convert a Prisma Note row to the NoteDTO shape used by the frontend.
 * Tags are stored as a JSON-encoded string in SQLite; decode them here.
 */
export const Note = {
  toDTO(r: PrismaNote): NoteDTO {
    let tags: string[] = []
    try {
      tags = JSON.parse(r.tags || "[]")
      if (!Array.isArray(tags)) tags = []
    } catch {
      tags = []
    }
    return {
      id: r.id,
      folderId: r.folderId,
      title: r.title,
      content: r.content,
      color: r.color,
      tags,
      pinned: r.pinned,
      favorite: r.favorite,
      archived: r.archived,
      trashed: r.trashed,
      position: r.position,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
      deletedAt: r.deletedAt ? r.deletedAt.toISOString() : null,
    }
  },
}
