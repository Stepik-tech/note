/**
 * Mentions-based links (Notion/Slack-style @mentions) — replaces [[wiki-links]].
 *
 * Syntax in note content (HTML):
 *   @Word         — links to a note titled "Word"
 *   @"Two words"  — links to a note titled "Two words"
 *
 * The parser scans the plain text of the note (HTML stripped) for mentions
 * and resolves them against the note list. Backlinks are computed by scanning
 * every note's content for mentions of the target note's title.
 */

export interface Mention {
  /** raw target title (as written, without @ and quotes) */
  target: string;
  index: number;
}

const MENTION_RE = /@(?:[A-Za-zА-Яа-яЁё0-9_][A-Za-zА-Яа-яЁё0-9_-]*|"[^"]+")/g;

/** Find all @mentions in a (possibly HTML) string. */
export function findMentions(text: string): Mention[] {
  const out: Mention[] = [];
  if (!text) return out;
  // strip HTML to plain text but keep positions roughly intact
  const plain = stripHtmlKeepLength(text);
  let m: RegExpExecArray | null;
  MENTION_RE.lastIndex = 0;
  while ((m = MENTION_RE.exec(plain)) !== null) {
    let raw = m[0].slice(1); // drop @
    if (raw.startsWith('"') && raw.endsWith('"')) {
      raw = raw.slice(1, -1);
    }
    out.push({ target: raw.trim(), index: m.index });
  }
  return out;
}

/** Normalize a title for case-insensitive matching. */
export function normalizeTitle(title: string): string {
  return (title || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function stripHtmlKeepLength(html: string): string {
  // Replace tags with spaces of equal length to preserve indices.
  return (html || "").replace(/<[^>]+>/g, (tag) => " ".repeat(tag.length));
}

function stripHtml(html: string): string {
  return (html || "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

/** Build a short snippet of context around a mention of the target title. */
export function buildBacklinkSnippet(html: string, target: string): string {
  const plain = stripHtml(html);
  if (!plain) return "";
  const norm = normalizeTitle(target);
  if (!norm) return plain.slice(0, 120);
  // find the mention position in plain text
  const re = new RegExp(
    `@(?:${norm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}|"[^"]*${norm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}[^"]*")`,
    "i"
  );
  const m = plain.match(re);
  const i = m?.index ?? -1;
  if (i === -1) return plain.slice(0, 120);
  const start = Math.max(0, i - 40);
  const end = Math.min(plain.length, i + (m?.[0].length ?? target.length) + 80);
  return (start > 0 ? "…" : "") + plain.slice(start, end) + (end < plain.length ? "…" : "");
}

// Backwards-compat aliases (older code used wiki-link names).
export const findWikiLinks = findMentions;
