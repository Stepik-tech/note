import ZAI from 'z-ai-web-dev-sdk'

let zaiPromise: Promise<ZAI> | null = null

export async function getAI(): Promise<ZAI> {
  if (!zaiPromise) {
    zaiPromise = ZAI.create()
  }
  return zaiPromise
}

/** Ask the LLM for a text completion. */
export async function aiComplete(
  system: string,
  user: string,
  opts: { json?: boolean; temperature?: number } = {}
): Promise<string> {
  const ai = await getAI()
  const res = await ai.chat.completions.create({
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user },
    ],
    temperature: opts.temperature ?? 0.3,
    ...(opts.json ? { response_format: { type: 'json_object' } } : {}),
  })
  const content: string =
    res?.choices?.[0]?.message?.content ?? res?.choices?.[0]?.delta?.content ?? ''
  return content.trim()
}

/** Safely parse JSON out of an LLM response (handles ```json fences). */
export function extractJSON<T = unknown>(raw: string): T | null {
  if (!raw) return null
  let s = raw.trim()
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fence) s = fence[1].trim()
  const first = s.indexOf('{')
  const last = s.lastIndexOf('}')
  if (first !== -1 && last !== -1 && last > first) {
    s = s.slice(first, last + 1)
  }
  try {
    return JSON.parse(s) as T
  } catch {
    return null
  }
}
