export type FolderDTO = {
  id: number;
  name: string;
  color: string;
  icon: string;
  position: number;
  createdAt: string;
  noteCount: number;
};

export type NoteDTO = {
  id: number;
  folderId: number | null;
  title: string;
  content: string;
  color: string;
  tags: string[];
  pinned: boolean;
  favorite: boolean;
  archived: boolean;
  trashed: boolean;
  position: number;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
};

export type ViewKey = "all" | "favorites" | "pinned" | "archive" | "trash";

export type SortKey = "updated-desc" | "created-desc" | "title-asc" | "title-desc";
