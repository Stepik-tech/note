"use client";

export type ConfirmState = {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
};

export function ConfirmDialog({ state, onClose }: { state: ConfirmState | null; onClose: () => void }) {
  if (!state) return null;
  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/35 backdrop-blur-sm"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-sm rounded-xl border border-[var(--stroke)] bg-[var(--surface)] p-5 shadow-[0_20px_60px_rgba(0,0,0,0.3)] animate-[pop-in_0.16s_ease-out]">
        <h3 className="text-base font-semibold text-[var(--text)]">{state.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-[var(--text-secondary)]">{state.message}</p>
        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="rounded-md border border-[var(--stroke)] px-3.5 py-1.5 text-sm font-medium text-[var(--text)] hover:bg-[var(--hover)]"
          >
            Отмена
          </button>
          <button
            onClick={() => {
              state.onConfirm();
              onClose();
            }}
            className={
              state.danger
                ? "rounded-md bg-[#f43f5e] px-3.5 py-1.5 text-sm font-semibold text-white hover:bg-[#e11d48]"
                : "rounded-md bg-[var(--accent)] px-3.5 py-1.5 text-sm font-semibold text-white hover:opacity-90"
            }
          >
            {state.confirmLabel ?? "Подтвердить"}
          </button>
        </div>
      </div>
    </div>
  );
}
