"use client";

import { useEffect, useRef } from "react";

export type GNode = {
  id: number;
  title: string;
  color: string;
  weight: number;
};

export type GEdge = { source: number; target: number };

type SimNode = GNode & { x: number; y: number; vx: number; vy: number; r: number };

export function ForceGraph({
  nodes,
  edges,
  currentId,
  onSelect,
}: {
  nodes: GNode[];
  edges: GEdge[];
  currentId?: number | null;
  onSelect?: (id: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const simRef = useRef<SimNode[]>([]);
  const edgesRef = useRef<GEdge[]>([]);
  const transformRef = useRef({ x: 0, y: 0, k: 1 });
  const hoverRef = useRef<number | null>(null);
  const dragRef = useRef<
    | { kind: "node"; id: number; offX: number; offY: number; startX: number; startY: number; moved: boolean }
    | { kind: "pan"; startX: number; startY: number; tx: number; ty: number }
    | null
  >(null);
  const sizeRef = useRef({ w: 0, h: 0 });

  // build simulation when data changes
  useEffect(() => {
    const limit = nodes.slice(0, 400);
    const ids = new Set(limit.map((n) => n.id));
    const cx = sizeRef.current.w / 2 || 300;
    const cy = sizeRef.current.h / 2 || 200;
    simRef.current = limit.map((n, i) => {
      const angle = (i / Math.max(1, limit.length)) * Math.PI * 2;
      const radius = 70 + Math.random() * 50;
      return {
        ...n,
        x: cx + Math.cos(angle) * radius,
        y: cy + Math.sin(angle) * radius,
        vx: 0,
        vy: 0,
        r: 5 + Math.min(16, n.weight * 3),
        color: n.color || "#7c3aed",
      };
    });
    edgesRef.current = edges.filter((e) => ids.has(e.source) && ids.has(e.target));
    transformRef.current = { x: 0, y: 0, k: 1 };
  }, [nodes, edges]);

  // resize observer
  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ro = new ResizeObserver(() => {
      const rect = wrap.getBoundingClientRect();
      sizeRef.current = { w: rect.width, h: rect.height };
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = rect.width + "px";
      canvas.style.height = rect.height + "px";
      const ctx = canvas.getContext("2d");
      if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    });
    ro.observe(wrap);
    return () => ro.disconnect();
  }, []);

  // animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    const tick = () => {
      const sim = simRef.current;
      const es = edgesRef.current;
      const { w, h } = sizeRef.current;
      const cx = w / 2;
      const cy = h / 2;

      // repulsion
      for (let i = 0; i < sim.length; i++) {
        const a = sim[i];
        for (let j = i + 1; j < sim.length; j++) {
          const b = sim[j];
          let dx = a.x - b.x;
          let dy = a.y - b.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 0.01) {
            dx = Math.random() - 0.5;
            dy = Math.random() - 0.5;
            d2 = dx * dx + dy * dy + 0.01;
          }
          const d = Math.sqrt(d2);
          const f = 1200 / d2;
          const fx = (dx / d) * f;
          const fy = (dy / d) * f;
          a.vx += fx;
          a.vy += fy;
          b.vx -= fx;
          b.vy -= fy;
        }
        a.vx += (cx - a.x) * 0.004;
        a.vy += (cy - a.y) * 0.004;
      }

      // springs
      const idIdx = new Map(sim.map((n, i) => [n.id, i]));
      for (const e of es) {
        const ai = idIdx.get(e.source);
        const bi = idIdx.get(e.target);
        if (ai === undefined || bi === undefined) continue;
        const a = sim[ai];
        const b = sim[bi];
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
        const target = 80;
        const f = (d - target) * 0.02;
        const fx = (dx / d) * f;
        const fy = (dy / d) * f;
        a.vx += fx;
        a.vy += fy;
        b.vx -= fx;
        b.vy -= fy;
      }

      // integrate (skip the node currently being dragged)
      for (const n of sim) {
        if (dragRef.current?.kind === "node" && dragRef.current.id === n.id) continue;
        n.vx *= 0.82;
        n.vy *= 0.82;
        n.x += n.vx;
        n.y += n.vy;
      }

      draw();
      raf = requestAnimationFrame(tick);
    };

    const draw = () => {
      const { w, h } = sizeRef.current;
      const t = transformRef.current;
      ctx.clearRect(0, 0, w, h);
      ctx.save();
      ctx.translate(t.x, t.y);
      ctx.scale(t.k, t.k);

      const sim = simRef.current;
      const es = edgesRef.current;
      const idNode = new Map(sim.map((n) => [n.id, n]));

      const accent = getCss("--accent", "#7c3aed");
      const fg = getCss("--text", "#dcdddd");

      // edges
      ctx.lineWidth = 1;
      for (const e of es) {
        const a = idNode.get(e.source);
        const b = idNode.get(e.target);
        if (!a || !b) continue;
        const hot =
          hoverRef.current === a.id ||
          hoverRef.current === b.id ||
          currentId === a.id ||
          currentId === b.id;
        ctx.strokeStyle = hot ? "rgba(124, 58, 237, 0.6)" : "rgba(141, 141, 141, 0.18)";
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }

      // nodes
      for (const n of sim) {
        const isCur = currentId === n.id;
        const isHover = hoverRef.current === n.id;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = n.color;
        ctx.globalAlpha = isCur ? 1 : isHover ? 0.95 : 0.8;
        ctx.fill();
        ctx.globalAlpha = 1;
        if (isCur || isHover) {
          ctx.lineWidth = 2;
          ctx.strokeStyle = isCur ? fg : "rgba(255,255,255,0.4)";
          ctx.stroke();
        }
        if (isHover || isCur || n.weight >= 2) {
          ctx.fillStyle = fg;
          ctx.globalAlpha = isHover || isCur ? 1 : 0.75;
          ctx.font = `${isHover || isCur ? 600 : 400} 11px var(--font-ui, sans-serif)`;
          ctx.textAlign = "center";
          ctx.fillText(trunc(n.title, 22), n.x, n.y + n.r + 12);
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
    };

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [currentId]);

  // ---- pointer interactions ----
  const toWorld = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const t = transformRef.current;
    return {
      x: (clientX - rect.left - t.x) / t.k,
      y: (clientY - rect.top - t.y) / t.k,
    };
  };
  const findNode = (wx: number, wy: number): SimNode | null => {
    for (const n of simRef.current) {
      const dx = n.x - wx;
      const dy = n.y - wy;
      if (dx * dx + dy * dy <= (n.r + 5) ** 2) return n;
    }
    return null;
  };

  const onDown = (e: React.PointerEvent) => {
    const canvas = canvasRef.current!;
    canvas.setPointerCapture(e.pointerId);
    const w = toWorld(e.clientX, e.clientY);
    const node = findNode(w.x, w.y);
    if (node) {
      dragRef.current = {
        kind: "node",
        id: node.id,
        offX: w.x - node.x,
        offY: w.y - node.y,
        startX: e.clientX,
        startY: e.clientY,
        moved: false,
      };
    } else {
      dragRef.current = {
        kind: "pan",
        startX: e.clientX,
        startY: e.clientY,
        tx: transformRef.current.x,
        ty: transformRef.current.y,
      };
    }
  };
  const onMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d) {
      const w = toWorld(e.clientX, e.clientY);
      const n = findNode(w.x, w.y);
      hoverRef.current = n?.id ?? null;
      const canvas = canvasRef.current!;
      canvas.style.cursor = n ? "pointer" : "grab";
      return;
    }
    // threshold: if pointer moved > 4px, mark as drag (not click)
    if (d.kind === "node") {
      const dx = e.clientX - d.startX;
      const dy = e.clientY - d.startY;
      if (dx * dx + dy * dy > 16) d.moved = true;
    }
    if (d.kind === "pan") {
      transformRef.current.x = d.tx + (e.clientX - d.startX);
      transformRef.current.y = d.ty + (e.clientY - d.startY);
    } else if (d.moved) {
      const w = toWorld(e.clientX, e.clientY);
      const node = simRef.current.find((n) => n.id === d.id);
      if (node) {
        node.x = w.x - d.offX;
        node.y = w.y - d.offY;
        node.vx = 0;
        node.vy = 0;
      }
    }
  };
  const onUp = (e: React.PointerEvent) => {
    const canvas = canvasRef.current!;
    canvas.releasePointerCapture(e.pointerId);
    const d = dragRef.current;
    dragRef.current = null;
    // Only open the note if this was a click (no significant movement).
    if (d?.kind === "node" && !d.moved && onSelect) {
      const w = toWorld(e.clientX, e.clientY);
      const node = findNode(w.x, w.y);
      if (node) onSelect(node.id);
    }
  };

  // wheel zoom via native listener so we can preventDefault (React's onWheel is passive)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const t = transformRef.current;
      const factor = e.deltaY > 0 ? 0.9 : 1.1;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const wx = (mx - t.x) / t.k;
      const wy = (my - t.y) / t.k;
      t.k = Math.max(0.2, Math.min(4, t.k * factor));
      t.x = mx - wx * t.k;
      t.y = my - wy * t.k;
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => canvas.removeEventListener("wheel", onWheel);
  }, []);

  return (
    <div ref={wrapRef} style={{ width: "100%", height: "100%", position: "relative" }}>
      <canvas
        ref={canvasRef}
        className="graph-canvas"
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
      />
    </div>
  );
}

function trunc(s: string, n: number) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
function getCss(name: string, fallback: string): string {
  if (typeof window === "undefined") return fallback;
  const v = getComputedStyle(document.documentElement).getPropertyValue(name);
  return v || fallback;
}
