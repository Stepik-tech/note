import type { SVGProps } from "react";

/**
 * Microsoft Fluent-style line icons for folders.
 * Used instead of emoji to give the app a professional, sellable look.
 * Color is inherited via `color` (use style={{ color: folder.color }}).
 */

type IconProps = SVGProps<SVGSVGElement> & { size?: number };

function base({ size = 16, ...props }: IconProps) {
  return {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    ...props,
  };
}

export const FolderIcons = {
  folder: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z" />
    </svg>
  ),
  star: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m12 3 2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6Z" />
    </svg>
  ),
  briefcase: (p: IconProps) => (
    <svg {...base(p)}>
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 12h18" />
    </svg>
  ),
  book: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2Z" />
      <path d="M4 19a2 2 0 0 0 2 2h13" />
    </svg>
  ),
  home: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m3 10 9-7 9 7v9a2 2 0 0 1-2 2h-3v-6H8v6H5a2 2 0 0 1-2-2Z" />
    </svg>
  ),
  bulb: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.2 1 2.5h6c0-1.3.3-1.8 1-2.5A6 6 0 0 0 12 3Z" />
    </svg>
  ),
  target: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
    </svg>
  ),
  receipt: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M5 21V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v17l-2-1.2L15 21l-2-1.2L11 21l-2-1.2L7 21l-2-1.2Z" />
      <path d="M8 7h8M8 11h8M8 15h5" />
    </svg>
  ),
  palette: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 3a9 9 0 1 0 0 18c1 0 1.5-.8 1.5-1.6 0-1.3-1-1.4-1-2.4 0-.8.7-1.5 1.5-1.5H16a5 5 0 0 0 5-5c0-3.9-4-7.5-9-7.5Z" />
      <circle cx="7.5" cy="11" r="1" fill="currentColor" stroke="none" />
      <circle cx="12" cy="7.5" r="1" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="11" r="1" fill="currentColor" stroke="none" />
    </svg>
  ),
  cart: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="9" cy="20" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="17" cy="20" r="1.4" fill="currentColor" stroke="none" />
      <path d="M3 4h2l2.5 12h11l2-8H6" />
    </svg>
  ),
  plane: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M21 4 3 11l6 2 2 6 3-5 4 3 3-13Z" />
      <path d="m9 13 5-5" />
    </svg>
  ),
  grad: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m12 4 10 5-10 5L2 9Z" />
      <path d="M6 11v4c0 1.5 2.7 3 6 3s6-1.5 6-3v-4M22 9v5" />
    </svg>
  ),
} as const;

export type FolderIconName = keyof typeof FolderIcons;

export const FOLDER_ICON_NAMES: FolderIconName[] = [
  "folder",
  "star",
  "briefcase",
  "book",
  "home",
  "bulb",
  "target",
  "receipt",
  "palette",
  "cart",
  "plane",
  "grad",
];

/** Render a folder icon by name. Falls back to generic folder. */
export function FolderIcon({
  name,
  size = 16,
  className,
  style,
}: {
  name: string;
  size?: number;
  className?: string;
  style?: React.CSSProperties;
}) {
  const Cmp = (FolderIcons as Record<string, (p: IconProps) => JSX.Element>)[name] ?? FolderIcons.folder;
  return <Cmp size={size} className={className} style={style} />;
}
