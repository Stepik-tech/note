"use client";

import { ConfirmDialog, type ConfirmState } from "@/components/ConfirmDialog";
import { ContextMenu, type MenuAction } from "@/components/ContextMenu";
import { EditorPane } from "@/components/EditorPane";
import { Icon } from "@/components/icons";
import { NoteList } from "@/components/NoteList";
import { SettingsPanel } from "@/components/SettingsPanel";
import { Sidebar } from "@/components/Sidebar";
import { Toasts, type ToastItem } from "@/components/Toasts";
import { BacklinksBar, type Backlink } from "@/components/BacklinksPanel";
import { GraphModal, type GraphData } from "@/components/GraphModal";
import { ErrorCaptureModal } from "@/components/ErrorCaptureModal";
import { Landing } from "@/components/Landing";
import { computeOutLinks } from "@/lib/out-links";
import type { FolderDTO, NoteDTO, SortKey, ViewKey } from "@/lib/types";
import { debounce, htmlToPlainText, wordStats } from "@/lib/utils";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

let toastSeq = 1;

export default function NotesApp() {
  const [view, setView] = useState<"landing" | "app">("landing");
  const [folders, setFolders] = useState<FolderDTO[]>([]);
  const [notes, setNotes] = useState<NoteDTO[]>([]);
  const [loaded, setLoaded] = useState(false);

  const [activeView, setActiveView] = useState<ViewKey>("all");
  const [activeFolderId, setActiveFolderId] = useState<number | null>(null);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("updated-desc");
  const [listMode, setListMode] = useState<"list" | "grid">("list");

  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);
  const [draft, setDraft] = useState({ title: "", content: "" });
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved">("idle");
  const skipNextAutosave = useRef(true);

  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [accent, setAccent] = useState("#0078d4");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [confirmState, setConfirmState] = useState<ConfirmState | null>(null);
  const [menu, setMenu] = useState<{ x: number; y: number; noteId: number } | null>(null);

  // Backlinks + graph + error capture + semantic search
  const [backlinks, setBacklinks] = useState<Backlink[]>([]);
  const [graphData, setGraphData] = useState<GraphData | null>(null);
  const [graphOpen, setGraphOpen] = useState(false);
  const [errorCaptureOpen, setErrorCaptureOpen] = useState(false);
  const [semantic, setSemantic] = useState(false);
  const [semanticLoading, setSemanticLoading] = useState(false);
  const [semanticIds, setSemanticIds] = useState<Set<number> | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const editorRef = useRef<HTMLDivElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  const pushToast = useCallback((message: string, opts?: Partial<ToastItem>) => {
    const id = toastSeq++;
    setToasts((prev) => [...prev, { id, message, ...opts }]);
    window.setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 5000);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((prev) => prev.filter((t) => t.id !== id)), []);

  // ---------- Initial load ----------
  useEffect(() => {
    const savedTheme = (localStorage.getItem("notes-theme") as "light" | "dark" | null) ?? "light";
    setTheme(savedTheme);
    document.documentElement.dataset.theme = savedTheme;

    (async () => {
      try {
        const [foldersRes, notesRes] = await Promise.all([fetch("/api/folders"), fetch("/api/notes")]);
        const foldersData = await foldersRes.json();
        const notesData = await notesRes.json();
        setFolders(foldersData);
        setNotes(notesData);
      } catch {
        pushToast("Не удалось загрузить данные", { tone: "danger" });
      } finally {
        setLoaded(true);
      }
    })();
  }, [pushToast]);

  function toggleTheme() {
    const next = theme === "light" ? "dark" : "light";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    localStorage.setItem("notes-theme", next);
  }
  function setAccentColor(color: string) {
    setAccent(color);
    document.documentElement.style.setProperty("--accent", color);
    localStorage.setItem("notes-accent", color);
  }

  // ---------- Derived data ----------
  const selectedNote = useMemo(() => notes.find((n) => n.id === selectedNoteId) ?? null, [notes, selectedNoteId]);

  const filteredNotes = useMemo(() => {
    let list = notes.slice();
    if (activeFolderId !== null) {
      list = list.filter((n) => n.folderId === activeFolderId && !n.trashed && !n.archived);
    } else if (activeView === "trash") {
      list = list.filter((n) => n.trashed);
    } else {
      list = list.filter((n) => !n.trashed);
      if (activeView === "favorites") list = list.filter((n) => n.favorite && !n.archived);
      else if (activeView === "pinned") list = list.filter((n) => n.pinned && !n.archived);
      else if (activeView === "archive") list = list.filter((n) => n.archived);
      else list = list.filter((n) => !n.archived);
    }

    if (activeTag) list = list.filter((n) => n.tags.includes(activeTag));

    if (semanticIds) {
      // semantic search: keep only matched ids, in ranked order
      const orderArr = [...semanticIds];
      list = list
        .filter((n) => semanticIds.has(n.id))
        .sort((a, b) => orderArr.indexOf(a.id) - orderArr.indexOf(b.id));
    } else if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter(
        (n) => n.title.toLowerCase().includes(q) || htmlToPlainText(n.content).toLowerCase().includes(q)
      );
    }

    list.sort((a, b) => {
      if (activeView !== "trash" && a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      switch (sortKey) {
        case "created-desc":
          return +new Date(b.createdAt) - +new Date(a.createdAt);
        case "title-asc":
          return a.title.localeCompare(b.title, "ru");
        case "title-desc":
          return b.title.localeCompare(a.title, "ru");
        default:
          return +new Date(activeView === "trash" ? (b.deletedAt ?? b.updatedAt) : b.updatedAt) -
            +new Date(activeView === "trash" ? (a.deletedAt ?? a.updatedAt) : a.updatedAt);
      }
    });

    return list;
  }, [notes, activeFolderId, activeView, activeTag, searchQuery, sortKey, semanticIds]);

  const viewCounts = useMemo(
    () => ({
      all: notes.filter((n) => !n.trashed && !n.archived).length,
      favorites: notes.filter((n) => n.favorite && !n.trashed && !n.archived).length,
      pinned: notes.filter((n) => n.pinned && !n.trashed && !n.archived).length,
      archive: notes.filter((n) => n.archived && !n.trashed).length,
      trash: notes.filter((n) => n.trashed).length,
    }),
    [notes]
  );

  const folderCounts = useMemo(() => {
    const map: Record<number, number> = {};
    for (const n of notes) {
      if (n.trashed || n.archived || n.folderId === null) continue;
      map[n.folderId] = (map[n.folderId] ?? 0) + 1;
    }
    return map;
  }, [notes]);

  const tagList = useMemo(() => {
    const map = new Map<string, number>();
    for (const n of notes) {
      if (n.trashed) continue;
      for (const t of n.tags) map.set(t, (map.get(t) ?? 0) + 1);
    }
    return Array.from(map.entries())
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);
  }, [notes]);

  const stats = useMemo(() => {
    const live = notes.filter((n) => !n.trashed);
    const totalWords = live.reduce((acc, n) => acc + wordStats(n.content).words, 0);
    return { totalNotes: live.length, totalFolders: folders.length, totalWords };
  }, [notes, folders]);

  const listTitle = useMemo(() => {
    if (activeFolderId !== null) return folders.find((f) => f.id === activeFolderId)?.name ?? "Папка";
    if (activeTag) return `#${activeTag}`;
    switch (activeView) {
      case "favorites": return "Избранное";
      case "pinned": return "Закреплённые";
      case "archive": return "Архив";
      case "trash": return "Корзина";
      default: return "Все заметки";
    }
  }, [activeView, activeFolderId, activeTag, folders]);

  // ---------- Autosave ----------
  useEffect(() => {
    if (selectedNote) {
      setDraft({ title: selectedNote.title, content: selectedNote.content });
      skipNextAutosave.current = true;
      setSaveStatus("idle");
    }
  }, [selectedNote?.id]);

  // Backlinks: load when selected note changes
  useEffect(() => {
    if (!selectedNoteId) { setBacklinks([]); return; }
    let alive = true;
    (async () => {
      try {
        const res = await fetch(`/api/notes/${selectedNoteId}/backlinks`);
        const data = await res.json();
        if (alive) setBacklinks(data.backlinks ?? []);
      } catch { if (alive) setBacklinks([]); }
    })();
    return () => { alive = false; };
  }, [selectedNoteId, notes]);

  const outLinks = useMemo(() => computeOutLinks(draft.content, notes), [draft.content, notes]);

  useEffect(() => {
    if (!selectedNote) return;
    if (skipNextAutosave.current) { skipNextAutosave.current = false; return; }
    setSaveStatus("saving");
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/notes/${selectedNote.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: draft.title, content: draft.content }),
        });
        const updated = await res.json();
        setNotes((prev) => prev.map((n) => (n.id === updated.id ? updated : n)));
        setSaveStatus("saved");
      } catch {
        pushToast("Не удалось сохранить изменения", { tone: "danger" });
      }
    }, 600);
    return () => clearTimeout(t);
  }, [draft]);

  // Semantic search: debounced fetch when semantic mode is on
  useEffect(() => {
    if (!semantic || !searchQuery.trim()) {
      setSemanticIds(null);
      setSemanticLoading(false);
      return;
    }
    setSemanticLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch("/api/ai/semantic-search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: searchQuery }),
        });
        const data = await res.json();
        setSemanticIds(new Set((data.ids ?? []).map((id: number) => id)));
      } catch {
        setSemanticIds(null);
      } finally {
        setSemanticLoading(false);
      }
    }, 500);
    return () => clearTimeout(t);
  }, [searchQuery, semantic]);

  // ---------- Generic API helpers ----------
  async function patchNote(id: number, patch: Record<string, unknown>) {
    setNotes((prev) => prev.map((n) => (n.id === id ? { ...n, ...patch } as NoteDTO : n)));
    try {
      const res = await fetch(`/api/notes/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const updated = await res.json();
      setNotes((prev) => prev.map((n) => (n.id === id ? updated : n)));
      return updated as NoteDTO;
    } catch {
      pushToast("Ошибка сохранения", { tone: "danger" });
      return null;
    }
  }

  async function createNote(folderId: number | null = activeFolderId) {
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folderId, title: "", content: "" }),
      });
      const created: NoteDTO = await res.json();
      setNotes((prev) => [created, ...prev]);
      setSelectedNoteId(created.id);
      setActiveView("all");
      if (activeTag) setActiveTag(null);
      pushToast("Новая заметка создана", { tone: "success" });
      setTimeout(() => editorRef.current?.focus(), 50);
    } catch {
      pushToast("Не удалось создать заметку", { tone: "danger" });
    }
  }

  async function createNoteByTitle(title: string, content = "") {
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folderId: activeFolderId, title, content }),
      });
      const created: NoteDTO = await res.json();
      setNotes((prev) => [created, ...prev]);
      setSelectedNoteId(created.id);
      pushToast(`Создана заметка «${title}»`, { tone: "success" });
      setTimeout(() => editorRef.current?.focus(), 50);
    } catch {
      pushToast("Не удалось создать заметку", { tone: "danger" });
    }
  }

  async function createFromError(data: { title: string; content: string; tags: string[] }) {
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folderId: activeFolderId, ...data }),
      });
      const created: NoteDTO = await res.json();
      setNotes((prev) => [created, ...prev]);
      setSelectedNoteId(created.id);
      pushToast("Заметка об ошибке сохранена", { tone: "success" });
      setTimeout(() => editorRef.current?.focus(), 50);
    } catch {
      pushToast("Не удалось сохранить", { tone: "danger" });
    }
  }

  async function softDeleteNote(id: number) {
    const res = await fetch(`/api/notes/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.permanent) {
      setNotes((prev) => prev.filter((n) => n.id !== id));
      pushToast("Заметка удалена навсегда", { tone: "danger" });
    } else {
      setNotes((prev) => prev.map((n) => (n.id === id ? data.note : n)));
      if (selectedNoteId === id) setSelectedNoteId(null);
      pushToast("Заметка перемещена в корзину", {
        actionLabel: "Отменить",
        onAction: () => restoreNote(id),
      });
    }
  }

  async function restoreNote(id: number) {
    const res = await fetch(`/api/notes/${id}/restore`, { method: "POST" });
    const updated = await res.json();
    setNotes((prev) => prev.map((n) => (n.id === id ? updated : n)));
    pushToast("Заметка восстановлена", { tone: "success" });
  }

  function permanentDeleteNote(id: number) {
    setConfirmState({
      title: "Удалить навсегда?",
      message: "Это действие нельзя отменить. Заметка будет удалена безвозвратно.",
      confirmLabel: "Удалить",
      danger: true,
      onConfirm: async () => {
        await fetch(`/api/notes/${id}`, { method: "DELETE" });
        setNotes((prev) => prev.filter((n) => n.id !== id));
        if (selectedNoteId === id) setSelectedNoteId(null);
        pushToast("Заметка удалена навсегда", { tone: "danger" });
      },
    });
  }

  async function duplicateNote(id: number) {
    const res = await fetch(`/api/notes/${id}/duplicate`, { method: "POST" });
    const created: NoteDTO = await res.json();
    setNotes((prev) => [created, ...prev]);
    setSelectedNoteId(created.id);
    pushToast("Заметка продублирована", { tone: "success" });
  }

  async function copyNote(note: NoteDTO) {
    const text = `${note.title || "Без названия"}\n\n${htmlToPlainText(note.content)}`;
    try {
      await navigator.clipboard.writeText(text);
      pushToast("Текст заметки скопирован");
    } catch {
      pushToast("Не удалось скопировать", { tone: "danger" });
    }
  }

  async function copyAllVisible() {
    const text = filteredNotes
      .map((n) => `${n.title || "Без названия"}\n${htmlToPlainText(n.content)}`)
      .join("\n\n---\n\n");
    try {
      await navigator.clipboard.writeText(text || "Нет заметок для копирования");
      pushToast(`Скопировано заметок: ${filteredNotes.length}`);
    } catch {
      pushToast("Не удалось скопировать", { tone: "danger" });
    }
  }

  function exportSingleNote(note: NoteDTO) {
    const text = `${note.title || "Без названия"}\n\n${htmlToPlainText(note.content)}`;
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(note.title || "note").slice(0, 60)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportAll(format: "json" | "txt") {
    window.open(`/api/notes/export?format=${format}`, "_blank");
  }

  function triggerImport() { importInputRef.current?.click(); }

  async function handleImportFile(file: File) {
    const text = await file.text();
    const payload: { notes?: unknown[]; text?: string; folderId?: number | null } = file.name.endsWith(".json")
      ? safeParseJson(text) ?? { text }
      : { text };
    try {
      const res = await fetch("/api/notes/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.notes) {
        setNotes((prev) => [...data.notes, ...prev]);
        pushToast(`Импортировано заметок: ${data.count}`, { tone: "success" });
      } else {
        pushToast("Не удалось импортировать файл", { tone: "danger" });
      }
    } catch {
      pushToast("Ошибка импорта", { tone: "danger" });
    }
  }

  function safeParseJson(text: string): { notes?: unknown[]; text?: string } | null {
    try {
      const parsed = JSON.parse(text);
      return Array.isArray(parsed) ? { notes: parsed } : parsed;
    } catch {
      return { text };
    }
  }

  function emptyTrash() {
    setConfirmState({
      title: "Очистить корзину?",
      message: "Все заметки в корзине будут удалены безвозвратно.",
      confirmLabel: "Очистить",
      danger: true,
      onConfirm: async () => {
        await fetch("/api/notes/trash/empty", { method: "POST" });
        setNotes((prev) => prev.filter((n) => !n.trashed));
        pushToast("Корзина очищена", { tone: "danger" });
      },
    });
  }

  // ---------- Folder handlers ----------
  async function createFolder() {
    // Auto-assign a different color based on existing folder count (Microsoft palette)
    const colors = ["#0078d4", "#107c10", "#d13438", "#5c2d91", "#ca5010", "#008575", "#b4009e", "#038387"];
    const icons = ["folder", "briefcase", "home", "bulb", "book", "target", "star", "receipt"];
    const idx = folders.length;
    const color = colors[idx % colors.length];
    const icon = icons[idx % icons.length];
    const res = await fetch("/api/folders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "Новая папка", icon, color }),
    });
    const created: FolderDTO = await res.json();
    setFolders((prev) => [...prev, created]);
    pushToast("Папка создана", { tone: "success" });
  }

  async function renameFolder(id: number, name: string) {
    setFolders((prev) => prev.map((f) => (f.id === id ? { ...f, name } : f)));
    await fetch(`/api/folders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
  }

  function deleteFolder(id: number) {
    const folder = folders.find((f) => f.id === id);
    setConfirmState({
      title: "Удалить папку?",
      message: `Папка «${folder?.name ?? ""}» будет удалена. Заметки останутся без папки.`,
      confirmLabel: "Удалить",
      danger: true,
      onConfirm: async () => {
        await fetch(`/api/folders/${id}`, { method: "DELETE" });
        setFolders((prev) => prev.filter((f) => f.id !== id));
        setNotes((prev) => prev.map((n) => (n.folderId === id ? { ...n, folderId: null } : n)));
        if (activeFolderId === id) setActiveFolderId(null);
        pushToast("Папка удалена", { tone: "danger" });
      },
    });
  }

  async function setFolderStyle(id: number, patch: { color?: string; icon?: string }) {
    setFolders((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f)));
    await fetch(`/api/folders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
  }

  async function reorderFolders(order: number[]) {
    setFolders((prev) => {
      const map = new Map(prev.map((f) => [f.id, f]));
      return order.map((id, i) => ({ ...map.get(id)!, position: i }));
    });
    await fetch("/api/folders/reorder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ order }),
    });
  }

  async function moveNoteToFolder(noteId: number, folderId: number | null) {
    const updated = await patchNote(noteId, { folderId });
    if (updated) pushToast("Заметка перемещена");
  }

  // ---------- Keyboard shortcuts ----------
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement)?.isContentEditable;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        createNote();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        searchInputRef.current?.focus();
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        pushToast("Автосохранение включено — всё уже сохранено");
      } else if (e.key === "Escape") {
        setSettingsOpen(false);
        setMenu(null);
        setErrorCaptureOpen(false);
      } else if (e.key === "Delete" && selectedNote && !typing) {
        softDeleteNote(selectedNote.id);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [selectedNote, activeFolderId]);

  function buildContextActions(noteId: number): MenuAction[] {
    const note = notes.find((n) => n.id === noteId);
    if (!note) return [];
    if (note.trashed) {
      return [
        { label: "Восстановить", icon: <Icon.Undo className="h-4 w-4" />, onClick: () => restoreNote(noteId) },
        { label: "Удалить навсегда", icon: <Icon.Trash className="h-4 w-4" />, danger: true, onClick: () => permanentDeleteNote(noteId) },
      ];
    }
    return [
      { label: note.pinned ? "Открепить" : "Закрепить", icon: <Icon.Pin className="h-4 w-4" />, onClick: () => patchNote(noteId, { pinned: !note.pinned }) },
      { label: note.favorite ? "Убрать из избранного" : "В избранное", icon: <Icon.Star className="h-4 w-4" />, onClick: () => patchNote(noteId, { favorite: !note.favorite }) },
      { label: note.archived ? "Из архива" : "В архив", icon: <Icon.Archive className="h-4 w-4" />, onClick: () => patchNote(noteId, { archived: !note.archived }) },
      { label: "Дублировать", icon: <Icon.Copy className="h-4 w-4" />, onClick: () => duplicateNote(noteId), divider: true },
      { label: "Скопировать текст", icon: <Icon.Copy className="h-4 w-4" />, onClick: () => copyNote(note) },
      { label: "Скачать .txt", icon: <Icon.Download className="h-4 w-4" />, onClick: () => exportSingleNote(note) },
      { label: "Удалить", icon: <Icon.Trash className="h-4 w-4" />, danger: true, onClick: () => softDeleteNote(noteId), divider: true },
    ];
  }

  // ---------- Graph ----------
  async function openGraph() {
    setGraphOpen(true);
    if (!graphData) {
      try {
        const res = await fetch("/api/graph");
        const data = await res.json();
        setGraphData(data);
      } catch {
        pushToast("Не удалось загрузить граф", { tone: "danger" });
      }
    }
  }
  async function refreshGraph() {
    try {
      const res = await fetch("/api/graph");
      const data = await res.json();
      setGraphData(data);
    } catch {}
  }

  if (!loaded) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[var(--bg)]">
        <div className="flex items-center gap-3 text-[var(--text-secondary)]">
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-[var(--accent)] border-t-transparent" />
          Загрузка заметок…
        </div>
      </div>
    );
  }

  // Mobile: show editor full-screen when a note is selected, otherwise list+sidebar.
  const mobileEditorMode = selectedNote !== null;

  if (view === "landing") {
    return <Landing onOpenApp={() => setView("app")} />;
  }

  return (
    <div className="flex h-[100dvh] w-screen overflow-hidden bg-[var(--bg)]">
      <Sidebar
        folders={folders}
        folderCounts={folderCounts}
        viewCounts={viewCounts}
        tags={tagList}
        activeView={activeView}
        activeFolderId={activeFolderId}
        activeTag={activeTag}
        theme={theme}
        onToggleTheme={toggleTheme}
        onSelectView={(v) => {
          setActiveView(v);
          setActiveFolderId(null);
          setMobileSidebarOpen(false);
        }}
        onSelectFolder={(id) => {
          setActiveFolderId(id);
          setActiveView("all");
          setMobileSidebarOpen(false);
        }}
        onSelectTag={setActiveTag}
        onCreateFolder={createFolder}
        onRenameFolder={renameFolder}
        onDeleteFolder={deleteFolder}
        onSetFolderStyle={setFolderStyle}
        onReorderFolders={reorderFolders}
        onDropNoteOnFolder={moveNoteToFolder}
        onOpenSettings={() => setSettingsOpen(true)}
        onBackHome={() => setView("landing")}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      <div className={mobileEditorMode ? "hidden min-w-0 flex-1 md:flex" : "flex min-w-0 flex-1"}>
        <button
          onClick={() => setMobileSidebarOpen(true)}
          className="fixed left-2 top-2 z-20 grid h-7 w-7 place-items-center rounded-md border border-[var(--stroke)] bg-[var(--surface)] shadow-sm md:hidden"
        >
          <Icon.Menu className="h-3.5 w-3.5" />
        </button>

        <NoteList
          notes={filteredNotes}
          folders={folders}
          selectedNoteId={selectedNoteId}
          activeView={activeView}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchInputRef={searchInputRef}
          sortKey={sortKey}
          onSortChange={setSortKey}
          listMode={listMode}
          onListModeChange={setListMode}
          onSelect={setSelectedNoteId}
          onCreateNote={() => createNote()}
          onCopyAll={copyAllVisible}
          onExportAll={exportAll}
          onImportClick={triggerImport}
          onContextMenu={(e, id) => setMenu({ x: e.clientX, y: e.clientY, noteId: id })}
          title={listTitle}
          semantic={semantic}
          onToggleSemantic={() => {
            setSemantic((v) => !v);
            if (semantic) setSemanticIds(null);
          }}
          semanticLoading={semanticLoading}
        />
      </div>

      {/* Editor: full-screen on mobile when a note is selected; min-h-0+overflow-hidden keeps BacklinksBar pinned to bottom */}
      <div className={mobileEditorMode ? "flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden" : "hidden min-h-0 min-w-0 flex-1 flex-col overflow-hidden md:flex"}>
        {mobileEditorMode && (
          <button
            onClick={() => setSelectedNoteId(null)}
            className="flex items-center gap-1 border-b border-[var(--stroke)] px-3 py-2 text-[12px] text-[var(--accent)] md:hidden"
          >
            <Icon.Undo className="h-3.5 w-3.5" /> К списку
          </button>
        )}
        <div className="min-h-0 flex-1 overflow-hidden">
        <EditorPane
          note={selectedNote}
          folders={folders}
          draftTitle={draft.title}
          draftContent={draft.content}
          onChangeTitle={(v) => setDraft((d) => ({ ...d, title: v }))}
          onChangeContent={(v) => setDraft((d) => ({ ...d, content: v }))}
          editorRef={editorRef}
          saveStatus={saveStatus}
          onTogglePin={() => selectedNote && patchNote(selectedNote.id, { pinned: !selectedNote.pinned })}
          onToggleFavorite={() => selectedNote && patchNote(selectedNote.id, { favorite: !selectedNote.favorite })}
          onToggleArchive={() => selectedNote && patchNote(selectedNote.id, { archived: !selectedNote.archived })}
          onDelete={() => selectedNote && softDeleteNote(selectedNote.id)}
          onRestore={() => selectedNote && restoreNote(selectedNote.id)}
          onPermanentDelete={() => selectedNote && permanentDeleteNote(selectedNote.id)}
          onDuplicate={() => selectedNote && duplicateNote(selectedNote.id)}
          onCopy={() => selectedNote && copyNote(selectedNote)}
          onExportSingle={() => selectedNote && exportSingleNote(selectedNote)}
          onPrint={() => window.print()}
          onSetColor={(color) => selectedNote && patchNote(selectedNote.id, { color })}
          onMoveFolder={(folderId) => selectedNote && patchNote(selectedNote.id, { folderId })}
          onAddTag={(tag) => selectedNote && patchNote(selectedNote.id, { tags: [...new Set([...selectedNote.tags, tag])] })}
          onRemoveTag={(tag) => selectedNote && patchNote(selectedNote.id, { tags: selectedNote.tags.filter((t) => t !== tag) })}
          stats={stats}
          onOpenGraph={openGraph}
          onOpenErrorCapture={() => setErrorCaptureOpen(true)}
          onCreateNote={() => createNote()}
        />
        </div>
        {selectedNote && !selectedNote.trashed && (
          <BacklinksBar
            backlinks={backlinks}
            outLinks={outLinks}
            content={draft.content}
            onOpenNote={(id) => setSelectedNoteId(id)}
            onCreateNote={(title) => createNoteByTitle(title)}
          />
        )}
      </div>

      {graphOpen && (
        <GraphModal
          data={graphData}
          currentId={selectedNoteId}
          onSelect={(id) => setSelectedNoteId(id)}
          onClose={() => {
            setGraphOpen(false);
            refreshGraph();
          }}
        />
      )}

      <ErrorCaptureModal
        open={errorCaptureOpen}
        onClose={() => setErrorCaptureOpen(false)}
        onOpenNote={(id) => setSelectedNoteId(id)}
        onSave={createFromError}
      />

      {menu && <ContextMenu x={menu.x} y={menu.y} actions={buildContextActions(menu.noteId)} onClose={() => setMenu(null)} />}

      <ConfirmDialog state={confirmState} onClose={() => setConfirmState(null)} />

      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        theme={theme}
        onToggleTheme={toggleTheme}
        accent={accent}
        onSetAccent={setAccentColor}
        onExportAll={exportAll}
        onImportClick={triggerImport}
        onEmptyTrash={emptyTrash}
        trashCount={viewCounts.trash}
      />

      <Toasts items={toasts} onDismiss={dismissToast} />

      <input
        ref={importInputRef}
        type="file"
        accept=".txt,.json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleImportFile(file);
          e.target.value = "";
        }}
      />
    </div>
  );
}
