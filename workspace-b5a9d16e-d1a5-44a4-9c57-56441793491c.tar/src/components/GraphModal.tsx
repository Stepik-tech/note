"use client";

import { useEffect, useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import { ForceGraph, type GNode, type GEdge } from "@/components/ForceGraph";

export type GraphData = {
  nodes: Array<{
    id: number;
    title: string;
    folderId: number | null;
    folderName: string | null;
    folderColor: string | null;
    color: string;
    weight: number;
    tags: string[];
  }>;
  edges: Array<{ source: number; target: number }>;
};

export function GraphModal({
  data,
  currentId,
  onSelect,
  onClose,
}: {
  data: GraphData | null;
  currentId: number | null;
  onSelect: (id: number) => void;
  onClose: () => void;
}) {
  const [colorBy, setColorBy] = useState<"folder" | "note">("folder");
  const [mode, setMode] = useState<"global" | "local">("global");

  // escape on Esc
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  // Local graph: current node + 1-hop neighbors (both directions)
  const localData = useMemo(() => {
    if (!data || !currentId) return { nodes: [], edges: [] };
    const neighborIds = new Set<number>([currentId]);
    const localEdges = data.edges.filter((e) => {
      if (e.source === currentId) {
        neighborIds.add(e.target);
        return true;
      }
      if (e.target === currentId) {
        neighborIds.add(e.source);
        return true;
      }
      return false;
    });
    return {
      nodes: data.nodes.filter((n) => neighborIds.has(n.id)),
      edges: localEdges,
    };
  }, [data, currentId]);

  const activeData = mode === "local" ? localData : data ?? { nodes: [], edges: [] };

  // build legend
  const legend = (() => {
    const map = new Map<string, { color: string; count: number }>();
    for (const n of activeData.nodes) {
      const key = n.folderName ?? "Без папки";
      const color = n.folderColor ?? "#8764B8";
      const prev = map.get(key);
      map.set(key, { color, count: (prev?.count ?? 0) + 1 });
    }
    return [...map.entries()].map(([name, { color, count }]) => ({ name, color, count }));
  })();

  const gNodes: GNode[] = activeData.nodes.map((n) => ({
    id: n.id,
    title: n.title,
    color: colorBy === "folder" ? (n.folderColor ?? "#8764B8") : n.color,
    weight: n.weight,
  }));
  const gEdges: GEdge[] = activeData.edges;

  const canShowLocal = !!currentId && data !== null;

  return (
    <div
      className="graph-modal-overlay"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="graph-modal">
        <div className="graph-modal-header">
          <div>
            <h3 style={{ fontSize: 15, fontWeight: 600, color: "var(--text)", margin: 0 }}>
              Граф знаний
            </h3>
            <p style={{ fontSize: 11, color: "var(--text-secondary)", margin: "2px 0 0" }}>
              {data
                ? `${activeData.nodes.length} ${mode === "local" ? "связанных " : ""}заметок · ${activeData.edges.length} связей`
                : "Загрузка…"}
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {/* Global / Local toggle */}
            <div
              style={{
                display: "flex",
                border: "1px solid var(--stroke)",
                borderRadius: 6,
                padding: 2,
                background: "var(--surface-2)",
              }}
            >
              <button
                onClick={() => setMode("global")}
                disabled={!data}
                style={{
                  padding: "4px 10px",
                  fontSize: 12,
                  border: "none",
                  background: mode === "global" && data ? "var(--surface)" : "transparent",
                  borderRadius: 4,
                  fontWeight: mode === "global" ? 600 : 400,
                  color: "var(--text)",
                  cursor: data ? "pointer" : "not-allowed",
                  opacity: data ? 1 : 0.5,
                  boxShadow: mode === "global" && data ? "0 1px 2px rgba(0,0,0,0.08)" : "none",
                }}
              >
                Весь граф
              </button>
              <button
                onClick={() => canShowLocal && setMode("local")}
                disabled={!canShowLocal}
                title={canShowLocal ? "Граф текущей заметки и её соседей" : "Выберите заметку"}
                style={{
                  padding: "4px 10px",
                  fontSize: 12,
                  border: "none",
                  background: mode === "local" && canShowLocal ? "var(--surface)" : "transparent",
                  borderRadius: 4,
                  fontWeight: mode === "local" ? 600 : 400,
                  color: "var(--text)",
                  cursor: canShowLocal ? "pointer" : "not-allowed",
                  opacity: canShowLocal ? 1 : 0.5,
                  boxShadow: mode === "local" && canShowLocal ? "0 1px 2px rgba(0,0,0,0.08)" : "none",
                }}
              >
                Локальный
              </button>
            </div>
            {/* Color toggle */}
            <div
              style={{
                display: "flex",
                border: "1px solid var(--stroke)",
                borderRadius: 6,
                padding: 2,
                background: "var(--surface-2)",
              }}
            >
              <button
                onClick={() => setColorBy("folder")}
                style={{
                  padding: "4px 10px",
                  fontSize: 12,
                  border: "none",
                  background: colorBy === "folder" ? "var(--surface)" : "transparent",
                  borderRadius: 4,
                  fontWeight: colorBy === "folder" ? 600 : 400,
                  color: "var(--text)",
                  cursor: "pointer",
                  boxShadow: colorBy === "folder" ? "0 1px 2px rgba(0,0,0,0.08)" : "none",
                }}
              >
                Папки
              </button>
              <button
                onClick={() => setColorBy("note")}
                style={{
                  padding: "4px 10px",
                  fontSize: 12,
                  border: "none",
                  background: colorBy === "note" ? "var(--surface)" : "transparent",
                  borderRadius: 4,
                  fontWeight: colorBy === "note" ? 600 : 400,
                  color: "var(--text)",
                  cursor: "pointer",
                  boxShadow: colorBy === "note" ? "0 1px 2px rgba(0,0,0,0.08)" : "none",
                }}
              >
                Цвет заметки
              </button>
            </div>
            <button
              onClick={onClose}
              className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]"
              title="Закрыть"
            >
              <Icon.Close className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="graph-modal-body">
          {data ? (
            <ForceGraph
              nodes={gNodes}
              edges={gEdges}
              currentId={currentId}
              onSelect={(id) => {
                onSelect(id);
                onClose();
              }}
            />
          ) : (
            <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--text-secondary)" }}>
                <span style={{ width: 18, height: 18, border: "2px solid var(--accent)", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 0.8s linear infinite", display: "inline-block" }} />
                Загрузка графа…
              </div>
            </div>
          )}
          {mode === "local" && !canShowLocal && (
            <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}>
              <p style={{ color: "var(--text-secondary)", fontSize: 13 }}>Выберите заметку, чтобы увидеть её локальный граф</p>
            </div>
          )}
          {legend.length > 0 && (
            <div className="graph-legend">
              {legend.slice(0, 8).map((l) => (
                <div key={l.name} className="graph-legend-item">
                  <span className="graph-legend-dot" style={{ background: l.color }} />
                  <span>{l.name}</span>
                  <span style={{ opacity: 0.6 }}>{l.count}</span>
                </div>
              ))}
            </div>
          )}
          <div className="graph-hint">
            Колесо — зум · Перетаскивание — двигать · Клик по узлу — открыть
            <br />
            Размер узла = число входящих ссылок
            {mode === "local" && <br />}
            {mode === "local" && "Локальный граф: текущая заметка + её соседи (1 шаг)"}
          </div>
        </div>
      </div>
    </div>
  );
}
