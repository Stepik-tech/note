import type { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

const base = (props: IconProps) => ({
  width: 18,
  height: 18,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  ...props,
});

export const Icon = {
  Search: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="11" cy="11" r="7" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  ),
  Plus: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 5v14M5 12h14" />
    </svg>
  ),
  Folder: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z" />
    </svg>
  ),
  Notebook: (p: IconProps) => (
    <svg {...base(p)}>
      <rect x="4" y="3" width="16" height="18" rx="2" />
      <path d="M8 3v18M4 8h4M4 13h4" />
    </svg>
  ),
  Star: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m12 3 2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6Z" />
    </svg>
  ),
  Pin: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 4h6l-1 6 4 3v2h-6v5l-1 2-1-2v-5H4v-2l4-3Z" />
    </svg>
  ),
  Archive: (p: IconProps) => (
    <svg {...base(p)}>
      <rect x="3" y="4" width="18" height="4" rx="1" />
      <path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8M10 13h4" />
    </svg>
  ),
  Trash: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M4 7h16M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2m-9 0 1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13" />
      <path d="M10 11v6M14 11v6" />
    </svg>
  ),
  Tag: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12.59 2.59 20 10l-10 10-7.41-7.41a2 2 0 0 1 0-2.83L9.76 2.6a2 2 0 0 1 2.83 0Z" />
      <circle cx="8" cy="8.5" r="1.3" fill="currentColor" stroke="none" />
    </svg>
  ),
  Dots: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  ),
  Copy: (p: IconProps) => (
    <svg {...base(p)}>
      <rect x="9" y="9" width="12" height="12" rx="2" />
      <path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" />
    </svg>
  ),
  Download: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16" />
    </svg>
  ),
  Upload: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 21V9m0 0 4 4m-4-4-4 4M4 5h16" />
    </svg>
  ),
  Sun: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </svg>
  ),
  Moon: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z" />
    </svg>
  ),
  Grid: (p: IconProps) => (
    <svg {...base(p)}>
      <rect x="3" y="3" width="8" height="8" rx="1.5" />
      <rect x="13" y="3" width="8" height="8" rx="1.5" />
      <rect x="3" y="13" width="8" height="8" rx="1.5" />
      <rect x="13" y="13" width="8" height="8" rx="1.5" />
    </svg>
  ),
  List: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
    </svg>
  ),
  Bold: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M6 4h7a3.5 3.5 0 0 1 0 7H6zM6 11h8a3.5 3.5 0 0 1 0 7H6z" />
    </svg>
  ),
  Italic: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M10 4h8M6 20h8M13 4 11 20" />
    </svg>
  ),
  Underline: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M6 4v7a6 6 0 0 0 12 0V4M4 20h16" />
    </svg>
  ),
  Strike: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M5 12h14M7 7c0-1.7 2-3 5-3s5 1.2 5 3-2 2.5-5 3M7 17c0 1.7 2 3 5 3s5-1.3 5-3" />
    </svg>
  ),
  BulletList: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 6h11M9 12h11M9 18h11" />
      <circle cx="4.2" cy="6" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="4.2" cy="12" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="4.2" cy="18" r="1.1" fill="currentColor" stroke="none" />
    </svg>
  ),
  NumberList: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 6h11M9 12h11M9 18h11" />
      <path d="M4 5v3M3 5h1.5M3 11h2l-2 2.5h2M3.5 17h1.5v3M3 20h2" />
    </svg>
  ),
  Checklist: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m3 6 1.5 1.5L7 5M3 13l1.5 1.5L7 12M3 20l1.5 1.5L7 19" />
      <path d="M11 6h10M11 13h10M11 20h10" />
    </svg>
  ),
  Link: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 15 15 9M8 17l-2 2a3.5 3.5 0 0 1-5-5l3-3a3.5 3.5 0 0 1 5-0.3M16 7l2-2a3.5 3.5 0 0 1 5 5l-3 3a3.5 3.5 0 0 1-5 .3" />
    </svg>
  ),
  Highlight: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m9 11 4 4L21 7l-4-4Z" />
      <path d="M3 21v-3l6.5-6.5 3 3L6 21Z" />
    </svg>
  ),
  ClearFormat: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M6 4h12M8 4l4 16M4 20h8M15 12l6 6m0-6-6 6" />
    </svg>
  ),
  Undo: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M9 7 4 12l5 5M4 12h11a5 5 0 0 1 0 10h-1" />
    </svg>
  ),
  Redo: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m15 7 5 5-5 5M20 12H9A5 5 0 0 0 9 22h1" />
    </svg>
  ),
  Print: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2" />
      <rect x="6" y="14" width="12" height="7" />
    </svg>
  ),
  Settings: (p: IconProps) => (
    <svg {...base(p)}>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l2-1.6-2-3.4-2.4.8a7.6 7.6 0 0 0-2.6-1.5L14 2h-4l-.4 2.3a7.6 7.6 0 0 0-2.6 1.5l-2.4-.8-2 3.4 2 1.6a7.6 7.6 0 0 0 0 3l-2 1.6 2 3.4 2.4-.8a7.6 7.6 0 0 0 2.6 1.5L10 22h4l.4-2.3a7.6 7.6 0 0 0 2.6-1.5l2.4.8 2-3.4Z" />
    </svg>
  ),
  Close: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m5 5 14 14M19 5 5 19" />
    </svg>
  ),
  Menu: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M4 7h16M4 12h16M4 17h16" />
    </svg>
  ),
  Move: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 2v20M2 12h20M5 9l-3 3 3 3M19 9l3 3-3 3M9 5l3-3 3 3M9 19l3 3 3-3" />
    </svg>
  ),
  Check: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m5 13 4 4L19 7" />
    </svg>
  ),
  Sparkle: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" />
    </svg>
  ),
  Bug: (p: IconProps) => (
    <svg {...base(p)} strokeWidth={1.6}>
      {/* Body — rounded oval */}
      <ellipse cx="12" cy="13" rx="4.5" ry="6" />
      {/* Center line down the back */}
      <line x1="12" y1="7.5" x2="12" y2="18.5" />
      {/* Head */}
      <path d="M9 7.5a3 3 0 0 1 6 0" />
      {/* Antennae */}
      <path d="M9.5 5.5 8 3M14.5 5.5 16 3" />
      {/* Eyes (small dots) */}
      <circle cx="10.5" cy="6" r="0.5" fill="currentColor" stroke="none" />
      <circle cx="13.5" cy="6" r="0.5" fill="currentColor" stroke="none" />
      {/* Legs — 3 pairs */}
      <path d="M7.5 10 4 8.5M7.5 13 4 13M7.5 16 4 17.5M16.5 10 20 8.5M16.5 13 20 13M16.5 16 20 17.5" />
    </svg>
  ),
  Code: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="m8 18-6-6 6-6M16 6l6 6-6 6M14 4l-4 16" />
    </svg>
  ),
  ArrowRight: (p: IconProps) => (
    <svg {...base(p)}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  ),
};
