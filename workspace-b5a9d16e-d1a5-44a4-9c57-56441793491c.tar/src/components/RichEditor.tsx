"use client";

import { Icon } from "@/components/icons";
import { cx } from "@/lib/utils";
import { useEffect, useRef } from "react";

const TEXT_COLORS = ["#1b1b1b", "#D13438", "#CA5010", "#107C10", "#0078D4", "#8764B8"];
const HIGHLIGHT_COLORS = ["#fff4ce", "#ffe3cc", "#fde7e9", "#d7f5ec", "#dbeeff", "#e3dcff"];

function ToolbarButton({
  title,
  onClick,
  children,
}: {
  title: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={(e) => {
        e.preventDefault();
        onClick();
      }}
      className="flex h-7 w-7 items-center justify-center rounded-md text-[var(--text-secondary)] transition hover:bg-[var(--hover)] hover:text-[var(--text)] [&_svg]:h-3.5 [&_svg]:w-3.5"
    >
      {children}
    </button>
  );
}

function Divider() {
  return <span className="mx-1 h-5 w-px shrink-0 bg-[var(--stroke)]" />;
}

export function RichEditor({
  html,
  onChange,
  editorRef,
}: {
  html: string;
  onChange: (html: string) => void;
  editorRef: React.RefObject<HTMLDivElement | null>;
}) {
  const colorInputRef = useRef<HTMLInputElement>(null);
  const highlightInputRef = useRef<HTMLInputElement>(null);
  const isInternalUpdate = useRef(false);

  useEffect(() => {
    const el = editorRef.current;
    if (!el) return;
    if (isInternalUpdate.current) {
      isInternalUpdate.current = false;
      return;
    }
    if (el.innerHTML !== html) {
      el.innerHTML = html || "";
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [html]);

  function emitChange() {
    const el = editorRef.current;
    if (!el) return;
    isInternalUpdate.current = true;
    onChange(el.innerHTML);
  }

  function exec(command: string, value?: string) {
    editorRef.current?.focus();
    document.execCommand(command, false, value);
    emitChange();
  }

  function insertChecklist() {
    editorRef.current?.focus();
    document.execCommand(
      "insertHTML",
      false,
      `<div class="cl-item"><input type="checkbox" contenteditable="false" /><span>Новый пункт</span></div><p><br></p>`
    );
    emitChange();
  }

  function toggleHeading() {
    editorRef.current?.focus();
    const formatted = document.queryCommandValue("formatBlock");
    document.execCommand("formatBlock", false, formatted === "h3" ? "p" : "h3");
    emitChange();
  }

  function insertLink() {
    const url = window.prompt("Введите ссылку (URL):", "https://");
    if (!url) return;
    exec("createLink", url);
  }

  function handleContainerClick(e: React.MouseEvent<HTMLDivElement>) {
    const target = e.target as HTMLElement;
    if (target.tagName === "INPUT" && (target as HTMLInputElement).type === "checkbox") {
      const input = target as HTMLInputElement;
      window.setTimeout(() => {
        if (input.checked) input.setAttribute("checked", "");
        else input.removeAttribute("checked");
        emitChange();
      }, 0);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-0.5 border-b border-[var(--stroke)] px-1.5 py-1">
        <ToolbarButton title="Жирный (Ctrl+B)" onClick={() => exec("bold")}>
          <Icon.Bold />
        </ToolbarButton>
        <ToolbarButton title="Курсив (Ctrl+I)" onClick={() => exec("italic")}>
          <Icon.Italic />
        </ToolbarButton>
        <ToolbarButton title="Подчёркнутый (Ctrl+U)" onClick={() => exec("underline")}>
          <Icon.Underline />
        </ToolbarButton>
        <ToolbarButton title="Зачёркнутый" onClick={() => exec("strikeThrough")}>
          <Icon.Strike />
        </ToolbarButton>
        <Divider />
        <ToolbarButton title="Заголовок" onClick={toggleHeading}>
          <span className="text-[13px] font-bold">H</span>
        </ToolbarButton>
        <ToolbarButton title="Маркированный список" onClick={() => exec("insertUnorderedList")}>
          <Icon.BulletList />
        </ToolbarButton>
        <ToolbarButton title="Нумерованный список" onClick={() => exec("insertOrderedList")}>
          <Icon.NumberList />
        </ToolbarButton>
        <ToolbarButton title="Список дел" onClick={insertChecklist}>
          <Icon.Checklist />
        </ToolbarButton>
        <Divider />
        <ToolbarButton title="Цвет текста" onClick={() => colorInputRef.current?.click()}>
          <span className="relative">
            <span className="text-[13px] font-bold">A</span>
            <span className="absolute -bottom-0.5 left-0 h-0.5 w-full bg-[#f43f5e]" />
          </span>
        </ToolbarButton>
        <input
          ref={colorInputRef}
          type="color"
          className="hidden"
          onChange={(e) => exec("foreColor", e.target.value)}
        />
        <div className="flex items-center gap-0.5">
          {TEXT_COLORS.map((c) => (
            <button
              key={c}
              title={c}
              onMouseDown={(e) => {
                e.preventDefault();
                exec("foreColor", c);
              }}
              className="h-3.5 w-3.5 rounded-full border border-black/10"
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
        <Divider />
        <ToolbarButton title="Маркер (выделение)" onClick={() => highlightInputRef.current?.click()}>
          <Icon.Highlight />
        </ToolbarButton>
        <input
          ref={highlightInputRef}
          type="color"
          className="hidden"
          onChange={(e) => exec("hiliteColor", e.target.value)}
        />
        <div className="flex items-center gap-0.5">
          {HIGHLIGHT_COLORS.map((c) => (
            <button
              key={c}
              title={c}
              onMouseDown={(e) => {
                e.preventDefault();
                exec("hiliteColor", c);
              }}
              className="h-3.5 w-3.5 rounded-full border border-black/10"
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
        <Divider />
        <ToolbarButton title="Вставить ссылку" onClick={insertLink}>
          <Icon.Link />
        </ToolbarButton>
        <ToolbarButton title="Очистить форматирование" onClick={() => exec("removeFormat")}>
          <Icon.ClearFormat />
        </ToolbarButton>
        <Divider />
        <ToolbarButton title="Отменить" onClick={() => exec("undo")}>
          <Icon.Undo />
        </ToolbarButton>
        <ToolbarButton title="Повторить" onClick={() => exec("redo")}>
          <Icon.Redo />
        </ToolbarButton>
      </div>
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onInput={emitChange}
        onClick={handleContainerClick}
        className={cx(
          "note-editor-content min-h-[180px] flex-1 overflow-y-auto px-5 py-3.5 text-[14px] leading-relaxed text-[var(--text)] outline-none"
        )}
        data-placeholder="Начните печатать заметку…"
      />
    </div>
  );
}
