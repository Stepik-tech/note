"use client";

import { Icon } from "@/components/icons";
import { cx } from "@/lib/utils";

const ACCENTS = [
  "#0078d4",
  "#106ebe",
  "#107c10",
  "#5c2d91",
  "#d13438",
  "#ca5010",
  "#008575",
  "#038387",
];

export function SettingsPanel({
  open,
  onClose,
  theme,
  onToggleTheme,
  accent,
  onSetAccent,
  onExportAll,
  onImportClick,
  onEmptyTrash,
  trashCount,
}: {
  open: boolean;
  onClose: () => void;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  accent: string;
  onSetAccent: (c: string) => void;
  onExportAll: (format: "json" | "txt") => void;
  onImportClick: () => void;
  onEmptyTrash: () => void;
  trashCount: number;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/35 backdrop-blur-sm" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="w-full max-w-md rounded-xl border border-[var(--stroke)] bg-[var(--surface)] p-5 shadow-[0_24px_70px_rgba(0,0,0,0.3)] animate-[pop-in_0.16s_ease-out]">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold text-[var(--text)]">Настройки</h3>
          <button onClick={onClose} className="grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]">
            <Icon.Close className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4">
          <p className="text-xs font-semibold uppercase text-[var(--text-secondary)]">Тема оформления</p>
          <div className="mt-2 flex gap-2">
            <button
              onClick={() => theme !== "light" && onToggleTheme()}
              className={cx(
                "flex flex-1 items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm",
                theme === "light" ? "border-[var(--accent)] bg-[var(--active)] text-[var(--accent)]" : "border-[var(--stroke)] text-[var(--text)]"
              )}
            >
              <Icon.Sun className="h-4 w-4" /> Светлая
            </button>
            <button
              onClick={() => theme !== "dark" && onToggleTheme()}
              className={cx(
                "flex flex-1 items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm",
                theme === "dark" ? "border-[var(--accent)] bg-[var(--active)] text-[var(--accent)]" : "border-[var(--stroke)] text-[var(--text)]"
              )}
            >
              <Icon.Moon className="h-4 w-4" /> Тёмная
            </button>
          </div>
        </div>

        <div className="mt-4">
          <p className="text-xs font-semibold uppercase text-[var(--text-secondary)]">Акцентный цвет</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {ACCENTS.map((c) => (
              <button
                key={c}
                onClick={() => onSetAccent(c)}
                className={cx("h-7 w-7 rounded-full border-2", accent === c ? "border-[var(--text)]" : "border-transparent")}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>

        <div className="mt-4">
          <p className="text-xs font-semibold uppercase text-[var(--text-secondary)]">Данные</p>
          <div className="mt-2 flex flex-wrap gap-2">
            <button onClick={() => onExportAll("json")} className="flex items-center gap-1.5 rounded-md border border-[var(--stroke)] px-3 py-1.5 text-xs font-medium hover:bg-[var(--hover)]">
              <Icon.Download className="h-3.5 w-3.5" /> Бэкап JSON
            </button>
            <button onClick={() => onExportAll("txt")} className="flex items-center gap-1.5 rounded-md border border-[var(--stroke)] px-3 py-1.5 text-xs font-medium hover:bg-[var(--hover)]">
              <Icon.Download className="h-3.5 w-3.5" /> Экспорт .txt
            </button>
            <button onClick={onImportClick} className="flex items-center gap-1.5 rounded-md border border-[var(--stroke)] px-3 py-1.5 text-xs font-medium hover:bg-[var(--hover)]">
              <Icon.Upload className="h-3.5 w-3.5" /> Импорт
            </button>
          </div>
        </div>

        <div className="mt-4">
          <p className="text-xs font-semibold uppercase text-[var(--text-secondary)]">Корзина</p>
          <button
            onClick={onEmptyTrash}
            disabled={trashCount === 0}
            className="mt-2 flex items-center gap-1.5 rounded-md border border-[rgba(244,63,94,0.3)] px-3 py-1.5 text-xs font-medium text-[#f43f5e] hover:bg-[rgba(244,63,94,0.12)] disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Icon.Trash className="h-3.5 w-3.5" /> Очистить корзину ({trashCount})
          </button>
        </div>

        <p className="mt-5 text-[11px] text-[var(--text-secondary)]">
          Горячие клавиши: Ctrl+N — новая заметка, Ctrl+F — поиск, Esc — закрыть окно.
        </p>
      </div>
    </div>
  );
}
