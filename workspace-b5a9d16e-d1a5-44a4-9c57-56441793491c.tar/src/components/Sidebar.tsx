"use client";

import { Icon } from "@/components/icons";
import { FolderIcon, FOLDER_ICON_NAMES } from "@/components/folder-icons";
import type { FolderDTO, ViewKey } from "@/lib/types";
import { FOLDER_COLORS, cx } from "@/lib/utils";
import { useRef, useState } from "react";

const NOTE_DRAG_TYPE = "application/x-note-id";
const FOLDER_DRAG_TYPE = "application/x-folder-id";

type ViewCounts = Record<ViewKey, number>;

export function Sidebar({
  folders,
  folderCounts,
  viewCounts,
  tags,
  activeView,
  activeFolderId,
  activeTag,
  theme,
  onToggleTheme,
  onSelectView,
  onSelectFolder,
  onSelectTag,
  onCreateFolder,
  onRenameFolder,
  onDeleteFolder,
  onSetFolderStyle,
  onReorderFolders,
  onDropNoteOnFolder,
  onOpenSettings,
  onBackHome,
  mobileOpen,
  onCloseMobile,
}: {
  folders: FolderDTO[];
  folderCounts: Record<number, number>;
  viewCounts: ViewCounts;
  tags: { tag: string; count: number }[];
  activeView: ViewKey;
  activeFolderId: number | null;
  activeTag: string | null;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  onSelectView: (v: ViewKey) => void;
  onSelectFolder: (id: number | null) => void;
  onSelectTag: (tag: string | null) => void;
  onCreateFolder: () => void;
  onRenameFolder: (id: number, name: string) => void;
  onDeleteFolder: (id: number) => void;
  onSetFolderStyle: (id: number, patch: { color?: string; icon?: string }) => void;
  onReorderFolders: (order: number[]) => void;
  onDropNoteOnFolder: (noteId: number, folderId: number | null) => void;
  onOpenSettings: () => void;
  onBackHome?: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState("");
  const [styleMenuId, setStyleMenuId] = useState<number | null>(null);
  const dragFolderIndex = useRef<number | null>(null);
  const [overTarget, setOverTarget] = useState<string | null>(null);

  function startRename(f: FolderDTO) {
    setEditingId(f.id);
    setEditingName(f.name);
  }

  function commitRename(id: number) {
    if (editingName.trim()) onRenameFolder(id, editingName.trim());
    setEditingId(null);
  }

  function handleFolderDrop(e: React.DragEvent, folderId: number | null, index: number | null) {
    e.preventDefault();
    setOverTarget(null);
    if (e.dataTransfer.types.includes(NOTE_DRAG_TYPE)) {
      const noteId = Number(e.dataTransfer.getData(NOTE_DRAG_TYPE));
      if (!Number.isNaN(noteId)) onDropNoteOnFolder(noteId, folderId);
      return;
    }
    if (e.dataTransfer.types.includes(FOLDER_DRAG_TYPE) && index !== null && dragFolderIndex.current !== null) {
      const from = dragFolderIndex.current;
      if (from === index) return;
      const order = folders.map((f) => f.id);
      const [moved] = order.splice(from, 1);
      order.splice(index, 0, moved);
      onReorderFolders(order);
    }
  }

  const navItem = (
    key: ViewKey,
    label: string,
    icon: React.ReactNode,
    count: number
  ) => (
    <button
      key={key}
      onClick={() => onSelectView(key)}
      className={cx(
        "flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-[13px] transition",
        activeView === key && activeFolderId === null
          ? "bg-[var(--active)] font-semibold text-[var(--accent)]"
          : "text-[var(--text)] hover:bg-[var(--hover)]"
      )}
    >
      <span className="shrink-0 [&_svg]:h-3.5 [&_svg]:w-3.5">{icon}</span>
      <span className="flex-1 truncate">{label}</span>
      {count > 0 && <span className="text-[11px] text-[var(--text-secondary)]">{count}</span>}
    </button>
  );

  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/30 md:hidden" onClick={onCloseMobile} />
      )}
      <aside
        className={cx(
          "app-scroll fixed z-40 flex h-full w-[230px] shrink-0 flex-col overflow-y-auto border-r border-[var(--stroke)] bg-[var(--rail)] px-2.5 py-2.5 transition-transform md:static md:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="mb-2 flex items-center gap-1.5 px-1">
          {onBackHome && (
            <button
              onClick={onBackHome}
              title="На главную"
              className="grid h-7 w-7 shrink-0 place-items-center rounded-md text-[var(--text-secondary)] hover:bg-[var(--hover)]"
            >
              <Icon.Undo className="h-3.5 w-3.5" />
            </button>
          )}
          <div className="flex-1">
            <p className="text-[13.5px] font-semibold leading-tight text-[var(--text)]">Synapse</p>
            <p className="text-[10.5px] text-[var(--text-secondary)] leading-tight">от Microsoft 365</p>
          </div>
          <button
            onClick={onToggleTheme}
            title="Сменить тему"
            className="grid h-7 w-7 shrink-0 place-items-center rounded-md text-[var(--text-secondary)] hover:bg-[var(--hover)]"
          >
            {theme === "light" ? <Icon.Moon className="h-3.5 w-3.5" /> : <Icon.Sun className="h-3.5 w-3.5" />}
          </button>
        </div>

        <nav className="flex flex-col gap-0.5">
          {navItem("all", "Все заметки", <Icon.Notebook className="h-4 w-4" />, viewCounts.all)}
          {navItem("favorites", "Избранное", <Icon.Star className="h-4 w-4" />, viewCounts.favorites)}
          {navItem("pinned", "Закреплённые", <Icon.Pin className="h-4 w-4" />, viewCounts.pinned)}
          {navItem("archive", "Архив", <Icon.Archive className="h-4 w-4" />, viewCounts.archive)}
          {navItem("trash", "Корзина", <Icon.Trash className="h-4 w-4" />, viewCounts.trash)}
        </nav>

        <div className="mt-3 flex items-center justify-between px-1">
          <p className="text-[10.5px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">
            Папки <span className="font-normal normal-case opacity-60">· правый клик для настройки</span>
          </p>
          <button
            onClick={onCreateFolder}
            title="Новая папка"
            className="grid h-5 w-5 place-items-center rounded text-[var(--text-secondary)] hover:bg-[var(--hover)] hover:text-[var(--text)]"
          >
            <Icon.Plus className="h-3 w-3" />
          </button>
        </div>

        <ul
          className="mt-1 flex flex-col gap-0.5"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => handleFolderDrop(e, null, null)}
        >
          <li
            onDragOver={(e) => {
              e.preventDefault();
              setOverTarget("unfiled");
            }}
            onDragLeave={() => setOverTarget((v) => (v === "unfiled" ? null : v))}
            onDrop={(e) => handleFolderDrop(e, null, null)}
          >
            <button
              onClick={() => onSelectFolder(null)}
              className={cx(
                "flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-[13px] transition",
                activeFolderId === null && activeView === "all" ? "" : "",
                overTarget === "unfiled" && "ring-2 ring-[var(--accent)]",
                "text-[var(--text-secondary)] hover:bg-[var(--hover)]"
              )}
            >
              <Icon.Folder className="h-3.5 w-3.5 shrink-0" />
              <span className="flex-1 truncate italic">Без папки</span>
            </button>
          </li>
          {folders.map((f, index) => (
            <li
              key={f.id}
              draggable
              onDragStart={(e) => {
                dragFolderIndex.current = index;
                e.dataTransfer.setData(FOLDER_DRAG_TYPE, String(f.id));
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setOverTarget(`folder-${f.id}`);
              }}
              onDragLeave={() => setOverTarget((v) => (v === `folder-${f.id}` ? null : v))}
              onDrop={(e) => handleFolderDrop(e, f.id, index)}
              onContextMenu={(e) => {
                e.preventDefault();
                setStyleMenuId(styleMenuId === f.id ? null : f.id);
              }}
              className="group relative flex items-center"
            >
              {editingId === f.id ? (
                <input
                  autoFocus
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  onBlur={() => commitRename(f.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename(f.id);
                    if (e.key === "Escape") setEditingId(null);
                  }}
                  className="w-full rounded-md border border-[var(--accent)] bg-[var(--surface)] px-2 py-1 text-[13px] outline-none"
                />
              ) : (
                <button
                  onClick={() => onSelectFolder(f.id)}
                  onDoubleClick={() => startRename(f)}
                  className={cx(
                    "flex min-w-0 flex-1 items-center gap-2 rounded-md px-2 py-1 text-left text-[13px] transition",
                    activeFolderId === f.id
                      ? "bg-[var(--active)] font-semibold text-[var(--accent)]"
                      : "text-[var(--text)] hover:bg-[var(--hover)]",
                    overTarget === `folder-${f.id}` && "ring-2 ring-[var(--accent)]"
                  )}
                >
                  <FolderIcon name={f.icon} size={14} style={{ color: f.color }} className="shrink-0" />
                  <span className="min-w-0 flex-1 truncate">{f.name}</span>
                  {f.noteCount > 0 && (
                    <span className="shrink-0 text-[11px] text-[var(--text-secondary)]">
                      {folderCounts[f.id] ?? f.noteCount}
                    </span>
                  )}
                </button>
              )}

              {styleMenuId === f.id && (
                <div className="absolute right-0 top-8 z-50 w-56 rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-3 shadow-[0_12px_30px_rgba(0,0,0,0.18)]">
                  <p className="mb-1.5 text-[11px] font-semibold uppercase text-[var(--text-secondary)]">Значок</p>
                  <div className="mb-3 grid grid-cols-6 gap-1.5">
                    {FOLDER_ICON_NAMES.map((name) => (
                      <button
                        key={name}
                        onClick={() => onSetFolderStyle(f.id, { icon: name })}
                        className={cx(
                          "grid h-7 w-7 place-items-center rounded-md border hover:bg-[var(--hover)]",
                          f.icon === name ? "border-[var(--accent)]" : "border-transparent"
                        )}
                        style={{ color: f.color }}
                        title={name}
                      >
                        <FolderIcon name={name} size={14} />
                      </button>
                    ))}
                  </div>
                  <p className="mb-1.5 text-[11px] font-semibold uppercase text-[var(--text-secondary)]">Цвет</p>
                  <div className="mb-3 flex flex-wrap gap-1.5">
                    {FOLDER_COLORS.map((color) => (
                      <button
                        key={color}
                        onClick={() => onSetFolderStyle(f.id, { color })}
                        className={cx(
                          "h-6 w-6 rounded-full border-2",
                          f.color === color ? "border-[var(--text)]" : "border-transparent"
                        )}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      onDeleteFolder(f.id);
                      setStyleMenuId(null);
                    }}
                    className="flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-sm text-[#f43f5e] hover:bg-[rgba(244,63,94,0.12)]"
                  >
                    <Icon.Trash className="h-3.5 w-3.5" /> Удалить папку
                  </button>
                </div>
              )}
            </li>
          ))}
          {folders.length === 0 && (
            <li className="px-2.5 py-2 text-xs text-[var(--text-secondary)]">Папок пока нет</li>
          )}
        </ul>

        {tags.length > 0 && (
          <>
            <p className="mt-3 px-1 text-[10.5px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">Теги</p>
            <div className="mt-1 flex flex-wrap gap-1 px-1">
              {tags.map(({ tag, count }) => (
                <button
                  key={tag}
                  onClick={() => onSelectTag(activeTag === tag ? null : tag)}
                  className={cx(
                    "flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] transition",
                    activeTag === tag
                      ? "border-[var(--accent)] bg-[var(--active)] text-[var(--accent)]"
                      : "border-[var(--stroke)] text-[var(--text-secondary)] hover:bg-[var(--hover)]"
                  )}
                >
                  <Icon.Tag className="h-2.5 w-2.5" /> {tag}
                  <span className="opacity-70">{count}</span>
                </button>
              ))}
            </div>
          </>
        )}

        <div className="mt-auto pt-3">
          <button
            onClick={onOpenSettings}
            className="flex w-full items-center gap-2 rounded-md px-2 py-1 text-left text-[13px] text-[var(--text-secondary)] hover:bg-[var(--hover)]"
          >
            <Icon.Settings className="h-3.5 w-3.5" /> Настройки
          </button>
        </div>
      </aside>
    </>
  );
}
