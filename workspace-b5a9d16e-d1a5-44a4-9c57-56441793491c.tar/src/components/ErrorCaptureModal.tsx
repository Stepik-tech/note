"use client";

import { useEffect, useState } from "react";
import { Icon } from "@/components/icons";
import type { NoteDTO } from "@/lib/types";
import { cx } from "@/lib/utils";

type RelatedNote = { note: NoteDTO; reason: string };
type Parsed = {
  title: string;
  language: string | null;
  framework: string | null;
  errorType: string | null;
  file: string | null;
  line: number | null;
  tags: string[];
  summary: string;
  related: RelatedNote[];
};

export function ErrorCaptureModal({
  open,
  onClose,
  onOpenNote,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  onOpenNote: (id: number) => void;
  onSave: (data: { title: string; content: string; tags: string[] }) => void;
}) {
  const [trace, setTrace] = useState("");
  const [loading, setLoading] = useState(false);
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setTrace("");
      setParsed(null);
      setError(null);
      setLoading(false);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  async function onParse() {
    if (!trace.trim()) return;
    setLoading(true);
    setError(null);
    setParsed(null);
    try {
      const res = await fetch("/api/ai/parse-error", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trace }),
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();
      setParsed(data.parsed);
    } catch (e: any) {
      setError("Не удалось распарсить: " + String(e?.message ?? e));
    } finally {
      setLoading(false);
    }
  }

  function handleSave() {
    if (!parsed) return;
    const content = buildNoteContent(trace, parsed);
    onSave({ title: parsed.title, content, tags: parsed.tags });
    onClose();
  }

  if (!open) return null;

  return (
    <div
      className="error-modal-overlay"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="error-modal">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[var(--stroke)] px-4 py-2.5">
          <div className="flex items-center gap-2">
            <div className="grid h-7 w-7 place-items-center rounded-md bg-[var(--accent-light)] text-[var(--accent)]">
              <Icon.Bug className="h-4 w-4" />
            </div>
            <div>
              <h3 style={{ fontSize: 14, fontWeight: 600, color: "var(--text)", margin: 0 }}>
                Quick Capture для багов
              </h3>
              <p style={{ fontSize: 10.5, color: "var(--text-secondary)", margin: 0 }}>
                Вставьте ошибку — ИИ найдёт решения
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-md text-[var(--text-secondary)] hover:bg-[var(--hover)]"
          >
            <Icon.Close className="h-4 w-4" />
          </button>
        </div>

        <div className="app-scroll flex-1 overflow-y-auto">
          {/* Code-editor style input (Microsoft Fluent, no macOS traffic lights) */}
          <div className="border-b border-[var(--stroke)]">
            <div className="flex items-center gap-2 bg-[var(--surface-2)] px-3 py-1.5 border-b border-[var(--stroke)]">
              <Icon.Code className="h-3.5 w-3.5 text-[var(--accent)]" />
              <span className="text-[11px] font-medium text-[var(--text)]">error.log</span>
              <span className="ml-auto text-[10px] text-[var(--text-secondary)]">{trace.length} симв.</span>
            </div>
            <textarea
              value={trace}
              onChange={(e) => setTrace(e.target.value)}
              placeholder={"TypeError: Cannot read properties of undefined (reading 'map')\n    at Component (app/page.tsx:42:15)\n    at renderRoot (...)"}
              className="h-32 w-full resize-none bg-[var(--bg)] p-3 font-mono text-[12px] leading-relaxed text-[var(--text)] outline-none placeholder:text-[var(--text-secondary)]/50"
              style={{ fontFamily: "var(--font-mono)" }}
              spellCheck={false}
            />
          </div>

          {/* Action bar */}
          <div className="flex items-center justify-between px-3 py-2 border-b border-[var(--stroke)]">
            <span className="text-[11px] text-[var(--text-secondary)]">
              {parsed ? "Готово к сохранению" : "Нажмите для анализа"}
            </span>
            <button
              onClick={onParse}
              disabled={!trace.trim() || loading}
              className="flex items-center gap-1.5 rounded-md bg-[var(--accent)] px-3 py-1.5 text-[12px] font-medium text-white hover:opacity-90 disabled:opacity-40"
            >
              {loading ? (
                <span className="flex items-center gap-0.5">
                  <span className="semantic-dot" />
                  <span className="semantic-dot" style={{ animationDelay: '0.15s' }} />
                  <span className="semantic-dot" style={{ animationDelay: '0.3s' }} />
                </span>
              ) : (
                <Icon.Sparkle className="h-3.5 w-3.5" />
              )}
              {loading ? "Анализ…" : "Распознать"}
            </button>
          </div>

          {error && (
            <div className="m-3 rounded-md border border-[rgba(244,63,94,0.3)] bg-[rgba(244,63,94,0.08)] px-3 py-2 text-[12px] text-[#f43f5e]">
              {error}
            </div>
          )}

          {parsed && (
            <div className="p-3 space-y-3">
              {/* Parsed metadata as chips */}
              <div className="rounded-lg border border-[var(--stroke)] bg-[var(--surface-2)] p-3">
                <div className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">
                  <Icon.Sparkle className="h-3 w-3 text-[var(--accent)]" />
                  Распознано ИИ
                </div>
                <h4 className="mb-2 text-[14px] font-semibold text-[var(--text)]">{parsed.title}</h4>

                {/* Metadata chips */}
                <div className="flex flex-wrap gap-1.5">
                  {parsed.errorType && (
                    <Chip label="Тип" value={parsed.errorType} color="#f43f5e" />
                  )}
                  {parsed.language && (
                    <Chip label="Язык" value={parsed.language} color="var(--accent)" />
                  )}
                  {parsed.framework && (
                    <Chip label="Фреймворк" value={parsed.framework} color="#6366f1" />
                  )}
                  {parsed.file && (
                    <Chip
                      label="Файл"
                      value={`${parsed.file}${parsed.line ? `:${parsed.line}` : ""}`}
                      color="#f59e0b"
                      mono
                    />
                  )}
                  {parsed.tags.map((t) => (
                    <span key={t} className="rounded-full bg-[var(--hover)] px-2 py-0.5 text-[10px] text-[var(--text-secondary)]">
                      #{t}
                    </span>
                  ))}
                </div>

                {parsed.summary && (
                  <p className="mt-2 text-[12px] leading-relaxed text-[var(--text-secondary)]">
                    {parsed.summary}
                  </p>
                )}
              </div>

              {/* Related notes — "internal StackOverflow" */}
              {parsed.related.length > 0 && (
                <div className="rounded-lg border border-[var(--accent)]/40 bg-[var(--accent-light)] p-3">
                  <div className="mb-2 flex items-center gap-1.5 text-[12px] font-semibold text-[var(--accent)]">
                    <Icon.Search className="h-3.5 w-3.5" />
                    Похожие заметки ({parsed.related.length})
                  </div>
                  <div className="space-y-1.5">
                    {parsed.related.map(({ note, reason }) => (
                      <button
                        key={note.id}
                        onClick={() => {
                          onOpenNote(note.id);
                          onClose();
                        }}
                        className="block w-full rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2.5 py-1.5 text-left transition hover:border-[var(--accent)]/60"
                      >
                        <div className="truncate text-[12.5px] font-medium text-[var(--text)]">
                          {note.title || "Без названия"}
                        </div>
                        <div className="flex items-start gap-1 text-[11px] text-[var(--text-secondary)]">
                          <Icon.Sparkle className="mt-0.5 h-2.5 w-2.5 shrink-0 text-[var(--accent)]" />
                          <span>{reason}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2 border-t border-[var(--stroke)] px-3 py-2">
          <button
            onClick={onClose}
            className="rounded-md border border-[var(--stroke)] px-3 py-1.5 text-[12px] font-medium text-[var(--text)] hover:bg-[var(--hover)]"
          >
            Отмена
          </button>
          <button
            onClick={handleSave}
            disabled={!parsed}
            className="flex items-center gap-1.5 rounded-md bg-[var(--accent)] px-3 py-1.5 text-[12px] font-medium text-white hover:opacity-90 disabled:opacity-40"
          >
            <Icon.Plus className="h-3.5 w-3.5" /> Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}

function Chip({ label, value, color, mono }: { label: string; value: string; color: string; mono?: boolean }) {
  return (
    <span
      className="inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px]"
      style={{ background: color + "18", color }}
    >
      <span style={{ opacity: 0.7 }}>{label}:</span>
      <span className={cx(mono && "font-mono")} style={mono ? { fontFamily: "var(--font-mono)" } : undefined}>
        {value}
      </span>
    </span>
  );
}

function buildNoteContent(trace: string, parsed: Parsed): string {
  const meta: string[] = [];
  if (parsed.errorType) meta.push(`<p><b>Тип ошибки:</b> ${esc(parsed.errorType)}</p>`);
  if (parsed.language) meta.push(`<p><b>Язык:</b> ${esc(parsed.language)}</p>`);
  if (parsed.framework) meta.push(`<p><b>Фреймворк:</b> ${esc(parsed.framework)}</p>`);
  if (parsed.file) meta.push(`<p><b>Файл:</b> <code>${esc(parsed.file)}${parsed.line ? ":" + parsed.line : ""}</code></p>`);

  return [
    `<h3>${esc(parsed.title)}</h3>`,
    parsed.summary ? `<p>${esc(parsed.summary)}</p>` : "",
    meta.join(""),
    "<h3>Stack Trace</h3>",
    `<pre><code>${esc(trace)}</code></pre>`,
    "<h3>Решение</h3><p>...</p>",
  ].filter(Boolean).join("");
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
