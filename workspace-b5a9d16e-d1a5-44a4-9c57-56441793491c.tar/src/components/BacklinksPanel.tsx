"use client";

import { useMemo, useState } from "react";
import { Icon } from "@/components/icons";
import { cx } from "@/lib/utils";

export type Backlink = {
  fromId: number;
  fromTitle: string;
  snippet: string;
  updatedAt: string;
};

export type OutLink = {
  id: number | null;
  title: string;
  alias?: string;
};

/**
 * Compact collapsible bottom bar with three tabs:
 *  - Связи (backlinks + out-links)
 *  - Структура (H3 outline of current note)
 */
export function BacklinksBar({
  backlinks,
  outLinks,
  content,
  onOpenNote,
  onCreateNote,
}: {
  backlinks: Backlink[];
  outLinks: OutLink[];
  content: string;
  onOpenNote: (id: number) => void;
  onCreateNote: (title: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"links" | "outline">("links");
  const total = backlinks.length + outLinks.length;

  // Extract H3 headings from the HTML content for the outline
  const outline = useMemo(() => {
    if (typeof document === "undefined") {
      // server-side fallback: regex
      const matches = [...content.matchAll(/<h3[^>]*>(.*?)<\/h3>/gi)];
      return matches.map((m) => m[1].replace(/<[^>]+>/g, "").trim()).filter(Boolean);
    }
    const tmp = document.createElement("div");
    tmp.innerHTML = content || "";
    return Array.from(tmp.querySelectorAll("h3"))
      .map((h) => (h.textContent || "").trim())
      .filter(Boolean);
  }, [content]);

  return (
    <div className="border-t border-[var(--stroke)] bg-[var(--surface-2)]">
      <div className="flex items-center">
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex flex-1 items-center gap-2 px-3 py-1.5 text-left text-[11.5px] text-[var(--text-secondary)] hover:bg-[var(--hover)]"
        >
          <Icon.Link className="h-3 w-3 shrink-0" />
          <span className="font-medium text-[var(--text)]">Связи и структура</span>
          <span className="opacity-70">
            ↗ {outLinks.length} · ← {backlinks.length} · ☰ {outline.length}
          </span>
          <span className="ml-auto opacity-60">{open ? "▾" : "▸"}</span>
        </button>
      </div>

      {open && (
        <>
          {/* tabs */}
          <div className="flex gap-1 border-t border-[var(--stroke)] px-2 pt-1.5">
            <button
              onClick={() => setTab("links")}
              className={cx(
                "rounded-md px-2 py-1 text-[11px] font-medium transition",
                tab === "links"
                  ? "bg-[var(--active)] text-[var(--accent)]"
                  : "text-[var(--text-secondary)] hover:bg-[var(--hover)]"
              )}
            >
              Связи ({total})
            </button>
            <button
              onClick={() => setTab("outline")}
              className={cx(
                "rounded-md px-2 py-1 text-[11px] font-medium transition",
                tab === "outline"
                  ? "bg-[var(--active)] text-[var(--accent)]"
                  : "text-[var(--text-secondary)] hover:bg-[var(--hover)]"
              )}
            >
              Структура ({outline.length})
            </button>
          </div>

          {tab === "links" ? (
            <div className="app-scroll flex max-h-48 gap-3 overflow-y-auto px-3 py-2 text-[11.5px]">
              {/* Outgoing */}
              <div className="min-w-0 flex-1">
                <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">
                  Ссылки отсюда ({outLinks.length})
                </p>
                {outLinks.length === 0 ? (
                  <p className="text-[11px] text-[var(--text-secondary)] opacity-70">
                    Нет. Используйте <code className="rounded bg-[var(--hover)] px-1">[[Название]]</code>
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {outLinks.map((l, i) => (
                      <button
                        key={i}
                        onClick={() => (l.id !== null ? onOpenNote(l.id) : onCreateNote(l.title))}
                        className={cx(
                          "flex items-center gap-1 rounded-full border px-2 py-0.5 transition",
                          l.id === null
                            ? "border-dashed border-[var(--stroke)] text-[var(--text-secondary)] hover:border-[var(--accent)] hover:text-[var(--accent)]"
                            : "border-[var(--accent)]/30 bg-[var(--accent-light)] text-[var(--accent)] hover:bg-[var(--active)]"
                        )}
                        title={l.id === null ? "Создать заметку" : "Открыть заметку"}
                      >
                        <Icon.Link className="h-2.5 w-2.5" />
                        {l.alias || l.title}
                        {l.id === null && <span className="opacity-60">＋</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Backlinks */}
              <div className="min-w-0 flex-1 border-l border-[var(--stroke)] pl-3">
                <p className="mb-1 text-[10px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">
                  Ссылки сюда ({backlinks.length})
                </p>
                {backlinks.length === 0 ? (
                  <p className="text-[11px] text-[var(--text-secondary)] opacity-70">
                    На эту заметку пока не ссылаются.
                  </p>
                ) : (
                  <div className="flex flex-col gap-1">
                    {backlinks.slice(0, 6).map((b) => (
                      <button
                        key={b.fromId}
                        onClick={() => onOpenNote(b.fromId)}
                        className="rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2 py-1 text-left hover:border-[var(--accent)]/50"
                      >
                        <div className="truncate text-[12px] font-medium text-[var(--text)]">
                          {b.fromTitle || "Без названия"}
                        </div>
                        {b.snippet && (
                          <div className="line-clamp-1 text-[10.5px] text-[var(--text-secondary)]">{b.snippet}</div>
                        )}
                      </button>
                    ))}
                    {backlinks.length > 6 && (
                      <p className="text-[10px] text-[var(--text-secondary)] opacity-70">
                        и ещё {backlinks.length - 6}…
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="app-scroll max-h-48 overflow-y-auto px-3 py-2">
              {outline.length === 0 ? (
                <p className="text-[11.5px] text-[var(--text-secondary)] opacity-70">
                  Заголовков H3 нет. Используйте кнопку <strong>H</strong> в тулбаре редактора.
                </p>
              ) : (
                <ul className="space-y-0.5">
                  {outline.map((h, i) => (
                    <li key={i} className="flex items-center gap-2 text-[12px] text-[var(--text)]">
                      <span className="text-[var(--text-secondary)] opacity-60">☰</span>
                      <span className="truncate">{h}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
