"use client";

import { cx } from "@/lib/utils";

export type ToastItem = {
  id: number;
  message: string;
  tone?: "default" | "success" | "danger";
  actionLabel?: string;
  onAction?: () => void;
};

export function Toasts({ items, onDismiss }: { items: ToastItem[]; onDismiss: (id: number) => void }) {
  if (items.length === 0) return null;
  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[100] flex w-full max-w-md -translate-x-1/2 flex-col gap-2 px-4 sm:left-auto sm:right-5 sm:translate-x-0">
      {items.map((t) => (
        <div
          key={t.id}
          className={cx(
            "pointer-events-auto flex items-center gap-3 rounded-lg border px-4 py-3 shadow-[0_8px_28px_rgba(0,0,0,0.18)] backdrop-blur-xl",
            "animate-[toast-in_0.22s_ease-out]",
            "border-[var(--stroke)] bg-[var(--toast-bg)] text-[var(--text)]"
          )}
        >
          <span
            className={cx(
              "h-2 w-2 shrink-0 rounded-full",
              t.tone === "success" && "bg-emerald-500",
              t.tone === "danger" && "bg-[#f43f5e]",
              (!t.tone || t.tone === "default") && "bg-[var(--accent)]"
            )}
          />
          <p className="flex-1 text-sm">{t.message}</p>
          {t.actionLabel && t.onAction && (
            <button
              onClick={() => {
                t.onAction?.();
                onDismiss(t.id);
              }}
              className="shrink-0 rounded-md px-2 py-1 text-sm font-semibold text-[var(--accent)] hover:bg-[var(--hover)]"
            >
              {t.actionLabel}
            </button>
          )}
          <button
            onClick={() => onDismiss(t.id)}
            className="shrink-0 rounded-md p-1 text-[var(--text-secondary)] hover:bg-[var(--hover)]"
            aria-label="Закрыть"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
