"use client";

import { useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";

/**
 * Microsoft Fluent-style landing page.
 * Design principles applied (Fluent Design 2):
 *  - Light, clean surface with subtle depth (Z-depth layering via shadows)
 *  - Microsoft accent #0078D4, restrained use of color
 *  - Real product mockups, not generic "feature cards" with emojis
 *  - Concrete copy, no "Modern / Powerful / Beautiful" filler
 *  - Motion: subtle reveal-on-scroll, hover elevation
 *  - Typography: Segoe UI hierarchy, generous whitespace
 *
 * What makes it NOT look like AI-generated:
 *  - Specific product names and feature descriptions
 *  - Real UI mockups with actual content (code, notes, graph)
 *  - Numbered steps with concrete actions
 *  - Comparison table, FAQ, real footer
 *  - No purple gradients, no emoji icons, no glassmorphism
 */

export function Landing({ onOpenApp }: { onOpenApp: () => void }) {
  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-[var(--bg)] text-[var(--text)]">
      {/* Top nav — Microsoft style: thin, white, sticky */}
      <nav className="sticky top-0 z-50 border-b border-[var(--stroke)] bg-[var(--surface)]/95 backdrop-blur">
        <div className="mx-auto flex h-12 max-w-[1200px] items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <div className="grid h-6 w-6 place-items-center rounded bg-[var(--accent)] text-white">
              <Icon.Notebook className="h-3.5 w-3.5" />
            </div>
            <span className="text-[14px] font-semibold tracking-tight">Synapse</span>
            <span className="ml-1 hidden text-[11px] text-[var(--text-secondary)] sm:inline">от Microsoft 365</span>
          </div>
          <div className="hidden items-center gap-6 md:flex">
            <a href="#overview" className="text-[13px] text-[var(--text-secondary)] hover:text-[var(--text)]">Обзор</a>
            <a href="#features" className="text-[13px] text-[var(--text-secondary)] hover:text-[var(--text)]">Возможности</a>
            <a href="#compare" className="text-[13px] text-[var(--text-secondary)] hover:text-[var(--text)]">Сравнение</a>
            <a href="#pricing" className="text-[13px] text-[var(--text-secondary)] hover:text-[var(--text)]">Цены</a>
            <a href="#faq" className="text-[13px] text-[var(--text-secondary)] hover:text-[var(--text)]">Вопросы</a>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenApp}
              className="text-[13px] font-medium text-[var(--accent)] hover:underline"
            >
              Войти
            </button>
            <button
              onClick={onOpenApp}
              className="rounded bg-[var(--accent)] px-3 py-1.5 text-[12.5px] font-semibold text-white hover:bg-[var(--accent-strong)]"
            >
              Начать
            </button>
          </div>
        </div>
      </nav>

      {/* Hero — Microsoft style: left text + right product mockup, on light background */}
      <section id="overview" className="mx-auto max-w-[1200px] px-6 pt-14 pb-10">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <div className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-[var(--accent-light)] px-3 py-1 text-[11px] font-medium text-[var(--accent)]">
              <Icon.Sparkle className="h-3 w-3" /> Новый Synapse 2026
            </div>
            <h1 className="text-[34px] font-semibold leading-[1.1] tracking-tight text-[var(--text)] sm:text-[42px]">
              Заметки, которые<br />
              <span className="text-[var(--accent)]">связаны между собой</span>
            </h1>
            <p className="mt-4 max-w-md text-[15px] leading-relaxed text-[var(--text-secondary)]">
              Synapse — это приложение для заметок с графом знаний, @упоминаниями
              и семантическим поиском. Создано для команд и разработчиков, которые
              работают с большими объёмами информации.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                onClick={onOpenApp}
                className="rounded bg-[var(--accent)] px-5 py-2.5 text-[14px] font-semibold text-white shadow-sm hover:bg-[var(--accent-strong)]"
              >
                Открыть Synapse
              </button>
              <a
                href="#features"
                className="flex items-center gap-1.5 text-[14px] font-medium text-[var(--accent)] hover:underline"
              >
                Посмотреть возможности
                <Icon.ArrowRight className="h-4 w-4" />
              </a>
            </div>
            <div className="mt-6 flex items-center gap-5 text-[12px] text-[var(--text-secondary)]">
              <span className="flex items-center gap-1.5">
                <Icon.Check className="h-3.5 w-3.5 text-[#107c10]" /> Без установки
              </span>
              <span className="flex items-center gap-1.5">
                <Icon.Check className="h-3.5 w-3.5 text-[#107c10]" /> Работает офлайн
              </span>
              <span className="flex items-center gap-1.5">
                <Icon.Check className="h-3.5 w-3.5 text-[#107c10]" /> Импорт из .txt/.json
              </span>
            </div>
          </div>

          {/* Real product mockup — actual app layout, not generic illustration */}
          <ProductMockup />
        </div>
      </section>

      {/* Trust bar — Microsoft style logos strip */}
      <section className="border-y border-[var(--stroke)] bg-[var(--surface)] py-6">
        <div className="mx-auto max-w-[1200px] px-6">
          <p className="mb-4 text-center text-[11px] font-semibold uppercase tracking-wider text-[var(--text-secondary)]">
            На основе технологий Microsoft 365
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-[var(--text-secondary)]">
            <span className="text-[14px] font-semibold">OneNote</span>
            <span className="text-[14px] font-semibold">Loop</span>
            <span className="text-[14px] font-semibold">Fluid Design</span>
            <span className="text-[14px] font-semibold">Cascadia Code</span>
            <span className="text-[14px] font-semibold">Segoe UI</span>
          </div>
        </div>
      </section>

      {/* Features — Microsoft style: alternating image+text rows, not equal cards */}
      <section id="features" className="mx-auto max-w-[1200px] px-6 py-16">
        <div className="mb-10 max-w-2xl">
          <h2 className="text-[28px] font-semibold tracking-tight text-[var(--text)]">
            Возможности, которые экономят время
          </h2>
          <p className="mt-2 text-[15px] text-[var(--text-secondary)]">
            Каждая функция решает конкретную задачу — без лишнего.
          </p>
        </div>

        <FeatureRow
          reverse
          icon={<Icon.Sparkle className="h-5 w-5" />}
          eyebrow="Граф знаний"
          title="Видите, как связаны ваши идеи"
          desc="Synapse строит интерактивный граф всех заметок. Узлы — это заметки, линии — ссылки между ними. Чем больше ссылок на заметку, тем крупнее узел. Перетаскивайте, зумьте, кликайте — открывайте любую заметку прямо из графа."
          points={["Force-directed визуализация", "Цвет по папкам или тегам", "Локальный граф для текущей заметки"]}
          visual={<GraphVisual />}
        />

        <FeatureRow
          icon={<Icon.Bug className="h-5 w-5" />}
          eyebrow="Для разработчиков"
          title="Quick Capture для багов"
          desc="Вставьте stack trace из консоли — Synapse определит тип ошибки, язык, фреймворк и файл. Найдёт похожие заметки с решениями и сохранит структурированную запись об ошибке."
          points={["Парсит TypeError, ReferenceError, ImportError", "Определяет язык и фреймворк", "Связывает с прошлыми решениями"]}
          visual={<ErrorVisual />}
        />

        <FeatureRow
          reverse
          icon={<Icon.Search className="h-5 w-5" />}
          eyebrow="Семантический поиск"
          title="Находит по смыслу, а не по буквам"
          desc="Запрос «как подключить базу данных» найдёт заметку с кодом useEffect(() => connectDB()), даже если в тексте нет слова «подключить». Внутренний StackOverflow для вашей команды."
          points={["Понимает код и контекст", "Ранжирует по релевантности", "Работает с русским и английским"]}
          visual={<SearchVisual />}
        />

        <FeatureRow
          icon={<Icon.Link className="h-5 w-5" />}
          eyebrow="@упоминания"
          title="Связи без лишнего синтаксиса"
          desc={'Напишите @Second_Brain или @"Second Brain" — и заметки свяжутся автоматически. Никаких [[двойных скобок]]. Backlinks показывают, кто ссылается на текущую заметку.'}
          points={["Синтаксис как в Notion и Slack", "Двунаправленные связи", "Автосоздание по битой ссылке"]}
          visual={<LinksVisual />}
        />
      </section>

      {/* Comparison table — Microsoft style */}
      <section id="compare" className="border-y border-[var(--stroke)] bg-[var(--surface)] py-16">
        <div className="mx-auto max-w-[1100px] px-6">
          <h2 className="mb-2 text-[28px] font-semibold tracking-tight">Сравнение с другими</h2>
          <p className="mb-8 text-[15px] text-[var(--text-secondary)]">
            Что отличает Synapse от обычных заметочников.
          </p>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-[14px]">
              <thead>
                <tr className="border-b border-[var(--stroke)]">
                  <th className="py-3 text-left font-semibold text-[var(--text-secondary)]">Возможность</th>
                  <th className="py-3 text-center font-semibold text-[var(--text)]">Synapse</th>
                  <th className="py-3 text-center font-normal text-[var(--text-secondary)]">Обычные заметки</th>
                  <th className="py-3 text-center font-normal text-[var(--text-secondary)]">Бумажный блокнот</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Граф знаний", true, false, false],
                  ["@упоминания и backlinks", true, false, false],
                  ["Семантический поиск", true, false, false],
                  ["ИИ-парсинг ошибок", true, false, false],
                  ["Автосохранение", true, true, false],
                  ["Работает офлайн", true, true, true],
                  ["Экспорт в .txt/.json", true, true, false],
                ].map(([label, a, b, c]) => (
                  <tr key={label as string} className="border-b border-[var(--stroke)]">
                    <td className="py-3 text-[var(--text)]">{label}</td>
                    <td className="py-3 text-center">{a ? <Icon.Check className="mx-auto h-4 w-4 text-[#107c10]" /> : <span className="text-[var(--text-secondary)]">—</span>}</td>
                    <td className="py-3 text-center">{b ? <Icon.Check className="mx-auto h-4 w-4 text-[#107c10]" /> : <span className="text-[var(--text-secondary)]">—</span>}</td>
                    <td className="py-3 text-center">{c ? <Icon.Check className="mx-auto h-4 w-4 text-[#107c10]" /> : <span className="text-[var(--text-secondary)]">—</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Pricing — Microsoft style 3 tiers */}
      <section id="pricing" className="mx-auto max-w-[1200px] px-6 py-16">
        <div className="mb-10 text-center">
          <h2 className="text-[28px] font-semibold tracking-tight">Простые цены</h2>
          <p className="mt-2 text-[15px] text-[var(--text-secondary)]">Начните бесплатно. Платите только когда нужно больше.</p>
        </div>
        <div className="grid gap-5 md:grid-cols-3">
          <PriceCard
            name="Лично"
            price="0 ₽"
            period="навсегда"
            features={["До 1000 заметок", "Граф знаний", "@упоминания", "Экспорт в .txt"]}
            cta="Начать бесплатно"
            onCta={onOpenApp}
          />
          <PriceCard
            name="Pro"
            price="299 ₽"
            period="в месяц"
            highlight
            features={["Безлимит заметок", "Семантический поиск", "Quick Capture для багов", "Тёмная тема", "Приоритетная поддержка"]}
            cta="Попробовать 30 дней"
            onCta={onOpenApp}
          />
          <PriceCard
            name="Команда"
            price="899 ₽"
            period="в месяц / 5 чел."
            features={["Всё из Pro", "Общие папки", "Совместное редактирование", "История изменений", "SSO и аудит"]}
            cta="Связаться с нами"
            onCta={onOpenApp}
          />
        </div>
      </section>

      {/* FAQ — Microsoft style accordion */}
      <section id="faq" className="border-t border-[var(--stroke)] bg-[var(--surface)] py-16">
        <div className="mx-auto max-w-[800px] px-6">
          <h2 className="mb-8 text-[28px] font-semibold tracking-tight">Частые вопросы</h2>
          <div className="divide-y divide-[var(--stroke)]">
            <FaqItem q="Где хранятся мои заметки?" a="Заметки хранятся локально в браузере через SQLite. Вы можете экспортировать всё в .json или .txt в любой момент. Никакие данные не уходят на сервер." />
            <FaqItem q="Чем @упоминания отличаются от [[ссылок]]?" a={'@упоминания — это привычный синтаксис из Notion и Slack. Пишите @Second_Brain или @"Second Brain" с пробелами. Не нужно запоминать двойные скобки.'} />
            <FaqItem q="Как работает семантический поиск?" a="ИИ анализирует смысл запроса и находит заметки с похожим значением, даже если слова не совпадают. Запрос «подключить базу» найдёт код с connectDB()." />
            <FaqItem q="Quick Capture для багов — что это?" a="Вставьте stack trace из консоли. Synapse определит TypeError/язык/фреймворк/файл, найдёт похожие заметки с решениями и сохранит структурированную запись." />
            <FaqItem q="Работает ли офлайн?" a="Да. После первой загрузки приложение работает без интернета. Все заметки сохраняются локально. ИИ-функции (семантический поиск, парсинг ошибок) требуют подключения." />
          </div>
        </div>
      </section>

      {/* CTA — clean, no gradient */}
      <section className="mx-auto max-w-[1200px] px-6 py-16">
        <div className="rounded-xl border border-[var(--stroke)] bg-[var(--surface)] p-10 text-center shadow-sm">
          <h2 className="text-[26px] font-semibold tracking-tight">Попробуйте Synapse прямо сейчас</h2>
          <p className="mx-auto mt-2 max-w-md text-[14px] text-[var(--text-secondary)]">
            Без регистрации. Откройте приложение и начните писать.
          </p>
          <button
            onClick={onOpenApp}
            className="mt-5 rounded bg-[var(--accent)] px-6 py-2.5 text-[14px] font-semibold text-white hover:bg-[var(--accent-strong)]"
          >
            Открыть приложение
          </button>
        </div>
      </section>

      {/* Footer — Microsoft style: multiple columns */}
      <footer className="border-t border-[var(--stroke)] bg-[var(--surface-2)] py-10">
        <div className="mx-auto max-w-[1200px] px-6">
          <div className="grid gap-8 md:grid-cols-4">
            <div>
              <div className="mb-3 flex items-center gap-2">
                <div className="grid h-5 w-5 place-items-center rounded bg-[var(--accent)] text-white">
                  <Icon.Notebook className="h-3 w-3" />
                </div>
                <span className="text-[13px] font-semibold">Synapse</span>
              </div>
              <p className="text-[12px] leading-relaxed text-[var(--text-secondary)]">
                Заметки с графом знаний для команд и разработчиков.
              </p>
            </div>
            <FooterCol title="Продукт" links={["Обзор", "Возможности", "Цены", "Обновления"]} />
            <FooterCol title="Ресурсы" links={["Документация", "Горячие клавиши", "Импорт заметок", "Поддержка"]} />
            <FooterCol title="Компания" links={["О нас", "Блог", "Контакты", "Конфиденциальность"]} />
          </div>
          <div className="mt-8 border-t border-[var(--stroke)] pt-5 text-[11px] text-[var(--text-secondary)]">
            © 2026 Synapse. Сделано с заботой о ваших знаниях.
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ---------- Visual components (real UI mockups, not generic) ---------- */

function ProductMockup() {
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--stroke)] shadow-xl">
      {/* Title bar — Microsoft style, no macOS traffic lights */}
      <div className="flex items-center gap-2 border-b border-[var(--stroke)] bg-[var(--surface-2)] px-3 py-2">
        <Icon.Notebook className="h-3.5 w-3.5 text-[var(--accent)]" />
        <span className="text-[11px] font-medium text-[var(--text)]">Synapse — Все заметки</span>
      </div>
      <div className="flex h-[340px] bg-[var(--surface)] text-[11px]">
        {/* Sidebar */}
        <div className="hidden w-32 flex-col gap-1 border-r border-[var(--stroke)] bg-[var(--surface-2)] p-2 sm:flex">
          <div className="rounded bg-[var(--accent-light)] px-2 py-1 font-medium text-[var(--accent)]">Все заметки</div>
          <div className="px-2 py-1 text-[var(--text-secondary)]">Избранное</div>
          <div className="px-2 py-1 text-[var(--text-secondary)]">Закреплённые</div>
          <div className="mt-2 text-[9px] font-semibold uppercase text-[var(--text-secondary)]">Папки</div>
          <div className="flex items-center gap-1 px-2 py-1 text-[var(--text)]"><span className="h-2 w-2 rounded-sm bg-[#0078d4]" />Работа</div>
          <div className="flex items-center gap-1 px-2 py-1 text-[var(--text)]"><span className="h-2 w-2 rounded-sm bg-[#107c10]" />Личное</div>
          <div className="flex items-center gap-1 px-2 py-1 text-[var(--text)]"><span className="h-2 w-2 rounded-sm bg-[#ca5010]" />Идеи</div>
        </div>
        {/* List */}
        <div className="w-36 border-r border-[var(--stroke)] p-2">
          <div className="mb-1.5 rounded border border-[var(--accent)] bg-[var(--accent-light)] px-2 py-1.5">
            <div className="font-medium text-[var(--text)]">Подключение БД</div>
            <div className="truncate text-[10px] text-[var(--text-secondary)]">useEffect + Pool...</div>
          </div>
          <div className="mb-1.5 rounded border border-[var(--stroke)] px-2 py-1.5">
            <div className="font-medium text-[var(--text)]">Second Brain</div>
            <div className="truncate text-[10px] text-[var(--text-secondary)]">Методология...</div>
          </div>
          <div className="rounded border border-[var(--stroke)] px-2 py-1.5">
            <div className="font-medium text-[var(--text)]">Zettelkasten</div>
          </div>
        </div>
        {/* Editor */}
        <div className="flex-1 p-3">
          <div className="text-[13px] font-bold text-[var(--text)]">Подключение PostgreSQL к Next.js</div>
          <pre className="mt-2 rounded bg-[var(--surface-2)] p-2 text-[10px] leading-relaxed text-[var(--text)]" style={{ fontFamily: "var(--font-mono)" }}>
{`useEffect(() => {
  const client = new Pool({
    connectionString: process.env.DATABASE_URL
  });
  await client.connect();
}, []);`}
          </pre>
          <div className="mt-2 flex items-center gap-1 text-[10px] text-[var(--accent)]">
            <Icon.Link className="h-2.5 w-2.5" />
            @Second_Brain · @Zettelkasten
          </div>
        </div>
      </div>
    </div>
  );
}

function GraphVisual() {
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-4 shadow-sm">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[12px] font-medium text-[var(--text)]">Граф знаний</span>
        <span className="text-[10px] text-[var(--text-secondary)]">5 заметок · 3 связи</span>
      </div>
      <svg viewBox="0 0 320 200" className="h-48 w-full">
        {/* edges */}
        <line x1="160" y1="100" x2="80" y2="50" stroke="rgba(0,120,212,0.3)" strokeWidth="1.5" />
        <line x1="160" y1="100" x2="240" y2="50" stroke="rgba(0,120,212,0.3)" strokeWidth="1.5" />
        <line x1="160" y1="100" x2="100" y2="160" stroke="rgba(0,120,212,0.3)" strokeWidth="1.5" />
        <line x1="80" y1="50" x2="240" y2="50" stroke="rgba(0,120,212,0.2)" strokeWidth="1" />
        {/* nodes — size by weight */}
        <circle cx="160" cy="100" r="14" fill="#0078d4" />
        <circle cx="80" cy="50" r="9" fill="#107c10" />
        <circle cx="240" cy="50" r="9" fill="#ca5010" />
        <circle cx="100" cy="160" r="7" fill="#5c2d91" />
        <circle cx="260" cy="160" r="6" fill="#b4009e" />
        {/* labels */}
        <text x="160" y="125" textAnchor="middle" fontSize="9" fill="currentColor" className="text-[var(--text)]">Second Brain</text>
        <text x="80" y="38" textAnchor="middle" fontSize="8" fill="currentColor" className="text-[var(--text-secondary)]">Zettelkasten</text>
        <text x="240" y="38" textAnchor="middle" fontSize="8" fill="currentColor" className="text-[var(--text-secondary)]">PostgreSQL</text>
      </svg>
    </div>
  );
}

function ErrorVisual() {
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--stroke)] bg-[var(--surface)] shadow-sm">
      <div className="flex items-center gap-2 border-b border-[var(--stroke)] bg-[var(--surface-2)] px-3 py-1.5">
        <Icon.Code className="h-3.5 w-3.5 text-[var(--accent)]" />
        <span className="text-[11px] font-medium text-[var(--text)]">error.log</span>
      </div>
      <div className="p-3">
        <pre className="text-[10px] leading-relaxed text-[var(--text)]" style={{ fontFamily: "var(--font-mono)" }}>
{`TypeError: Cannot read properties
  of undefined (reading 'map')
    at Component (page.tsx:42)`}
        </pre>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <span className="rounded bg-[rgba(209,52,56,0.1)] px-1.5 py-0.5 text-[10px] text-[#d13438]">TypeError</span>
          <span className="rounded bg-[var(--accent-light)] px-1.5 py-0.5 text-[10px] text-[var(--accent)]">TypeScript</span>
          <span className="rounded bg-[rgba(92,45,145,0.1)] px-1.5 py-0.5 text-[10px] text-[#5c2d91]">Next.js</span>
          <span className="rounded bg-[rgba(202,80,16,0.1)] px-1.5 py-0.5 text-[10px] text-[#ca5010]">page.tsx:42</span>
        </div>
        <div className="mt-3 flex items-start gap-1.5 rounded bg-[var(--accent-light)] p-2 text-[11px] text-[var(--accent)]">
          <Icon.Sparkle className="mt-0.5 h-3 w-3 shrink-0" />
          <span>Найдена похожая заметка с решением</span>
        </div>
      </div>
    </div>
  );
}

function SearchVisual() {
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-4 shadow-sm">
      <div className="mb-3 flex items-center gap-2 rounded border border-[var(--stroke)] bg-[var(--surface-2)] px-2.5 py-1.5">
        <Icon.Search className="h-3.5 w-3.5 text-[var(--accent)]" />
        <span className="text-[12px] text-[var(--text)]">как подключить базу данных</span>
        <span className="ml-auto flex items-center gap-0.5">
          <span className="semantic-dot" />
          <span className="semantic-dot" style={{ animationDelay: "0.15s" }} />
          <span className="semantic-dot" style={{ animationDelay: "0.3s" }} />
        </span>
      </div>
      <div className="space-y-2">
        <div className="rounded border border-[var(--accent)]/40 bg-[var(--accent-light)] p-2">
          <div className="text-[12px] font-medium text-[var(--text)]">Подключение PostgreSQL к Next.js</div>
          <div className="mt-0.5 flex items-center gap-1 text-[10px] text-[var(--accent)]">
            <Icon.Sparkle className="h-2.5 w-2.5" /> 94% совпадение по смыслу
          </div>
        </div>
        <div className="rounded border border-[var(--stroke)] p-2">
          <div className="text-[12px] font-medium text-[var(--text)]">Pool соединений</div>
          <div className="mt-0.5 text-[10px] text-[var(--text-secondary)]">71% совпадение</div>
        </div>
      </div>
    </div>
  );
}

function LinksVisual() {
  return (
    <div className="overflow-hidden rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-4 shadow-sm">
      <div className="text-[12px] font-medium text-[var(--text)]">Связи заметки</div>
      <div className="mt-2 text-[10px] font-semibold uppercase text-[var(--text-secondary)]">Ссылки отсюда (2)</div>
      <div className="mt-1 flex flex-wrap gap-1.5">
        <span className="rounded-full border border-[var(--accent)]/30 bg-[var(--accent-light)] px-2 py-0.5 text-[11px] text-[var(--accent)]">@Zettelkasten</span>
        <span className="rounded-full border border-[var(--accent)]/30 bg-[var(--accent-light)] px-2 py-0.5 text-[11px] text-[var(--accent)]">@"Second Brain"</span>
      </div>
      <div className="mt-3 text-[10px] font-semibold uppercase text-[var(--text-secondary)]">Ссылки сюда (1)</div>
      <div className="mt-1 rounded border border-[var(--stroke)] px-2 py-1">
        <div className="text-[11px] font-medium text-[var(--text)]">Подключение PostgreSQL</div>
        <div className="text-[10px] text-[var(--text-secondary)]">…связано с @Second_Brain…</div>
      </div>
    </div>
  );
}

/* ---------- Reusable building blocks ---------- */

function FeatureRow({
  icon,
  eyebrow,
  title,
  desc,
  points,
  visual,
  reverse,
}: {
  icon: React.ReactNode;
  eyebrow: string;
  title: string;
  desc: string;
  points: string[];
  visual: React.ReactNode;
  reverse?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ob = new IntersectionObserver(
      ([e]) => e.isIntersecting && setVisible(true),
      { threshold: 0.15 }
    );
    ob.observe(el);
    return () => ob.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={`mb-16 grid items-center gap-8 lg:grid-cols-2 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"} transition-all duration-500`}
    >
      <div className={reverse ? "lg:order-2" : ""}>
        <div className="mb-2 flex items-center gap-2 text-[var(--accent)]">
          <div className="grid h-8 w-8 place-items-center rounded bg-[var(--accent-light)]">{icon}</div>
          <span className="text-[12px] font-semibold uppercase tracking-wide">{eyebrow}</span>
        </div>
        <h3 className="text-[22px] font-semibold tracking-tight text-[var(--text)]">{title}</h3>
        <p className="mt-2 text-[14px] leading-relaxed text-[var(--text-secondary)]">{desc}</p>
        <ul className="mt-4 space-y-1.5">
          {points.map((p) => (
            <li key={p} className="flex items-start gap-2 text-[13px] text-[var(--text)]">
              <Icon.Check className="mt-0.5 h-4 w-4 shrink-0 text-[#107c10]" />
              {p}
            </li>
          ))}
        </ul>
      </div>
      <div className={reverse ? "lg:order-1" : ""}>{visual}</div>
    </div>
  );
}

function PriceCard({
  name,
  price,
  period,
  features,
  cta,
  onCta,
  highlight,
}: {
  name: string;
  price: string;
  period: string;
  features: string[];
  cta: string;
  onCta: () => void;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-lg border bg-[var(--surface)] p-6 shadow-sm ${
        highlight ? "border-[var(--accent)] ring-1 ring-[var(--accent)]" : "border-[var(--stroke)]"
      }`}
    >
      {highlight && (
        <div className="mb-3 inline-block rounded bg-[var(--accent)] px-2 py-0.5 text-[10px] font-semibold uppercase text-white">
          Популярный
        </div>
      )}
      <h3 className="text-[16px] font-semibold text-[var(--text)]">{name}</h3>
      <div className="mt-2 flex items-baseline gap-1">
        <span className="text-[28px] font-semibold text-[var(--text)]">{price}</span>
        <span className="text-[12px] text-[var(--text-secondary)]">/ {period}</span>
      </div>
      <ul className="mt-4 space-y-2">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-[13px] text-[var(--text)]">
            <Icon.Check className="mt-0.5 h-4 w-4 shrink-0 text-[#107c10]" />
            {f}
          </li>
        ))}
      </ul>
      <button
        onClick={onCta}
        className={`mt-5 w-full rounded px-4 py-2 text-[13px] font-semibold ${
          highlight
            ? "bg-[var(--accent)] text-white hover:bg-[var(--accent-strong)]"
            : "border border-[var(--stroke)] text-[var(--text)] hover:bg-[var(--hover)]"
        }`}
      >
        {cta}
      </button>
    </div>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between py-4 text-left"
      >
        <span className="text-[14px] font-medium text-[var(--text)]">{q}</span>
        <span className="text-[var(--text-secondary)]">{open ? "−" : "+"}</span>
      </button>
      {open && <p className="pb-4 text-[13px] leading-relaxed text-[var(--text-secondary)]">{a}</p>}
    </div>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <h4 className="mb-3 text-[12px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">{title}</h4>
      <ul className="space-y-2">
        {links.map((l) => (
          <li key={l}>
            <a href="#" className="text-[13px] text-[var(--text)] hover:text-[var(--accent)] hover:underline">
              {l}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
