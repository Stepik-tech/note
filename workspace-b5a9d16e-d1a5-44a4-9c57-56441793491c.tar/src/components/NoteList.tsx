"use client";

import { Icon } from "@/components/icons";
import { FolderIcon } from "@/components/folder-icons";
import type { FolderDTO, NoteDTO, SortKey, ViewKey } from "@/lib/types";
import { cx, formatRelativeTime, htmlToPlainText } from "@/lib/utils";
import { RefObject } from "react";

const NOTE_DRAG_TYPE = "application/x-note-id";

export function NoteList({
  notes,
  folders,
  selectedNoteId,
  activeView,
  searchQuery,
  onSearchChange,
  searchInputRef,
  sortKey,
  onSortChange,
  listMode,
  onListModeChange,
  onSelect,
  onCreateNote,
  onCopyAll,
  onExportAll,
  onImportClick,
  onContextMenu,
  title,
  semantic,
  onToggleSemantic,
  semanticLoading,
}: {
  notes: NoteDTO[];
  folders: FolderDTO[];
  selectedNoteId: number | null;
  activeView: ViewKey;
  searchQuery: string;
  onSearchChange: (v: string) => void;
  searchInputRef: RefObject<HTMLInputElement | null>;
  sortKey: SortKey;
  onSortChange: (s: SortKey) => void;
  listMode: "list" | "grid";
  onListModeChange: (m: "list" | "grid") => void;
  onSelect: (id: number) => void;
  onCreateNote: () => void;
  onCopyAll: () => void;
  onExportAll: (format: "json" | "txt") => void;
  onImportClick: () => void;
  onContextMenu: (e: React.MouseEvent, noteId: number) => void;
  title: string;
  semantic?: boolean;
  onToggleSemantic?: () => void;
  semanticLoading?: boolean;
}) {
  const folderById = new Map(folders.map((f) => [f.id, f]));

  return (
    <section className="flex h-full w-full max-w-[300px] shrink-0 flex-col border-r border-[var(--stroke)] bg-[var(--surface-2)] md:w-[280px]">
      <div className="flex items-center justify-between gap-2 px-3 pt-3">
        <h2 className="truncate text-[15px] font-semibold text-[var(--text)]">{title}</h2>
        <button
          onClick={onCreateNote}
          title="Новая заметка (Ctrl+N)"
          className="flex items-center gap-1 rounded-md bg-[var(--accent)] px-2 py-1 text-[11px] font-semibold text-white shadow-sm hover:opacity-90"
        >
          <Icon.Plus className="h-3 w-3" /> Заметка
        </button>
      </div>

      <div className="mt-2 px-3">
        <div className="flex items-center gap-2 rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2 py-1">
          <Icon.Search className="h-3.5 w-3.5 text-[var(--text-secondary)]" />
          <input
            ref={searchInputRef}
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={semantic ? "Поиск по смыслу…" : "Поиск (Ctrl+F)"}
            className="w-full bg-transparent text-[13px] text-[var(--text)] outline-none placeholder:text-[var(--text-secondary)]"
          />
          {semanticLoading && (
            <span className="flex items-center gap-0.5" title="Семантический поиск...">
              <span className="semantic-dot" />
              <span className="semantic-dot" style={{ animationDelay: '0.15s' }} />
              <span className="semantic-dot" style={{ animationDelay: '0.3s' }} />
            </span>
          )}
          {searchQuery && !semanticLoading && (
            <button onClick={() => onSearchChange("")} className="text-[var(--text-secondary)]">
              <Icon.Close className="h-3 w-3" />
            </button>
          )}
          {onToggleSemantic && (
            <button
              onClick={onToggleSemantic}
              title={semantic ? "Обычный поиск" : "Семантический поиск (по смыслу)"}
              className={cx(
                "grid h-5 w-5 place-items-center rounded transition",
                semantic ? "bg-[var(--accent)] text-white" : "text-[var(--text-secondary)] hover:bg-[var(--hover)]"
              )}
            >
              <Icon.Sparkle className="h-3 w-3" />
            </button>
          )}
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between gap-2 px-3 text-[var(--text-secondary)]">
        <select
          value={sortKey}
          onChange={(e) => onSortChange(e.target.value as SortKey)}
          className="rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-1.5 py-0.5 text-[11px] text-[var(--text)] outline-none"
        >
          <option value="updated-desc">Сначала изменённые</option>
          <option value="created-desc">Сначала новые</option>
          <option value="title-asc">Заголовок А-Я</option>
          <option value="title-desc">Заголовок Я-А</option>
        </select>
        <div className="flex items-center gap-0.5">
          <button
            title="Копировать весь список текстом"
            onClick={onCopyAll}
            className="grid h-6 w-6 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Copy className="h-3 w-3" />
          </button>
          <button
            title="Экспорт в .txt"
            onClick={() => onExportAll("txt")}
            className="grid h-6 w-6 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Download className="h-3 w-3" />
          </button>
          <button
            title="Импорт заметок"
            onClick={onImportClick}
            className="grid h-6 w-6 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Upload className="h-3 w-3" />
          </button>
          <span className="mx-0.5 h-3.5 w-px bg-[var(--stroke)]" />
          <button
            title="Список"
            onClick={() => onListModeChange("list")}
            className={cx("grid h-6 w-6 place-items-center rounded-md hover:bg-[var(--hover)]", listMode === "list" && "bg-[var(--active)] text-[var(--accent)]")}
          >
            <Icon.List className="h-3 w-3" />
          </button>
          <button
            title="Сетка"
            onClick={() => onListModeChange("grid")}
            className={cx("grid h-6 w-6 place-items-center rounded-md hover:bg-[var(--hover)]", listMode === "grid" && "bg-[var(--active)] text-[var(--accent)]")}
          >
            <Icon.Grid className="h-3 w-3" />
          </button>
        </div>
      </div>

      <div className={cx("app-scroll mt-2 flex-1 overflow-y-auto px-2 pb-3", listMode === "grid" && "grid grid-cols-2 gap-2 content-start")}>
        {notes.length === 0 && (
          <div className="col-span-2 mt-8 flex flex-col items-center gap-2 px-6 text-center text-[var(--text-secondary)]">
            <Icon.Notebook className="h-7 w-7 opacity-40" />
            <p className="text-[13px]">Заметок не найдено</p>
          </div>
        )}
        {notes.map((note) => {
          const plain = htmlToPlainText(note.content);
          const folder = note.folderId ? folderById.get(note.folderId) : null;
          const selected = note.id === selectedNoteId;
          return (
            <article
              key={note.id}
              draggable
              onDragStart={(e) => e.dataTransfer.setData(NOTE_DRAG_TYPE, String(note.id))}
              onClick={() => onSelect(note.id)}
              onContextMenu={(e) => {
                e.preventDefault();
                onSelect(note.id);
                onContextMenu(e, note.id);
              }}
              className={cx(
                "mb-2 cursor-pointer rounded-lg border px-3 py-2 transition",
                selected
                  ? "border-[var(--accent)] bg-[var(--active)] shadow-[0_0_0_1px_var(--accent)]"
                  : "border-[var(--stroke)] bg-[var(--surface)] hover:border-[var(--accent)]/50 hover:shadow-[var(--shadow-card)]",
                listMode === "grid" && "mb-0"
              )}
              style={note.color !== "#ffffff" ? { backgroundColor: selected ? undefined : note.color } : undefined}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="line-clamp-1 flex-1 text-[13px] font-semibold text-[var(--text)]">
                  {note.title || "Без названия"}
                </h3>
                <div className="flex shrink-0 items-center gap-1 text-[var(--text-secondary)]">
                  {note.pinned && <Icon.Pin className="h-2.5 w-2.5 fill-current text-[var(--accent)]" />}
                  {note.favorite && <Icon.Star className="h-2.5 w-2.5 fill-current text-amber-500" />}
                </div>
              </div>
              <p className="mt-0.5 line-clamp-2 text-[11.5px] leading-snug text-[var(--text-secondary)]">
                {plain || "Нет текста"}
              </p>
              <div className="mt-1 flex items-center gap-2 text-[10px] text-[var(--text-secondary)]">
                <span>{formatRelativeTime(note.trashed ? note.deletedAt : note.updatedAt)}</span>
                {folder && (
                  <span className="flex items-center gap-0.5 truncate">
                    <FolderIcon name={folder.icon} size={11} style={{ color: folder.color }} />
                    <span className="truncate">{folder.name}</span>
                  </span>
                )}
              </div>
              {note.tags.length > 0 && (
                <div className="mt-1 flex flex-wrap gap-1">
                  {note.tags.slice(0, 3).map((t) => (
                    <span key={t} className="rounded-full bg-[var(--hover)] px-1.5 py-0.5 text-[9px] text-[var(--text-secondary)]">
                      #{t}
                    </span>
                  ))}
                </div>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}
