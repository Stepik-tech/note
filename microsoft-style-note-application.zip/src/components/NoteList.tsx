"use client";

import { Icon } from "@/components/icons";
import type { FolderDTO, NoteDTO, SortKey, ViewKey } from "@/lib/types";
import { cx, formatRelativeTime, htmlToPlainText } from "@/lib/utils";
import { RefObject } from "react";

const NOTE_DRAG_TYPE = "application/x-note-id";

export function NoteList({
  notes,
  folders,
  selectedNoteId,
  activeView,
  searchQuery,
  onSearchChange,
  searchInputRef,
  sortKey,
  onSortChange,
  listMode,
  onListModeChange,
  onSelect,
  onCreateNote,
  onCopyAll,
  onExportAll,
  onImportClick,
  onContextMenu,
  title,
}: {
  notes: NoteDTO[];
  folders: FolderDTO[];
  selectedNoteId: number | null;
  activeView: ViewKey;
  searchQuery: string;
  onSearchChange: (v: string) => void;
  searchInputRef: RefObject<HTMLInputElement | null>;
  sortKey: SortKey;
  onSortChange: (s: SortKey) => void;
  listMode: "list" | "grid";
  onListModeChange: (m: "list" | "grid") => void;
  onSelect: (id: number) => void;
  onCreateNote: () => void;
  onCopyAll: () => void;
  onExportAll: (format: "json" | "txt") => void;
  onImportClick: () => void;
  onContextMenu: (e: React.MouseEvent, noteId: number) => void;
  title: string;
}) {
  const folderById = new Map(folders.map((f) => [f.id, f]));

  return (
    <section className="flex h-full w-full max-w-[380px] shrink-0 flex-col border-r border-[var(--stroke)] bg-[var(--surface-2)] md:w-[360px]">
      <div className="flex items-center justify-between gap-2 px-4 pt-4">
        <h2 className="truncate text-[17px] font-semibold text-[var(--text)]">{title}</h2>
        <button
          onClick={onCreateNote}
          title="Новая заметка (Ctrl+N)"
          className="flex items-center gap-1 rounded-md bg-[var(--accent)] px-2.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:opacity-90"
        >
          <Icon.Plus className="h-3.5 w-3.5" /> Заметка
        </button>
      </div>

      <div className="mt-3 px-4">
        <div className="flex items-center gap-2 rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2.5 py-1.5">
          <Icon.Search className="h-4 w-4 text-[var(--text-secondary)]" />
          <input
            ref={searchInputRef}
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Поиск по заметкам (Ctrl+F)"
            className="w-full bg-transparent text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-secondary)]"
          />
          {searchQuery && (
            <button onClick={() => onSearchChange("")} className="text-[var(--text-secondary)]">
              <Icon.Close className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      <div className="mt-2.5 flex items-center justify-between gap-2 px-4 text-[var(--text-secondary)]">
        <select
          value={sortKey}
          onChange={(e) => onSortChange(e.target.value as SortKey)}
          className="rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2 py-1 text-[12px] text-[var(--text)] outline-none"
        >
          <option value="updated-desc">Сначала изменённые</option>
          <option value="created-desc">Сначала новые</option>
          <option value="title-asc">Заголовок А-Я</option>
          <option value="title-desc">Заголовок Я-А</option>
        </select>
        <div className="flex items-center gap-1">
          <button
            title="Копировать весь список текстом"
            onClick={onCopyAll}
            className="grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Copy className="h-3.5 w-3.5" />
          </button>
          <button
            title="Экспорт в .txt"
            onClick={() => onExportAll("txt")}
            className="grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Download className="h-3.5 w-3.5" />
          </button>
          <button
            title="Импорт заметок"
            onClick={onImportClick}
            className="grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]"
          >
            <Icon.Upload className="h-3.5 w-3.5" />
          </button>
          <span className="mx-0.5 h-4 w-px bg-[var(--stroke)]" />
          <button
            title="Список"
            onClick={() => onListModeChange("list")}
            className={cx("grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]", listMode === "list" && "bg-[var(--active)] text-[var(--accent)]")}
          >
            <Icon.List className="h-3.5 w-3.5" />
          </button>
          <button
            title="Сетка"
            onClick={() => onListModeChange("grid")}
            className={cx("grid h-7 w-7 place-items-center rounded-md hover:bg-[var(--hover)]", listMode === "grid" && "bg-[var(--active)] text-[var(--accent)]")}
          >
            <Icon.Grid className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className={cx("app-scroll mt-3 flex-1 overflow-y-auto px-3 pb-4", listMode === "grid" && "grid grid-cols-2 gap-2.5 content-start")}>
        {notes.length === 0 && (
          <div className="col-span-2 mt-10 flex flex-col items-center gap-2 px-6 text-center text-[var(--text-secondary)]">
            <Icon.Notebook className="h-8 w-8 opacity-40" />
            <p className="text-sm">Заметок не найдено</p>
          </div>
        )}
        {notes.map((note) => {
          const plain = htmlToPlainText(note.content);
          const folder = note.folderId ? folderById.get(note.folderId) : null;
          const selected = note.id === selectedNoteId;
          return (
            <article
              key={note.id}
              draggable
              onDragStart={(e) => e.dataTransfer.setData(NOTE_DRAG_TYPE, String(note.id))}
              onClick={() => onSelect(note.id)}
              onContextMenu={(e) => {
                e.preventDefault();
                onSelect(note.id);
                onContextMenu(e, note.id);
              }}
              className={cx(
                "mb-2.5 cursor-pointer rounded-lg border px-3.5 py-3 transition",
                selected
                  ? "border-[var(--accent)] bg-[var(--active)] shadow-[0_0_0_1px_var(--accent)]"
                  : "border-[var(--stroke)] bg-[var(--surface)] hover:border-[var(--accent)]/50 hover:shadow-[var(--shadow-card)]",
                listMode === "grid" && "mb-0"
              )}
              style={note.color !== "#ffffff" ? { backgroundColor: selected ? undefined : note.color } : undefined}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="line-clamp-1 flex-1 text-[13.5px] font-semibold text-[var(--text)]">
                  {note.title || "Без названия"}
                </h3>
                <div className="flex shrink-0 items-center gap-1 text-[var(--text-secondary)]">
                  {note.pinned && <Icon.Pin className="h-3 w-3 fill-current text-[var(--accent)]" />}
                  {note.favorite && <Icon.Star className="h-3 w-3 fill-current text-amber-500" />}
                </div>
              </div>
              <p className="mt-1 line-clamp-2 text-[12.5px] leading-snug text-[var(--text-secondary)]">
                {plain || "Нет текста"}
              </p>
              <div className="mt-2 flex items-center gap-2 text-[11px] text-[var(--text-secondary)]">
                <span>{formatRelativeTime(note.trashed ? note.deletedAt : note.updatedAt)}</span>
                {folder && (
                  <span className="flex items-center gap-1 truncate">
                    <span>{folder.icon}</span>
                    <span className="truncate">{folder.name}</span>
                  </span>
                )}
              </div>
              {note.tags.length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {note.tags.slice(0, 3).map((t) => (
                    <span key={t} className="rounded-full bg-[var(--hover)] px-1.5 py-0.5 text-[10px] text-[var(--text-secondary)]">
                      #{t}
                    </span>
                  ))}
                </div>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}
