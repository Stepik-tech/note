"use client";

import { useEffect, useRef } from "react";

export type MenuAction = {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
  divider?: boolean;
};

export function ContextMenu({
  x,
  y,
  actions,
  onClose,
}: {
  x: number;
  y: number;
  actions: MenuAction[];
  onClose: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const safeX = Math.min(x, (typeof window !== "undefined" ? window.innerWidth : 1200) - 220);
  const safeY = Math.min(y, (typeof window !== "undefined" ? window.innerHeight : 800) - actions.length * 34 - 20);

  return (
    <div
      ref={ref}
      style={{ left: Math.max(8, safeX), top: Math.max(8, safeY) }}
      className="fixed z-[80] w-52 rounded-lg border border-[var(--stroke)] bg-[var(--surface)] py-1.5 shadow-[0_14px_36px_rgba(0,0,0,0.2)] fade-in"
    >
      {actions.map((a, i) => (
        <div key={i}>
          {a.divider && <div className="my-1 h-px bg-[var(--stroke)]" />}
          <button
            onClick={() => {
              a.onClick();
              onClose();
            }}
            className={`flex w-full items-center gap-2.5 px-3 py-1.5 text-left text-[13px] hover:bg-[var(--hover)] ${
              a.danger ? "text-rose-600" : "text-[var(--text)]"
            }`}
          >
            {a.icon}
            {a.label}
          </button>
        </div>
      ))}
    </div>
  );
}
