"use client";

import { Icon } from "@/components/icons";
import { RichEditor } from "@/components/RichEditor";
import type { FolderDTO, NoteDTO } from "@/lib/types";
import { NOTE_COLORS, cx, formatFullDate, wordStats } from "@/lib/utils";
import { RefObject, useState } from "react";

export function EditorPane({
  note,
  folders,
  draftTitle,
  draftContent,
  onChangeTitle,
  onChangeContent,
  editorRef,
  saveStatus,
  onTogglePin,
  onToggleFavorite,
  onToggleArchive,
  onDelete,
  onRestore,
  onPermanentDelete,
  onDuplicate,
  onCopy,
  onExportSingle,
  onPrint,
  onSetColor,
  onMoveFolder,
  onAddTag,
  onRemoveTag,
  stats,
}: {
  note: NoteDTO | null;
  folders: FolderDTO[];
  draftTitle: string;
  draftContent: string;
  onChangeTitle: (v: string) => void;
  onChangeContent: (v: string) => void;
  editorRef: RefObject<HTMLDivElement | null>;
  saveStatus: "idle" | "saving" | "saved";
  onTogglePin: () => void;
  onToggleFavorite: () => void;
  onToggleArchive: () => void;
  onDelete: () => void;
  onRestore: () => void;
  onPermanentDelete: () => void;
  onDuplicate: () => void;
  onCopy: () => void;
  onExportSingle: () => void;
  onPrint: () => void;
  onSetColor: (color: string) => void;
  onMoveFolder: (folderId: number | null) => void;
  onAddTag: (tag: string) => void;
  onRemoveTag: (tag: string) => void;
  stats: { totalNotes: number; totalFolders: number; totalWords: number };
}) {
  const [tagDraft, setTagDraft] = useState("");
  const [colorOpen, setColorOpen] = useState(false);

  if (!note) {
    return (
      <section className="flex h-full flex-1 flex-col items-center justify-center gap-4 bg-[var(--surface)] px-8 text-center">
        <div className="grid h-16 w-16 place-items-center rounded-2xl bg-[var(--accent-light)] text-[var(--accent)]">
          <Icon.Notebook className="h-8 w-8" />
        </div>
        <h2 className="text-xl font-semibold text-[var(--text)]">Выберите заметку или создайте новую</h2>
        <p className="max-w-sm text-sm text-[var(--text-secondary)]">
          Пишите заметки, раскладывайте их по папкам, помечайте тегами и мгновенно копируйте весь текст —
          всё сохраняется автоматически.
        </p>
        <div className="mt-2 flex gap-6 rounded-xl border border-[var(--stroke)] bg-[var(--surface-2)] px-6 py-4">
          <div className="text-center">
            <p className="text-lg font-semibold text-[var(--text)]">{stats.totalNotes}</p>
            <p className="text-[11px] text-[var(--text-secondary)]">заметок</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-semibold text-[var(--text)]">{stats.totalFolders}</p>
            <p className="text-[11px] text-[var(--text-secondary)]">папок</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-semibold text-[var(--text)]">{stats.totalWords}</p>
            <p className="text-[11px] text-[var(--text-secondary)]">слов написано</p>
          </div>
        </div>
      </section>
    );
  }

  const { words, chars, readingMinutes } = wordStats(draftContent);

  return (
    <section className="flex h-full flex-1 flex-col bg-[var(--surface)]">
      <div className="flex flex-wrap items-center gap-1 border-b border-[var(--stroke)] px-4 py-2">
        {!note.trashed ? (
          <>
            <button
              title={note.pinned ? "Открепить" : "Закрепить"}
              onClick={onTogglePin}
              className={cx("grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]", note.pinned && "text-[var(--accent)]")}
            >
              <Icon.Pin className="h-4 w-4" />
            </button>
            <button
              title={note.favorite ? "Убрать из избранного" : "В избранное"}
              onClick={onToggleFavorite}
              className={cx("grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]", note.favorite && "text-amber-500")}
            >
              <Icon.Star className="h-4 w-4" />
            </button>
            <button
              title={note.archived ? "Вернуть из архива" : "Архивировать"}
              onClick={onToggleArchive}
              className={cx("grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]", note.archived && "text-[var(--accent)]")}
            >
              <Icon.Archive className="h-4 w-4" />
            </button>
            <span className="mx-1 h-5 w-px bg-[var(--stroke)]" />

            <div className="relative">
              <button
                title="Цвет заметки"
                onClick={() => setColorOpen((v) => !v)}
                className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]"
              >
                <span className="h-4 w-4 rounded-full border border-black/15" style={{ backgroundColor: note.color }} />
              </button>
              {colorOpen && (
                <div className="absolute left-0 top-9 z-30 flex gap-1.5 rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-2 shadow-[0_10px_28px_rgba(0,0,0,0.18)]">
                  {NOTE_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => {
                        onSetColor(c);
                        setColorOpen(false);
                      }}
                      className={cx("h-6 w-6 rounded-full border-2", note.color === c ? "border-[var(--accent)]" : "border-black/10")}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              )}
            </div>

            <select
              value={note.folderId ?? ""}
              onChange={(e) => onMoveFolder(e.target.value ? Number(e.target.value) : null)}
              title="Переместить в папку"
              className="h-8 rounded-md border border-[var(--stroke)] bg-[var(--surface)] px-2 text-xs text-[var(--text)] outline-none"
            >
              <option value="">Без папки</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.icon} {f.name}
                </option>
              ))}
            </select>

            <span className="mx-1 h-5 w-px bg-[var(--stroke)]" />
            <button title="Дублировать" onClick={onDuplicate} className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]">
              <Icon.Copy className="h-4 w-4" />
            </button>
            <button title="Скопировать текст" onClick={onCopy} className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]">
              <Icon.Tag className="hidden" />
              <span className="text-[13px] font-medium">Копировать</span>
            </button>
            <button title="Скачать .txt" onClick={onExportSingle} className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]">
              <Icon.Download className="h-4 w-4" />
            </button>
            <button title="Печать" onClick={onPrint} className="grid h-8 w-8 place-items-center rounded-md hover:bg-[var(--hover)]">
              <Icon.Print className="h-4 w-4" />
            </button>
            <button
              title="Удалить"
              onClick={onDelete}
              className="ml-auto grid h-8 w-8 place-items-center rounded-md text-rose-600 hover:bg-rose-50"
            >
              <Icon.Trash className="h-4 w-4" />
            </button>
          </>
        ) : (
          <>
            <span className="rounded-full bg-rose-50 px-2.5 py-1 text-xs font-medium text-rose-600">В корзине</span>
            <button
              onClick={onRestore}
              className="ml-2 flex items-center gap-1.5 rounded-md border border-[var(--stroke)] px-2.5 py-1.5 text-xs font-medium hover:bg-[var(--hover)]"
            >
              <Icon.Undo className="h-3.5 w-3.5" /> Восстановить
            </button>
            <button
              onClick={onPermanentDelete}
              className="ml-auto flex items-center gap-1.5 rounded-md bg-rose-600 px-2.5 py-1.5 text-xs font-medium text-white hover:bg-rose-700"
            >
              <Icon.Trash className="h-3.5 w-3.5" /> Удалить навсегда
            </button>
          </>
        )}
      </div>

      <div id="print-area" className="app-scroll flex min-h-0 flex-1 flex-col overflow-y-auto">
        <div className="px-6 pt-5">
          <input
            value={draftTitle}
            onChange={(e) => onChangeTitle(e.target.value)}
            placeholder="Название заметки"
            disabled={note.trashed}
            className="w-full bg-transparent text-2xl font-bold text-[var(--text)] outline-none placeholder:text-[var(--text-secondary)]/60"
          />
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {note.tags.map((t) => (
              <span
                key={t}
                className="flex items-center gap-1 rounded-full bg-[var(--accent-light)] px-2.5 py-1 text-[11.5px] text-[var(--accent)]"
              >
                #{t}
                {!note.trashed && (
                  <button onClick={() => onRemoveTag(t)} className="opacity-70 hover:opacity-100">
                    ✕
                  </button>
                )}
              </span>
            ))}
            {!note.trashed && (
              <input
                value={tagDraft}
                onChange={(e) => setTagDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && tagDraft.trim()) {
                    onAddTag(tagDraft.trim().replace(/\s+/g, "-").toLowerCase());
                    setTagDraft("");
                  }
                }}
                placeholder="+ тег"
                className="w-20 bg-transparent text-[11.5px] text-[var(--text-secondary)] outline-none"
              />
            )}
          </div>
        </div>

        <div className="mt-2 flex-1">
          {note.trashed ? (
            <div
              className="px-6 py-5 text-[15px] leading-relaxed text-[var(--text)]"
              dangerouslySetInnerHTML={{ __html: draftContent || "<p class='opacity-60'>Нет текста</p>" }}
            />
          ) : (
            <RichEditor html={draftContent} onChange={onChangeContent} editorRef={editorRef} />
          )}
        </div>
      </div>

      <div className="flex items-center justify-between gap-3 border-t border-[var(--stroke)] px-4 py-2 text-[11.5px] text-[var(--text-secondary)]">
        <span>
          {words} слов · {chars} симв. · ~{readingMinutes} мин чтения
        </span>
        <span className="flex items-center gap-2">
          {!note.trashed && (
            <span>
              {saveStatus === "saving" ? "Сохранение…" : saveStatus === "saved" ? "Сохранено" : ""}
            </span>
          )}
          <span>Изменено: {formatFullDate(note.updatedAt)}</span>
        </span>
      </div>
    </section>
  );
}
