"use client";

import { Icon } from "@/components/icons";
import type { FolderDTO, ViewKey } from "@/lib/types";
import { FOLDER_COLORS, FOLDER_ICONS, cx } from "@/lib/utils";
import { useRef, useState } from "react";

const NOTE_DRAG_TYPE = "application/x-note-id";
const FOLDER_DRAG_TYPE = "application/x-folder-id";

type ViewCounts = Record<ViewKey, number>;

export function Sidebar({
  folders,
  folderCounts,
  viewCounts,
  tags,
  activeView,
  activeFolderId,
  activeTag,
  theme,
  onToggleTheme,
  onSelectView,
  onSelectFolder,
  onSelectTag,
  onCreateFolder,
  onRenameFolder,
  onDeleteFolder,
  onSetFolderStyle,
  onReorderFolders,
  onDropNoteOnFolder,
  onOpenSettings,
  mobileOpen,
  onCloseMobile,
}: {
  folders: FolderDTO[];
  folderCounts: Record<number, number>;
  viewCounts: ViewCounts;
  tags: { tag: string; count: number }[];
  activeView: ViewKey;
  activeFolderId: number | null;
  activeTag: string | null;
  theme: "light" | "dark";
  onToggleTheme: () => void;
  onSelectView: (v: ViewKey) => void;
  onSelectFolder: (id: number | null) => void;
  onSelectTag: (tag: string | null) => void;
  onCreateFolder: () => void;
  onRenameFolder: (id: number, name: string) => void;
  onDeleteFolder: (id: number) => void;
  onSetFolderStyle: (id: number, patch: { color?: string; icon?: string }) => void;
  onReorderFolders: (order: number[]) => void;
  onDropNoteOnFolder: (noteId: number, folderId: number | null) => void;
  onOpenSettings: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState("");
  const [styleMenuId, setStyleMenuId] = useState<number | null>(null);
  const dragFolderIndex = useRef<number | null>(null);
  const [overTarget, setOverTarget] = useState<string | null>(null);

  function startRename(f: FolderDTO) {
    setEditingId(f.id);
    setEditingName(f.name);
  }

  function commitRename(id: number) {
    if (editingName.trim()) onRenameFolder(id, editingName.trim());
    setEditingId(null);
  }

  function handleFolderDrop(e: React.DragEvent, folderId: number | null, index: number | null) {
    e.preventDefault();
    setOverTarget(null);
    if (e.dataTransfer.types.includes(NOTE_DRAG_TYPE)) {
      const noteId = Number(e.dataTransfer.getData(NOTE_DRAG_TYPE));
      if (!Number.isNaN(noteId)) onDropNoteOnFolder(noteId, folderId);
      return;
    }
    if (e.dataTransfer.types.includes(FOLDER_DRAG_TYPE) && index !== null && dragFolderIndex.current !== null) {
      const from = dragFolderIndex.current;
      if (from === index) return;
      const order = folders.map((f) => f.id);
      const [moved] = order.splice(from, 1);
      order.splice(index, 0, moved);
      onReorderFolders(order);
    }
  }

  const navItem = (
    key: ViewKey,
    label: string,
    icon: React.ReactNode,
    count: number
  ) => (
    <button
      key={key}
      onClick={() => onSelectView(key)}
      className={cx(
        "flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-[13.5px] transition",
        activeView === key && activeFolderId === null
          ? "bg-[var(--active)] font-semibold text-[var(--accent)]"
          : "text-[var(--text)] hover:bg-[var(--hover)]"
      )}
    >
      <span className="shrink-0">{icon}</span>
      <span className="flex-1 truncate">{label}</span>
      {count > 0 && <span className="text-xs text-[var(--text-secondary)]">{count}</span>}
    </button>
  );

  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/30 md:hidden" onClick={onCloseMobile} />
      )}
      <aside
        className={cx(
          "app-scroll fixed z-40 flex h-full w-[266px] shrink-0 flex-col overflow-y-auto border-r border-[var(--stroke)] bg-[var(--rail)] px-3 py-3 transition-transform md:static md:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="mb-3 flex items-center gap-2 px-1">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-md bg-[var(--accent)] text-white">
            <Icon.Notebook className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-[14px] font-semibold leading-tight text-[var(--text)]">Заметки</p>
            <p className="text-[11px] text-[var(--text-secondary)]">как в Microsoft 365</p>
          </div>
          <button
            onClick={onToggleTheme}
            title="Сменить тему"
            className="grid h-8 w-8 shrink-0 place-items-center rounded-md text-[var(--text-secondary)] hover:bg-[var(--hover)]"
          >
            {theme === "light" ? <Icon.Moon className="h-4 w-4" /> : <Icon.Sun className="h-4 w-4" />}
          </button>
        </div>

        <nav className="flex flex-col gap-0.5">
          {navItem("all", "Все заметки", <Icon.Notebook className="h-4 w-4" />, viewCounts.all)}
          {navItem("favorites", "Избранное", <Icon.Star className="h-4 w-4" />, viewCounts.favorites)}
          {navItem("pinned", "Закреплённые", <Icon.Pin className="h-4 w-4" />, viewCounts.pinned)}
          {navItem("archive", "Архив", <Icon.Archive className="h-4 w-4" />, viewCounts.archive)}
          {navItem("trash", "Корзина", <Icon.Trash className="h-4 w-4" />, viewCounts.trash)}
        </nav>

        <div className="mt-5 flex items-center justify-between px-1">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">Папки</p>
          <button
            onClick={onCreateFolder}
            title="Новая папка"
            className="grid h-6 w-6 place-items-center rounded text-[var(--text-secondary)] hover:bg-[var(--hover)] hover:text-[var(--text)]"
          >
            <Icon.Plus className="h-3.5 w-3.5" />
          </button>
        </div>

        <ul
          className="mt-1 flex flex-col gap-0.5"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => handleFolderDrop(e, null, null)}
        >
          <li
            onDragOver={(e) => {
              e.preventDefault();
              setOverTarget("unfiled");
            }}
            onDragLeave={() => setOverTarget((v) => (v === "unfiled" ? null : v))}
            onDrop={(e) => handleFolderDrop(e, null, null)}
          >
            <button
              onClick={() => onSelectFolder(null)}
              className={cx(
                "flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-[13.5px] transition",
                activeFolderId === null && activeView === "all" ? "" : "",
                overTarget === "unfiled" && "ring-2 ring-[var(--accent)]",
                "text-[var(--text-secondary)] hover:bg-[var(--hover)]"
              )}
            >
              <span>🗂️</span>
              <span className="flex-1 truncate italic">Без папки</span>
            </button>
          </li>
          {folders.map((f, index) => (
            <li
              key={f.id}
              draggable
              onDragStart={(e) => {
                dragFolderIndex.current = index;
                e.dataTransfer.setData(FOLDER_DRAG_TYPE, String(f.id));
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setOverTarget(`folder-${f.id}`);
              }}
              onDragLeave={() => setOverTarget((v) => (v === `folder-${f.id}` ? null : v))}
              onDrop={(e) => handleFolderDrop(e, f.id, index)}
              className="group relative"
            >
              {editingId === f.id ? (
                <input
                  autoFocus
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  onBlur={() => commitRename(f.id)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename(f.id);
                    if (e.key === "Escape") setEditingId(null);
                  }}
                  className="w-full rounded-md border border-[var(--accent)] bg-[var(--surface)] px-2.5 py-1.5 text-[13.5px] outline-none"
                />
              ) : (
                <button
                  onClick={() => onSelectFolder(f.id)}
                  onDoubleClick={() => startRename(f)}
                  className={cx(
                    "flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-[13.5px] transition",
                    activeFolderId === f.id
                      ? "bg-[var(--active)] font-semibold text-[var(--accent)]"
                      : "text-[var(--text)] hover:bg-[var(--hover)]",
                    overTarget === `folder-${f.id}` && "ring-2 ring-[var(--accent)]"
                  )}
                >
                  <span className="shrink-0">{f.icon}</span>
                  <span className="flex-1 truncate">{f.name}</span>
                  {f.noteCount > 0 && <span className="text-xs text-[var(--text-secondary)]">{folderCounts[f.id] ?? f.noteCount}</span>}
                </button>
              )}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setStyleMenuId(styleMenuId === f.id ? null : f.id);
                }}
                className="absolute right-1 top-1/2 hidden -translate-y-1/2 rounded p-1 text-[var(--text-secondary)] hover:bg-[var(--hover)] group-hover:block"
              >
                <Icon.Dots className="h-3.5 w-3.5" />
              </button>

              {styleMenuId === f.id && (
                <div className="absolute right-0 top-8 z-50 w-56 rounded-lg border border-[var(--stroke)] bg-[var(--surface)] p-3 shadow-[0_12px_30px_rgba(0,0,0,0.18)]">
                  <p className="mb-1.5 text-[11px] font-semibold uppercase text-[var(--text-secondary)]">Значок</p>
                  <div className="mb-3 flex flex-wrap gap-1.5">
                    {FOLDER_ICONS.map((icon) => (
                      <button
                        key={icon}
                        onClick={() => onSetFolderStyle(f.id, { icon })}
                        className={cx(
                          "grid h-7 w-7 place-items-center rounded-md border text-sm hover:bg-[var(--hover)]",
                          f.icon === icon ? "border-[var(--accent)]" : "border-transparent"
                        )}
                      >
                        {icon}
                      </button>
                    ))}
                  </div>
                  <p className="mb-1.5 text-[11px] font-semibold uppercase text-[var(--text-secondary)]">Цвет</p>
                  <div className="mb-3 flex flex-wrap gap-1.5">
                    {FOLDER_COLORS.map((color) => (
                      <button
                        key={color}
                        onClick={() => onSetFolderStyle(f.id, { color })}
                        className={cx(
                          "h-6 w-6 rounded-full border-2",
                          f.color === color ? "border-[var(--text)]" : "border-transparent"
                        )}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      onDeleteFolder(f.id);
                      setStyleMenuId(null);
                    }}
                    className="flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-sm text-rose-600 hover:bg-rose-50"
                  >
                    <Icon.Trash className="h-3.5 w-3.5" /> Удалить папку
                  </button>
                </div>
              )}
            </li>
          ))}
          {folders.length === 0 && (
            <li className="px-2.5 py-2 text-xs text-[var(--text-secondary)]">Папок пока нет</li>
          )}
        </ul>

        {tags.length > 0 && (
          <>
            <p className="mt-5 px-1 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-secondary)]">Теги</p>
            <div className="mt-1.5 flex flex-wrap gap-1.5 px-1">
              {tags.map(({ tag, count }) => (
                <button
                  key={tag}
                  onClick={() => onSelectTag(activeTag === tag ? null : tag)}
                  className={cx(
                    "flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11.5px] transition",
                    activeTag === tag
                      ? "border-[var(--accent)] bg-[var(--active)] text-[var(--accent)]"
                      : "border-[var(--stroke)] text-[var(--text-secondary)] hover:bg-[var(--hover)]"
                  )}
                >
                  <Icon.Tag className="h-3 w-3" /> {tag}
                  <span className="opacity-70">{count}</span>
                </button>
              ))}
            </div>
          </>
        )}

        <div className="mt-auto pt-4">
          <button
            onClick={onOpenSettings}
            className="flex w-full items-center gap-2.5 rounded-md px-2.5 py-1.5 text-left text-[13.5px] text-[var(--text-secondary)] hover:bg-[var(--hover)]"
          >
            <Icon.Settings className="h-4 w-4" /> Настройки
          </button>
        </div>
      </aside>
    </>
  );
}
