export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function debounce<Args extends unknown[]>(fn: (...args: Args) => void, wait: number) {
  let timer: ReturnType<typeof setTimeout> | null = null;
  const debounced = (...args: Args) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
  debounced.cancel = () => {
    if (timer) clearTimeout(timer);
  };
  return debounced;
}

export function htmlToPlainText(html: string): string {
  if (!html) return "";
  if (typeof document === "undefined") {
    return html.replace(/<[^>]+>/g, " ").trim();
  }
  const div = document.createElement("div");
  div.innerHTML = html
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<br\s*\/?>/gi, "\n");
  const text = div.textContent ?? "";
  return text.replace(/\n{3,}/g, "\n\n").trim();
}

export function wordStats(html: string) {
  const text = htmlToPlainText(html);
  const words = text.split(/\s+/).filter(Boolean);
  const chars = text.replace(/\s/g, "").length;
  const readingMinutes = Math.max(1, Math.round(words.length / 200));
  return { words: words.length, chars, readingMinutes };
}

export function formatRelativeTime(iso: string | null | undefined): string {
  if (!iso) return "";
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const diffSec = Math.round(diffMs / 1000);
  if (diffSec < 10) return "только что";
  if (diffSec < 60) return `${diffSec} с назад`;
  const diffMin = Math.round(diffSec / 60);
  if (diffMin < 60) return `${diffMin} мин назад`;
  const diffHour = Math.round(diffMin / 60);
  if (diffHour < 24) return `${diffHour} ч назад`;
  const diffDay = Math.round(diffHour / 24);
  if (diffDay === 1) return "вчера";
  if (diffDay < 7) return `${diffDay} дн назад`;
  return date.toLocaleDateString("ru-RU", { day: "numeric", month: "short", year: "numeric" });
}

export function formatFullDate(iso: string | null | undefined): string {
  if (!iso) return "";
  const date = new Date(iso);
  return date.toLocaleString("ru-RU", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const NOTE_COLORS = [
  "#ffffff",
  "#fff4ce",
  "#ffe3cc",
  "#fde7e9",
  "#f6d9ff",
  "#e3dcff",
  "#dbeeff",
  "#d7f5ec",
  "#e2f5d0",
];

export const FOLDER_COLORS = [
  "#0078D4",
  "#107C10",
  "#D13438",
  "#B4009E",
  "#8764B8",
  "#CA5010",
  "#00B7C3",
  "#486991",
];

export const FOLDER_ICONS = ["📁", "⭐", "💼", "📚", "🏠", "💡", "🎯", "🧾", "🎨", "🛒", "✈️", "🎓"];
