import { db } from "@/db";
import { folders, notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function parseId(idParam: string) {
  const id = Number(idParam);
  return Number.isInteger(id) ? id : null;
}

export async function PATCH(req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const update: Partial<typeof folders.$inferInsert> = {};

  if (typeof body.name === "string") update.name = body.name.trim() || "Без названия";
  if (typeof body.color === "string") update.color = body.color;
  if (typeof body.icon === "string") update.icon = body.icon;
  if (typeof body.position === "number") update.position = body.position;

  if (Object.keys(update).length === 0) {
    return Response.json({ error: "No fields to update" }, { status: 400 });
  }

  const [updated] = await db.update(folders).set(update).where(eq(folders.id, id)).returning();
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json(updated);
}

export async function DELETE(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  await db.update(notes).set({ folderId: null }).where(eq(notes.folderId, id));
  const [deleted] = await db.delete(folders).where(eq(folders.id, id)).returning();
  if (!deleted) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json({ ok: true });
}
