import { db } from "@/db";
import { folders, notes } from "@/db/schema";
import { asc, eq, sql } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select({
      id: folders.id,
      name: folders.name,
      color: folders.color,
      icon: folders.icon,
      position: folders.position,
      createdAt: folders.createdAt,
      noteCount: sql<number>`count(${notes.id}) filter (where ${notes.trashed} = false)`.mapWith(Number),
    })
    .from(folders)
    .leftJoin(notes, eq(notes.folderId, folders.id))
    .groupBy(folders.id)
    .orderBy(asc(folders.position), asc(folders.id));

  return Response.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const name = typeof body.name === "string" && body.name.trim() ? body.name.trim() : "Новая папка";
  const color = typeof body.color === "string" ? body.color : "#0078D4";
  const icon = typeof body.icon === "string" ? body.icon : "📁";

  const maxPositionRow = await db
    .select({ max: sql<number>`coalesce(max(${folders.position}), -1)`.mapWith(Number) })
    .from(folders);
  const nextPosition = (maxPositionRow[0]?.max ?? -1) + 1;

  const [created] = await db
    .insert(folders)
    .values({ name, color, icon, position: nextPosition })
    .returning();

  return Response.json({ ...created, noteCount: 0 }, { status: 201 });
}
