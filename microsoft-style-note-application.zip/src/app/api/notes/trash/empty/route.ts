import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST() {
  await db.delete(notes).where(eq(notes.trashed, true));
  return Response.json({ ok: true });
}
