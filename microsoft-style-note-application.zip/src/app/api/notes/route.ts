import { db } from "@/db";
import { notes } from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const hasView = searchParams.has("view");
  const view = searchParams.get("view") ?? "all";
  const folderId = searchParams.get("folderId");
  const tag = searchParams.get("tag");
  const q = searchParams.get("q")?.trim();
  const sort = searchParams.get("sort") ?? "updated-desc";

  if (!hasView) {
    // Full, unfiltered snapshot used by the client for instant local filtering.
    const rows = await db.select().from(notes).orderBy(desc(notes.pinned), desc(notes.updatedAt));
    return Response.json(rows);
  }

  const conditions = [];

  if (view === "trash") {
    conditions.push(eq(notes.trashed, true));
  } else {
    conditions.push(eq(notes.trashed, false));
    if (view === "favorites") conditions.push(eq(notes.favorite, true));
    if (view === "pinned") conditions.push(eq(notes.pinned, true));
    if (view === "archive") {
      conditions.push(eq(notes.archived, true));
    } else if (view !== "favorites" && view !== "pinned") {
      conditions.push(eq(notes.archived, false));
    }
  }

  if (folderId && folderId !== "null" && !Number.isNaN(Number(folderId))) {
    conditions.push(eq(notes.folderId, Number(folderId)));
  } else if (folderId === "null") {
    conditions.push(sql`${notes.folderId} is null`);
  }

  if (tag) {
    conditions.push(sql`${notes.tags} @> ${JSON.stringify([tag])}::jsonb`);
  }

  if (q) {
    conditions.push(or(ilike(notes.title, `%${q}%`), ilike(notes.content, `%${q}%`)));
  }

  let orderBy = [desc(notes.pinned), desc(notes.updatedAt)];
  if (sort === "created-desc") orderBy = [desc(notes.pinned), desc(notes.createdAt)];
  if (sort === "title-asc") orderBy = [desc(notes.pinned), asc(notes.title)];
  if (sort === "title-desc") orderBy = [desc(notes.pinned), desc(notes.title)];
  if (view === "trash") orderBy = [desc(notes.deletedAt)];

  const rows = await db
    .select()
    .from(notes)
    .where(and(...conditions))
    .orderBy(...orderBy);

  return Response.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const folderId = typeof body.folderId === "number" ? body.folderId : null;
  const title = typeof body.title === "string" ? body.title : "";
  const content = typeof body.content === "string" ? body.content : "";

  const [created] = await db
    .insert(notes)
    .values({ folderId, title, content })
    .returning();

  return Response.json(created, { status: 201 });
}
