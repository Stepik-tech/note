import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function parseId(idParam: string) {
  const id = Number(idParam);
  return Number.isInteger(id) ? id : null;
}

export async function GET(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const [row] = await db.select().from(notes).where(eq(notes.id, id));
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(row);
}

export async function PATCH(req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const update: Partial<typeof notes.$inferInsert> = {};

  if (typeof body.title === "string") update.title = body.title;
  if (typeof body.content === "string") update.content = body.content;
  if (typeof body.color === "string") update.color = body.color;
  if (Array.isArray(body.tags)) update.tags = body.tags.filter((t: unknown) => typeof t === "string");
  if (typeof body.pinned === "boolean") update.pinned = body.pinned;
  if (typeof body.favorite === "boolean") update.favorite = body.favorite;
  if (typeof body.archived === "boolean") update.archived = body.archived;
  if (body.folderId === null || typeof body.folderId === "number") update.folderId = body.folderId;
  if (typeof body.position === "number") update.position = body.position;

  if (typeof body.trashed === "boolean") {
    update.trashed = body.trashed;
    update.deletedAt = body.trashed ? new Date() : null;
  }

  if (Object.keys(update).length === 0) {
    return Response.json({ error: "No fields to update" }, { status: 400 });
  }

  update.updatedAt = new Date();

  const [updated] = await db.update(notes).set(update).where(eq(notes.id, id)).returning();
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });

  return Response.json(updated);
}

export async function DELETE(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = parseId(idParam);
  if (id === null) return Response.json({ error: "Invalid id" }, { status: 400 });

  const [existing] = await db.select().from(notes).where(eq(notes.id, id));
  if (!existing) return Response.json({ error: "Not found" }, { status: 404 });

  if (existing.trashed) {
    await db.delete(notes).where(eq(notes.id, id));
    return Response.json({ ok: true, permanent: true });
  }

  const [updated] = await db
    .update(notes)
    .set({ trashed: true, deletedAt: new Date(), updatedAt: new Date() })
    .where(eq(notes.id, id))
    .returning();

  return Response.json({ ok: true, permanent: false, note: updated });
}
