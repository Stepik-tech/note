import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = Number(idParam);
  if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });

  const [original] = await db.select().from(notes).where(eq(notes.id, id));
  if (!original) return Response.json({ error: "Not found" }, { status: 404 });

  const [created] = await db
    .insert(notes)
    .values({
      folderId: original.folderId,
      title: original.title ? `${original.title} (копия)` : "",
      content: original.content,
      color: original.color,
      tags: original.tags,
      pinned: false,
      favorite: false,
      archived: false,
      trashed: false,
    })
    .returning();

  return Response.json(created, { status: 201 });
}
