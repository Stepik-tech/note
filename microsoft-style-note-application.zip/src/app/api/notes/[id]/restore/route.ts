import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(_req: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await context.params;
  const id = Number(idParam);
  if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });

  const [updated] = await db
    .update(notes)
    .set({ trashed: false, deletedAt: null, archived: false, updatedAt: new Date() })
    .where(eq(notes.id, id))
    .returning();

  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json(updated);
}
