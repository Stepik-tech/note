import { db } from "@/db";
import { notes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

function stripHtml(html: string) {
  return html
    .replace(/<\s*br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const format = searchParams.get("format") === "txt" ? "txt" : "json";

  const rows = await db.select().from(notes).where(eq(notes.trashed, false));

  if (format === "json") {
    const body = JSON.stringify(rows, null, 2);
    return new Response(body, {
      headers: {
        "Content-Type": "application/json",
        "Content-Disposition": `attachment; filename="notes-backup-${Date.now()}.json"`,
      },
    });
  }

  const text = rows
    .map((n) => {
      const title = n.title || "Без названия";
      const divider = "=".repeat(Math.min(40, Math.max(10, title.length)));
      return `${title}\n${divider}\n${stripHtml(n.content)}\n`;
    })
    .join("\n\n");

  return new Response(text, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Content-Disposition": `attachment; filename="notes-export-${Date.now()}.txt"`,
    },
  });
}
