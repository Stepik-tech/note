import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Заметки — в стиле Microsoft",
  description: "Быстрые заметки с папками, тегами, автосохранением и экспортом — в стиле Microsoft Fluent Design.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
