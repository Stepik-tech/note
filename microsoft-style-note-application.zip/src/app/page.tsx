import NotesApp from "@/components/NotesApp";
import { db } from "@/db";
import { folders, notes } from "@/db/schema";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function ensureSeedData() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)`.mapWith(Number) }).from(folders);
  if (count > 0) return;

  const [work, personal, ideas] = await db
    .insert(folders)
    .values([
      { name: "Работа", color: "#0078D4", icon: "💼", position: 0 },
      { name: "Личное", color: "#107C10", icon: "🏠", position: 1 },
      { name: "Идеи", color: "#CA5010", icon: "💡", position: 2 },
    ])
    .returning();

  await db.insert(notes).values([
    {
      folderId: work.id,
      title: "Добро пожаловать в Заметки",
      pinned: true,
      tags: ["старт"],
      content:
        "<h3>Это ваш новый блокнот</h3><p>Пишите заметки, они сохраняются автоматически. Попробуйте возможности:</p>" +
        "<ul><li>Создавайте <b>папки</b> слева и перетаскивайте заметки прямо на них</li>" +
        "<li>Форматируйте текст: <b>жирный</b>, <i>курсив</i>, списки, чек-листы ✅</li>" +
        "<li>Копируйте весь текст заметки или сразу всего списка одной кнопкой</li>" +
        "<li>Закрепляйте, добавляйте в избранное, архивируйте, удаляйте в корзину</li>" +
        "<li>Ищите по всем заметкам (Ctrl+F) и создавайте новые (Ctrl+N)</li>" +
        "<li>Настройте тему и акцентный цвет в «Настройках»</li></ul>",
    },
    {
      folderId: ideas.id,
      title: "Список дел на неделю",
      tags: ["задачи"],
      content:
        '<div class="cl-item"><input type="checkbox" contenteditable="false" checked /><span>Изучить интерфейс</span></div>' +
        '<div class="cl-item"><input type="checkbox" contenteditable="false" /><span>Создать первую папку</span></div>' +
        '<div class="cl-item"><input type="checkbox" contenteditable="false" /><span>Импортировать старые заметки</span></div>',
    },
    {
      folderId: personal.id,
      title: "Идея для проекта",
      favorite: true,
      tags: ["проект", "идея"],
      content: "<p>Записывайте сюда любые мысли — всё сохранится автоматически, пока вы печатаете.</p>",
    },
  ]);
}

export default async function HomePage() {
  await ensureSeedData();
  return <NotesApp />;
}
